-- FindSure database schema for Supabase PostgreSQL.
-- The server uses the SERVICE ROLE KEY privately on the backend only.
-- Never put SUPABASE_SECRET_KEY or SUPABASE_SERVICE_ROLE_KEY in public/app.js or any browser bundle.

create extension if not exists pgcrypto;

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  listing_type text not null check (listing_type in ('lost','found')),
  item_type text not null check (item_type in ('phone','laptop','tablet','desktop','camera','watch','headphones','bike','car','keys','bag','documents','other-electronics','other')),
  title text not null check (length(title) between 1 and 100),
  description text not null default '',
  city text not null,
  area text not null default '',
  identifier text not null default '',
  contact text not null default '',
  share_contact boolean not null default false,
  status text not null default 'pending' check (status in ('pending','published','resolved','rejected')),
  created_at timestamptz not null default now(),
  lat double precision,
  lon double precision,
  owner_hash text not null,
  client_submission_id text
);

-- Safe migration for a pre-v6 database. The client ID makes offline retries idempotent.
alter table public.reports add column if not exists client_submission_id text;
create unique index if not exists reports_client_submission_id_uidx on public.reports (client_submission_id) where client_submission_id is not null;

create index if not exists reports_status_created_at_idx on public.reports (status, created_at desc);
create index if not exists reports_city_idx on public.reports (city);

create table if not exists public.devices (
  id uuid primary key default gen_random_uuid(),
  label text not null check (length(label) between 1 and 80),
  code_hash text not null unique,
  created_at timestamptz not null default now(),
  last_lat double precision,
  last_lon double precision,
  accuracy double precision,
  captured_at timestamptz,
  updated_at timestamptz,
  time_zone text,
  time_zone_name text,
  time_zone_source text
);

-- Safe migration for projects that already created the v2 table.
alter table public.devices add column if not exists captured_at timestamptz;
alter table public.devices add column if not exists time_zone text;
alter table public.devices add column if not exists time_zone_name text;
alter table public.devices add column if not exists time_zone_source text;

alter table public.reports enable row level security;
alter table public.devices enable row level security;
-- No anonymous policies are created: only the server-side service role should access these tables.
-- Keep the service-role key in your hosting provider's secret/environment-variable settings.

create table if not exists public.abuse_reports (
  id uuid primary key default gen_random_uuid(),
  report_id uuid not null references public.reports(id) on delete cascade,
  reason text not null check (reason in ('scam','personal-info','wrong-category','suspected-stolen','other')),
  details text not null default '',
  status text not null default 'open' check (status in ('open','reviewed','actioned')),
  created_at timestamptz not null default now()
);

create index if not exists abuse_reports_status_created_at_idx on public.abuse_reports (status, created_at desc);
alter table public.abuse_reports enable row level security;


-- FindSure v4: pilot support for a consent-based rotating BLE beacon network.
-- Raw short-lived rotating tokens are private backend data. Do not expose these
-- tables through anonymous Supabase policies; access only via the server secret.
create table if not exists public.device_beacon_tokens (
  id uuid primary key default gen_random_uuid(),
  device_id uuid not null references public.devices(id) on delete cascade,
  slot bigint not null,
  token text not null unique check (length(token) = 16),
  created_at timestamptz not null default now(),
  unique(device_id, slot)
);
create index if not exists device_beacon_tokens_device_slot_idx on public.device_beacon_tokens(device_id, slot);
create index if not exists device_beacon_tokens_slot_idx on public.device_beacon_tokens(slot);
alter table public.device_beacon_tokens enable row level security;

create table if not exists public.device_beacon_sightings (
  id uuid primary key default gen_random_uuid(),
  device_id uuid not null references public.devices(id) on delete cascade,
  token_slot bigint not null,
  lat double precision not null check (lat between -90 and 90),
  lon double precision not null check (lon between -180 and 180),
  accuracy double precision,
  captured_at timestamptz not null,
  relay_location_captured_at timestamptz not null default now(),
  received_at timestamptz not null default now(),
  time_zone text not null default 'UTC',
  time_zone_name text not null default 'UTC',
  time_zone_source text not null default 'UTC-fallback',
  finder_platform text not null default 'android' check (finder_platform in ('android','ios','web'))
);
alter table public.device_beacon_sightings add column if not exists relay_location_captured_at timestamptz not null default now();
create index if not exists device_beacon_sightings_device_captured_idx on public.device_beacon_sightings(device_id, captured_at desc);
alter table public.device_beacon_sightings enable row level security;
-- No anonymous policies: this pilot is served through the backend's private DB key.

-- v5: scoped credentials for independently powered external BLE tags.
-- A tag credential can fetch only its own rotating beacon tokens; it cannot query device location.
-- Revoking a tag makes all of its old cached tokens fail validation immediately.
create table if not exists public.device_beacon_tags (
  id uuid primary key default gen_random_uuid(),
  device_id uuid not null references public.devices(id) on delete cascade,
  label text not null default 'FindSure external BLE tag',
  credential_hash text not null unique,
  created_at timestamptz not null default now(),
  revoked_at timestamptz
);
create index if not exists device_beacon_tags_device_idx on public.device_beacon_tags(device_id, created_at desc);
alter table public.device_beacon_tags enable row level security;

create table if not exists public.device_beacon_tag_tokens (
  id uuid primary key default gen_random_uuid(),
  tag_id uuid not null references public.device_beacon_tags(id) on delete cascade,
  device_id uuid not null references public.devices(id) on delete cascade,
  slot bigint not null,
  token text not null unique check (length(token) = 16),
  created_at timestamptz not null default now(),
  unique(tag_id, slot)
);
create index if not exists device_beacon_tag_tokens_tag_slot_idx on public.device_beacon_tag_tokens(tag_id, slot);
create index if not exists device_beacon_tag_tokens_slot_idx on public.device_beacon_tag_tokens(slot);
alter table public.device_beacon_tag_tokens enable row level security;
-- No anonymous policies: use only through the backend server secret.


-- v7: SIM/GNSS vehicle trackers. The tracker API key is stored only as SHA-256;
-- location history is private and accessible only through the backend service key.
create table if not exists public.vehicle_trackers (
  id uuid primary key default gen_random_uuid(),
  device_id uuid not null references public.devices(id) on delete cascade,
  label text not null check (length(label) between 1 and 80),
  vehicle_type text not null check (vehicle_type in ('car','bike','other')),
  make_model text not null default '',
  credential_hash text not null unique,
  created_at timestamptz not null default now(),
  revoked_at timestamptz
);
create index if not exists vehicle_trackers_device_idx on public.vehicle_trackers(device_id, created_at desc);
alter table public.vehicle_trackers enable row level security;

create table if not exists public.vehicle_tracker_positions (
  id uuid primary key default gen_random_uuid(),
  tracker_id uuid not null references public.vehicle_trackers(id) on delete cascade,
  lat double precision not null check (lat between -90 and 90),
  lon double precision not null check (lon between -180 and 180),
  accuracy double precision,
  speed_kph double precision,
  heading double precision,
  ignition boolean,
  battery_voltage double precision,
  captured_at timestamptz not null,
  received_at timestamptz not null default now(),
  time_zone text not null default 'UTC',
  time_zone_name text not null default 'UTC',
  time_zone_source text not null default 'UTC-fallback'
);
create index if not exists vehicle_tracker_positions_latest_idx on public.vehicle_tracker_positions(tracker_id, captured_at desc);
alter table public.vehicle_tracker_positions enable row level security;
-- No anonymous policies. The API key is accepted only by the FindSure backend.
