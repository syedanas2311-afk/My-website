The local JSON database is created automatically when the server starts.
Runtime reports and credentials are intentionally not included in the downloadable release ZIP.
For public deployment, configure Supabase as described in DEPLOY_PUBLIC.md.
