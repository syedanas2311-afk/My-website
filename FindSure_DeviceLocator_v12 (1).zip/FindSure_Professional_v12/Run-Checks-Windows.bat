@echo off
cd /d "%~dp0"
node --check server.js
if errorlevel 1 goto fail
node --check public\app.js
if errorlevel 1 goto fail
echo.
echo JavaScript syntax checks passed.
pause
exit /b 0
:fail
echo.
echo A syntax check failed. Send the error text to your assistant.
pause
exit /b 1
