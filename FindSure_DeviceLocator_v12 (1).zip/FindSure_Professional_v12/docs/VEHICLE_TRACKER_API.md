# FindSure v7 Vehicle Tracker API

## Provision

`POST /api/vehicle-trackers/register`

```json
{"label":"My car","vehicleType":"car","makeModel":"Example make/model"}
```

The response includes a private owner recovery code, tracker ID, one-time 64-hex API key, and `/api/vehicle-trackers/telemetry` endpoint. Save both secrets securely; the server stores only hashes. Provisioning is rate-limited.

## Upload telemetry

`POST /api/vehicle-trackers/telemetry`

Headers:

- `Authorization: Bearer <tracker-api-key>`
- `Content-Type: application/json`

Body fields:

- `lat`, `lon`: required decimal WGS84 coordinates
- `capturedAt`: required ISO 8601 timestamp, UTC preferred; must be no more than 2 minutes in the future and no older than 48 hours
- `accuracy`, `speedKph`, `heading`, `ignition`, `batteryVoltage`, `timeZone`: optional validated metadata

The backend records both capture time and server receive time, and estimates the timezone from rounded location coordinates. It rate-limits requests and rejects revoked keys.

## Owner lookup

`POST /api/vehicle-trackers/locate`

```json
{"code":"OWNER_PRIVATE_RECOVERY_CODE"}
```

The response contains only the latest location for the vehicle associated with that private owner code. It is not a public tracking endpoint. FindSure's web page uses owner consent and renders the returned timestamped point on a map.

## Revoke

`POST /api/vehicle-trackers/revoke`

```json
{"code":"OWNER_PRIVATE_RECOVERY_CODE","trackerId":"TRACKER_ID"}
```

A revoked key is rejected immediately for future telemetry. Existing position history is retained under the configured retention policy; a full public deployment should add owner data-export/deletion controls and a retention schedule.

## Test with curl (local demo only)

After registering a test vehicle in the web UI, replace the placeholders:

```bash
curl -X POST http://localhost:3000/api/vehicle-trackers/telemetry \
  -H "Authorization: Bearer REPLACE_WITH_TRACKER_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"lat":24.8607,"lon":67.0011,"accuracy":8,"speedKph":0,"capturedAt":"2026-11-04T05:00:00.000Z"}'
```

Use current UTC time for `capturedAt` when you actually run the command. Never use example coordinates as a real vehicle position. Local JSON storage is for testing; configure Supabase before public launch.
