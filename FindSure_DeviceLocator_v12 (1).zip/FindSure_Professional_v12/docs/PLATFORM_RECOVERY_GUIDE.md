# Official platform recovery routes (FindSure v7)

FindSure gives users a clear route to the account/network that actually controls the location. It does not read private location data from these vendors or telecom operators.

| Platform | Owner's official route | Pre-loss setup / limitation |
|---|---|---|
| Android | https://android.com/find | Use the Google account already on the device; enable Find Hub and offline finding where supported. Offline/power-off support depends on model, hardware and settings. |
| Samsung Galaxy | https://samsungfind.samsung.com/ | Enable Samsung Find before loss and sign in with the Samsung account. Feature availability varies by device and region. |
| iPhone/iPad/Mac | https://www.icloud.com/find | Enable Find My in the Apple Account settings before loss. Powered-off/offline finding depends on compatible device/network support and settings. |
| Windows 10/11 | https://account.microsoft.com/devices | Microsoft says Find My Device should be enabled before loss; sign in with a personal Microsoft account as an administrator and enable device location. |
| Other smart tags/headphones | Manufacturer's own app/network | Pair the supported accessory before loss; use its vendor account. Do not assume compatibility between networks. |

## Integration access

- Google Find Hub: Google states it does not provide a general SDK/API for arbitrary Find Hub accessory integrations. A hardware partner must submit a device proposal, sign agreements, onboard, implement firmware and pass third-party certification before activation. https://developers.google.com/nearby/fast-pair/landing-page-find-hub
- Apple Find My: Accessory manufacturers must enroll in the MFi program to access proprietary Find My specifications, components and certification process. https://developer.apple.com/find-my/ and https://mfi.apple.com/en/how-it-works
- Windows: Microsoft's consumer Find My Device is an owner-account feature; FindSure does not have a general endpoint to retrieve coordinates from arbitrary Microsoft accounts. https://support.microsoft.com/en-us/accounts-billing/security/find-and-lock-a-lost-windows-device

## FindSure Android community network

The native Android companion is an opt-in pilot. Android background execution, BLE and background-location rules apply; users must see and consent to the service, and Google Play location/background permissions are reviewed. Coverage exists only where volunteer devices are nearby and scanning. It is not the same as Google's global Find Hub or Apple's Find My network.

References:
- https://developer.android.com/develop/connectivity/bluetooth/ble/background
- https://support.google.com/googleplay/android-developer/answer/9799150
