# FindSure v8 — Affordable recovery options

This document helps users choose an option without assuming every person can afford a dedicated tracker.

## Cars and bikes

### Option A — Reuse a spare Android phone (lowest new-hardware cost)

A spare smartphone already contains GNSS/GPS, a cellular modem, a battery and a processor. The FindSure Android Companion v0.6 adds a user-started **Vehicle GPS sharing** foreground-service mode that posts location points to the existing vehicle telemetry API. It can queue up to 100 readings locally when data is temporarily unavailable and upload them later.

What is still needed: an Android phone the owner already has, a SIM/data package, reliable safe charging, a public HTTPS FindSure server, a vehicle recovery code and tracker API key, and a built debug APK. This is not zero-cost if the user must buy a phone or data. It is not a dedicated anti-theft tracker: it stops reporting if the phone is switched off, removed, force-stopped, out of battery, overheated or denied location.

Use only in a vehicle the user owns or is authorised to manage. Start the visible service from the app, keep its ongoing notification, and stop it when no longer needed. Never install it to secretly track another person's movements. Don't leave a lithium battery in a dangerously hot vehicle or connect an unprotected charger to car wiring.

### Option B — Community BLE tag (no SIM in the tag)

A battery-powered Bluetooth Low Energy tag can keep advertising while the car/bike ignition is off because the tag has its own battery. A nearby FindSure volunteer Android app may record an approximate finder-phone sighting and relay it later. This can be cheaper to run than a cellular tracker because the tag itself has no SIM/data subscription.

Limitations: BLE range is short and environment-dependent; it does not calculate the vehicle's GPS location; it relies on nearby FindSure users with the companion app; sightings are not continuous; the tag battery must last; the tag must be attached before the loss. A small tag without a large volunteer network may be of limited use. Add anti-stalking protections and investigate Android/iOS unknown-tracker alerts before consumer release.

### Option C — Free community recovery listing

No new hardware or monthly plan is needed. An owner posts an item/vehicle report with a last-seen area and safe contact method. Community members can report a potential match. This is not live tracking and reports need moderation to reduce scams and stolen-goods laundering.

### Option D — Dedicated GNSS + cellular tracker

This remains the more robust vehicle-specific choice when installed correctly, but it costs more up front and may have SIM/platform fees. Ensure the tracker uses local mobile bands, has a backup-power design, stores points during data outages, has an API/protocol supported by FindSure, and is installed with automotive-grade fuse and transient protection by a qualified technician. Do not purchase a device based only on the words “GPS tracker”; cheap GSM/LBS-only devices can provide tower-based estimates instead of GNSS coordinates.

## Mobile phones and other devices after power-off

- An ordinary Android/iOS app cannot make a normal fully shut-down device keep transmitting. If its own power and radios are off, it cannot produce new BLE/GPS readings.
- Some manufacturers integrate low-power hardware/firmware and crowd-finding networks for selected device models. Users must turn on required settings and often a screen lock before loss. FindSure has no general API for reading private Google/Apple/Samsung network locations.
- An independent battery-powered tag attached before loss can still broadcast while the host phone/laptop/bag is switched off. The community finder then sees the tag, not the powered-off host device's own GPS.
- For device families without built-in support, this separate tag or a dedicated asset tracker is the practical workaround.

## Technology / policy notes

- Android location foreground services must be user-started while the app is visible, use the right foreground-service type and permissions, and show an ongoing notification. Android's background-start and location-service rules vary by version and can restrict operation.
- Android BLE scanning/connection in the background has process and foreground-service limitations. A pilot must be tested across Android versions and vendors.
- Public community finding must use rotating unguessable identifiers, owner-only location access, minimal retention, abuse reporting, opt-in volunteers, anti-stalking measures, and clear location-source labels. Do not show a finder volunteer's exact live location to arbitrary users.

## Useful official references

- Google Find Hub privacy/offline finding: https://support.google.com/android/answer/14796936
- Android foreground-service start restrictions: https://developer.android.com/develop/background-work/services/fgs/restrictions-bg-start
- Android foreground-service type and location permission requirements: https://developer.android.com/about/versions/14/changes/fgs-types-required
- Android BLE background communications: https://developer.android.com/develop/connectivity/bluetooth/ble/background
- Android background location policy: https://support.google.com/googleplay/android-developer/answer/9799150
