'use strict';
const $ = id => document.getElementById(id);
const itemLabels = { phone: 'Phone', laptop: 'Laptop', tablet: 'Tablet', desktop: 'Desktop computer', camera: 'Camera', watch: 'Smartwatch', headphones: 'Headphones', bike: 'Bike / motorcycle', car: 'Car', keys: 'Keys', bag: 'Bag / luggage', documents: 'Documents', 'other-electronics': 'Other electronics', other: 'Other item' };
const viewLabels = { home: 'FindSure — Device Locator & Recovery', browse: 'Community reports', create: 'Report lost or found', 'my-reports': 'Manage my report', device: 'Device locator', vehicle: 'Car & bike recovery', security: 'Prepare your devices', admin: 'Moderator review' };
let allReports = [], publicReports = [], maps = {}, pickedLocation = null, newOwnerCode = '', newReportId = '', toastTimer = null, devVersion = null, appIsDev = true, installPrompt = null;
let liveWatchId = null, livePushTimer = null, liveLastSentAt = 0, liveLastCoords = null, lookupTimer = null, lookupBusy = false, nearbyOrigin = null, possibleMatchSearch = null;
const OFFLINE_QUEUE_KEY = 'findsure-offline-location-queue';
const OFFLINE_REPORT_QUEUE_KEY = 'findsure-offline-report-queue-v6';
const OFFLINE_REPORT_HISTORY_KEY = 'findsure-offline-report-history-v6';
let pendingReportDraftBody = null, syncingOfflineReports = false, activeReportSubmissionId = '';
function newReportSubmissionId() { const bytes=new Uint8Array(16); if(window.crypto?.getRandomValues) window.crypto.getRandomValues(bytes); else for(let i=0;i<bytes.length;i++) bytes[i]=Math.floor(Math.random()*256); return Array.from(bytes,b=>b.toString(16).padStart(2,'0')).join('').toUpperCase(); }
const mapPins = {};

function escapeHtml(value) { return String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch])); }
function toast(message) { const el = $('toast'); el.textContent = message; el.classList.add('show'); clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove('show'), 3200); }
async function api(url, options = {}) {
  const headers = { ...(options.body ? { 'Content-Type': 'application/json' } : {}), ...(options.headers || {}) };
  const response = await fetch(url, { ...options, headers, cache: 'no-store' });
  let data = {}; try { data = await response.json(); } catch {}
  if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
  return data;
}
function showView(name) {
  document.querySelectorAll('.view').forEach(v => v.classList.toggle('active', v.id === `view-${name}`));
  document.querySelectorAll('.nav-link').forEach(b => b.classList.toggle('active', b.dataset.view === name || (name === 'security' && b.dataset.view === 'device')));
  $('pageTitle').textContent = viewLabels[name] || 'FindSure';
  const eyebrow = { home:'COMMUNITY RECOVERY', browse:'SEARCH LOST & FOUND', create:'COMMUNITY REPORT', 'my-reports':'YOUR PRIVATE REPORTS', device:'DEVICE LOCATOR', vehicle:'VEHICLE RECOVERY', security:'PREPARE BEFORE A LOSS', admin:'COMMUNITY MODERATION' };
  $('topEyebrow').textContent = eyebrow[name] || 'FINDSURE';
  if (name === 'home' || name === 'browse') loadReports().then(() => refreshMapSizes());
  if (name === 'create' || name === 'device' || name === 'vehicle') setTimeout(() => refreshMapSizes(), 120);
  if (name === 'my-reports') setTimeout(() => $('myReportCode')?.focus({preventScroll:true}), 180);
  if (name !== 'device') {
    if (liveWatchId !== null) stopLiveSharing('Sharing stopped because you left the Device Locator screen.');
    if (lookupTimer) { clearInterval(lookupTimer); lookupTimer=null; $('startLiveFollow')?.classList.remove('hidden'); $('stopLiveFollow')?.classList.add('hidden'); $('lookupLiveStatus').textContent='Auto-refresh is off.'; }
  }
  if (name === 'admin') $('adminKeyInput').focus({preventScroll:true});
  window.scrollTo({top:0, behavior:'smooth'});
  if (location.hash !== `#${name}`) history.replaceState(null, '', `${location.pathname}${location.search}#${name}`);
}
document.querySelectorAll('[data-view]').forEach(btn => btn.addEventListener('click', () => showView(btn.dataset.view)));
document.querySelectorAll('[data-goto]').forEach(btn => btn.addEventListener('click', () => { if (btn.dataset.reportType && $('listingType')) $('listingType').value = btn.dataset.reportType; showView(btn.dataset.goto); }));
document.querySelectorAll('[data-device-focus]').forEach(btn => btn.addEventListener('click', () => {
  showView('device');
  const target = btn.dataset.deviceFocus === 'setup' ? $('setupDevicePanel') : $('locateByCodePanel');
  setTimeout(() => { target?.scrollIntoView({behavior:'smooth', block:'start'}); (btn.dataset.deviceFocus === 'setup' ? $('deviceLabel') : $('lookupCode'))?.focus({preventScroll:true}); }, 140);
}));
document.querySelectorAll('[data-category]').forEach(btn => btn.addEventListener('click', () => { $('typeFilter').value = btn.dataset.category; showView('browse'); loadReports(); }));
document.querySelectorAll('details[data-refresh-map]').forEach(detail => detail.addEventListener('toggle', () => { if (detail.open) refreshMapSizes(); }));
function setLocatorMode(mode) {
  const setup = mode === 'setup';
  $('locatorRecoverPanel')?.classList.toggle('hidden', setup);
  $('locatorSetupPanel')?.classList.toggle('hidden', !setup);
  $('locatorRecoverTab')?.classList.toggle('active', !setup);
  $('locatorSetupTab')?.classList.toggle('active', setup);
  $('locatorRecoverTab')?.setAttribute('aria-selected', String(!setup));
  $('locatorSetupTab')?.setAttribute('aria-selected', String(setup));
  if (setup && liveWatchId !== null) stopLiveSharing('Sharing stopped because you switched away from the live-sharing panel.');
  if (setup && lookupTimer) { clearInterval(lookupTimer); lookupTimer=null; $('startLiveFollow')?.classList.remove('hidden'); $('stopLiveFollow')?.classList.add('hidden'); if ($('lookupLiveStatus')) $('lookupLiveStatus').textContent='Auto-refresh is off.'; }
  if (!setup) setTimeout(() => { if ($('lookupResult')?.classList.contains('hidden') === false) refreshMapSizes(); }, 150);
}
document.querySelectorAll('[data-locator-mode]').forEach(btn => btn.addEventListener('click', () => setLocatorMode(btn.dataset.locatorMode)));

function initMap(id, options = {}) {
  const holder = $(id); if (!holder || !window.L) { if (holder) holder.innerHTML = '<div class="map-fallback">Map requires internet access to load.</div>'; return null; }
  if (maps[id]) return maps[id];
  const map = L.map(holder, { scrollWheelZoom: false, zoomControl: true }).setView([24.8607, 67.0011], options.zoom || 5);
  L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19, attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap contributors</a>'
  }).addTo(map);
  maps[id] = map;
  if (options.pick) map.on('click', event => {
    pickedLocation = { lat: event.latlng.lat, lon: event.latlng.lng };
    $('locationStatus').textContent = `Location selected; public marker will be approximate (${event.latlng.lat.toFixed(3)}, ${event.latlng.lng.toFixed(3)}).`;
    updatePickMarker();
  });
  return map;
}
function refreshMapSizes() { setTimeout(() => Object.values(maps).forEach(map => { try { map.invalidateSize(); } catch {} }), 180); }
function updatePickMarker() {
  const map = maps.reportMiniMap; if (!map || !pickedLocation) return;
  if (map._findsurePick) map.removeLayer(map._findsurePick);
  map._findsurePick = L.circleMarker([pickedLocation.lat, pickedLocation.lon], { radius:9, color:'#fff', weight:3, fillColor:'#345cf5', fillOpacity:1 }).addTo(map);
  map.setView([pickedLocation.lat, pickedLocation.lon], Math.max(map.getZoom(), 13));
}
function typeEmoji(type) { return ({phone:'📱',laptop:'💻',tablet:'📱',desktop:'🖥️',camera:'📷',watch:'⌚',headphones:'🎧',bike:'🏍️',car:'🚗',keys:'🔑',bag:'🎒',documents:'📄','other-electronics':'🔌',other:'📦'})[type] || '📦'; }
function listingBadge(listingType) { return listingType === 'found' ? '<span class="badge found">Found item</span>' : '<span class="badge lost">Lost item</span>'; }
function dateLabel(value) { try { return new Intl.DateTimeFormat(undefined,{dateStyle:'medium'}).format(new Date(value)); } catch { return 'Recently'; } }
function mapLink(lat, lon, zoom = 16) { return `https://www.openstreetmap.org/?mlat=${encodeURIComponent(lat)}&mlon=${encodeURIComponent(lon)}#map=${zoom}/${encodeURIComponent(lat)}/${encodeURIComponent(lon)}`; }
function hasCoordinates(report) { return report.lat !== null && report.lat !== undefined && report.lon !== null && report.lon !== undefined && String(report.lat) !== '' && String(report.lon) !== '' && Number.isFinite(Number(report.lat)) && Number.isFinite(Number(report.lon)); }
function distanceKm(a,b) {
  const rad = n => n * Math.PI / 180;
  const dLat = rad(Number(b.lat)-Number(a.lat)), dLon=rad(Number(b.lon)-Number(a.lon));
  const x=Math.sin(dLat/2)**2+Math.cos(rad(Number(a.lat)))*Math.cos(rad(Number(b.lat)))*Math.sin(dLon/2)**2;
  return 6371*2*Math.atan2(Math.sqrt(x),Math.sqrt(Math.max(0,1-x)));
}
function updateNearMeButton() {
  const button=$('nearMeButton'); if(!button)return;
  button.classList.toggle('near-me-active',Boolean(nearbyOrigin));
  button.textContent=nearbyOrigin?'⌖ Nearby: on':'⌖ Near me';
  button.setAttribute('aria-pressed',String(Boolean(nearbyOrigin)));
}

function reportCard(report) {
  const status = report.status === 'resolved' ? '<span class="badge resolved">Recovered</span>' : '';
  const location = [report.area, report.city].filter(Boolean).join(', ');
  const contact = report.shareContact && report.contact ? `<div class="contact-line">Contact: ${escapeHtml(report.contact)}</div>` : '';
  const hasLocation = hasCoordinates(report);
  const mapA = hasLocation ? `<a class="card-map-link" href="${mapLink(report.lat, report.lon, 12)}" target="_blank" rel="noopener noreferrer">⌖ View approximate area ↗</a>` : '';
  const manage = report.status !== 'resolved' ? `<button class="mark-recovered" data-close-report="${escapeHtml(report.id)}">Mark recovered</button>` : '';
  const abuse = `<button class="report-concern" data-abuse-report="${escapeHtml(report.id)}">Report concern</button>`;
  return `<article class="listing-card" data-report-card="${escapeHtml(report.id)}"><div class="card-top"><span class="item-emoji">${typeEmoji(report.itemType)}</span><div class="badges">${listingBadge(report.listingType)}${status}</div><span class="card-date">${dateLabel(report.createdAt)}</span></div><h3>${escapeHtml(report.title)}</h3><div class="card-meta">${escapeHtml(itemLabels[report.itemType] || 'Other item')} <span>·</span> ${escapeHtml(location || 'Area not given')}</div><p class="card-description">${escapeHtml(report.description || 'No extra description provided.')}</p>${report.identifier ? `<p class="card-identifier"><b>Details:</b> ${escapeHtml(report.identifier)}</p>` : ''}${contact}<div class="card-foot"><span>Community listing</span>${mapA}<button class="share-report" type="button" data-share-report="${escapeHtml(report.id)}">Share</button>${manage}${abuse}</div></article>`;
}
function bindReportActions(container) {
  container.querySelectorAll('[data-close-report]').forEach(button => button.addEventListener('click', async () => {
    const savedCodes = JSON.parse(localStorage.getItem('findsure-owner-codes') || '{}');
    const ownerCode = prompt('Enter the private management code shown when this report was submitted:', savedCodes[button.dataset.closeReport] || '');
    if (!ownerCode) return;
    try { await api('/api/reports/close', {method:'POST', body:JSON.stringify({id:button.dataset.closeReport, ownerCode})}); delete savedCodes[button.dataset.closeReport]; localStorage.setItem('findsure-owner-codes', JSON.stringify(savedCodes)); toast('Report marked as recovered.'); await loadReports(); }
    catch (e) { toast(e.message); }
  }));
  container.querySelectorAll('[data-share-report]').forEach(button => button.addEventListener('click', async () => {
    const id = button.dataset.shareReport;
    const report = [...publicReports, ...allReports].find(r => r.id === id);
    if (!report) return toast('This public report could not be found.');
    const url = `${location.origin}/?report=${encodeURIComponent(id)}#browse`;
    const shareData = { title: `FindSure: ${report.title}`, text: `${report.listingType === 'found' ? 'Found' : 'Lost'} ${itemLabels[report.itemType] || 'item'} · ${[report.area, report.city].filter(Boolean).join(', ')}`, url };
    try {
      if (navigator.share) await navigator.share(shareData);
      else { await navigator.clipboard.writeText(url); toast('Share link copied.'); }
    } catch (error) {
      if (error.name !== 'AbortError') { try { await navigator.clipboard.writeText(url); toast('Share link copied.'); } catch { prompt('Copy this share link:', url); } }
    }
  }));
  container.querySelectorAll('[data-abuse-report]').forEach(button => button.addEventListener('click', async () => {
    const choices = 'scam, personal-info, wrong-category, suspected-stolen, other';
    const reason = prompt(`What is the concern? Enter one of: ${choices}`, 'other');
    if (!reason) return;
    const details = prompt('Optional details (do not include private information):', '') || '';
    button.disabled = true;
    try { const result = await api('/api/abuse',{method:'POST',body:JSON.stringify({reportId:button.dataset.abuseReport,reason:reason.trim().toLowerCase(),details})}); toast(result.message); }
    catch (e) { toast(e.message); }
    finally { button.disabled = false; }
  }));
}
function drawListingMarkers(reports) {
  Object.entries(maps).filter(([id]) => ['mainMap','browseMap'].includes(id)).forEach(([id,map]) => {
    if (mapPins[id]) mapPins[id].forEach(pin => map.removeLayer(pin)); mapPins[id] = [];
    const mapReports = id === 'browseMap' ? allReports : publicReports;
    const located = mapReports.filter(hasCoordinates);
    located.forEach(r => {
      const pin = L.circleMarker([Number(r.lat),Number(r.lon)], { radius:8, color:'#fff', weight:2, fillColor:r.listingType === 'found' ? '#11a77b' : '#345cf5', fillOpacity:.95 }).addTo(map);
      pin.bindPopup(`<div class="map-popup"><b>${escapeHtml(r.title)}</b><p>${escapeHtml(itemLabels[r.itemType] || 'Other item')} · ${escapeHtml(r.city)}</p><span>${r.listingType === 'found' ? 'Found item' : 'Lost item'}</span></div>`);
      pin.on('click', () => { if (id === 'mainMap') { showView('browse'); } }); mapPins[id].push(pin);
    });
    if (located.length) {
      const bounds = L.latLngBounds(located.map(r => [Number(r.lat), Number(r.lon)]));
      if (located.length === 1) map.setView(bounds.getCenter(), Math.max(map.getZoom(), 11)); else map.fitBounds(bounds.pad(.16), {maxZoom:11});
    }
  });
}
function updateStats(reports) {
  if ($('totalCount')) $('totalCount').textContent = reports.length.toLocaleString();
  if ($('mappedCount')) $('mappedCount').textContent = reports.filter(hasCoordinates).length.toLocaleString();
  if ($('resolvedCount')) $('resolvedCount').textContent = reports.filter(r => r.status === 'resolved').length.toLocaleString();
}
async function loadReports() {
  try {
    const data = await api('/api/reports');
    publicReports = data.reports || [];
    updateStats(publicReports);
    const searching = $('view-browse').classList.contains('active');
    const query = ($('searchInput')?.value || '').trim().toLowerCase();
    const kind = $('kindFilter')?.value || 'all';
    const type = $('typeFilter')?.value || 'all';
    const city = ($('cityFilter')?.value || '').trim().toLowerCase();
    allReports = searching ? publicReports.filter(r =>
      (kind === 'all' || r.listingType === kind) && (type === 'all' || r.itemType === type) &&
      (!city || `${r.city} ${r.area}`.toLowerCase().includes(city)) &&
      (!query || [r.title,r.description,r.identifier,r.city,r.area,r.itemType,r.listingType].join(' ').toLowerCase().includes(query))
    ) : publicReports;
    if (nearbyOrigin) {
      allReports = [...allReports].sort((a,b) => {
        const da=hasCoordinates(a)?distanceKm(nearbyOrigin,a):Infinity;
        const db=hasCoordinates(b)?distanceKm(nearbyOrigin,b):Infinity;
        return da-db;
      });
    }
    const recent = [...publicReports].slice(0, 4);
    $('recentReports').innerHTML = recent.length ? recent.map(reportCard).join('') : '<div class="empty-state v11-empty"><span>⌕</span><b>No community reports yet</b><p>FindSure only shows items people have reported here. This is not a search of private phone, police or telecom databases. You can post the first report for your area.</p><button class="button primary" data-goto="create" data-report-type="lost">Post a lost-item report</button></div>';
    const all = $('allReports');
    if (all) {
      all.innerHTML = allReports.length ? allReports.map(reportCard).join('') : '<div class="empty-state v11-empty"><span>⌕</span><b>No matching reports</b><p>Try another spelling, category or area. If your item is not listed, post a lost-item report so the community can help.</p><button class="button primary" data-goto="create" data-report-type="lost">Report my missing item</button></div>';
      $('resultCount').textContent = `${allReports.length} listing${allReports.length === 1 ? '' : 's'} found${nearbyOrigin?' · sorted by approximate distance':''}`;
      all.querySelectorAll('[data-goto]').forEach(button => button.addEventListener('click', () => { if (button.dataset.reportType && $('listingType')) $('listingType').value = button.dataset.reportType; showView(button.dataset.goto); }));
      bindReportActions(all);
    }
    $('recentReports').querySelectorAll('[data-goto]').forEach(button => button.addEventListener('click', () => { if (button.dataset.reportType && $('listingType')) $('listingType').value = button.dataset.reportType; showView(button.dataset.goto); }));
    bindReportActions($('recentReports'));
    drawListingMarkers(allReports);
    const mapPanel = $('browseMapPanel');
    if (mapPanel) mapPanel.classList.toggle('hidden', !allReports.some(hasCoordinates));
    const sharedId = new URLSearchParams(location.search).get('report');
    if (sharedId && $('view-browse')?.classList.contains('active')) {
      const target = [...($('allReports')?.querySelectorAll('[data-report-card]') || [])].find(card => card.dataset.reportCard === sharedId);
      if (target) { target.classList.add('shared-highlight'); target.scrollIntoView({ behavior:'smooth', block:'center' }); }
    }
  } catch (error) {
    $('apiStatus').textContent = 'Offline';
    if ($('allReports')) $('allReports').innerHTML = `<div class="empty-state"><b>Could not load listings</b><p>${escapeHtml(error.message)}</p></div>`;
  }
}
let searchTimer;
['searchInput','kindFilter','typeFilter','cityFilter'].forEach(id => $(id)?.addEventListener(id.includes('Filter') ? 'change' : 'input', () => {
  clearTimeout(searchTimer); searchTimer = setTimeout(loadReports, 220);
}));
$('clearFilters').addEventListener('click', () => { $('searchInput').value=''; $('kindFilter').value='all'; $('typeFilter').value='all'; $('cityFilter').value=''; nearbyOrigin=null; updateNearMeButton(); loadReports(); });
$('nearMeButton')?.addEventListener('click',async()=>{
  if(nearbyOrigin){nearbyOrigin=null;updateNearMeButton();await loadReports();toast('Nearby sorting turned off.');return;}
  const button=$('nearMeButton');button.disabled=true;button.textContent='Getting location…';
  try {
    const point=await getBrowserLocation(0); nearbyOrigin={lat:point.lat,lon:point.lon}; updateNearMeButton();
    await loadReports(); toast('Nearby sorting is on. Location stays in this browser; map points are approximate.');
  } catch(error) { toast(error.message); updateNearMeButton(); }
  finally {button.disabled=false;updateNearMeButton();}
});

function getBrowserLocation(maximumAge = 30000) {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) return reject(new Error('This browser does not support geolocation.'));
    navigator.geolocation.getCurrentPosition(
      pos => resolve({lat:pos.coords.latitude, lon:pos.coords.longitude, accuracy:pos.coords.accuracy}),
      error => reject(new Error(error.code === 1 ? 'Location permission was denied. Enable it in browser settings.' : error.code === 2 ? 'Location is unavailable. Check GPS/location settings.' : 'Location request timed out. Try again.')),
      {enableHighAccuracy:true, timeout:15000, maximumAge}
    );
  });
}
function currentDeviceTimeZone() { try { return Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC'; } catch { return 'UTC'; } }
function livePayload(code, loc) { return {code:String(code||'').trim(),lat:loc.lat,lon:loc.lon,accuracy:loc.accuracy,capturedAt:new Date().toISOString(),timeZone:currentDeviceTimeZone()}; }
function readOfflineQueue() { try { const q=JSON.parse(localStorage.getItem(OFFLINE_QUEUE_KEY)||'[]'); return Array.isArray(q)?q:[]; } catch { return []; } }
function updateOfflineQueueStatus() { const n=readOfflineQueue().length; const el=$('offlineQueueText'); if(el) el.textContent=n?`${n} location snapshot(s) waiting for internet`:'No offline location snapshots waiting.'; const clear=$('clearOfflineQueue'); if(clear) clear.classList.toggle('hidden',n===0); }
function queueOfflineCheckin(payload) {
  // Keep only the newest queued point per device code; this is not a route-history tracker.
  const q=readOfflineQueue().filter(item=>item.code!==payload.code); q.push(payload);
  localStorage.setItem(OFFLINE_QUEUE_KEY,JSON.stringify(q.slice(-10))); updateOfflineQueueStatus();
}
async function postLocationOrQueue(payload) {
  try {
    if(!navigator.onLine) throw new TypeError('No network connection.');
    return {queued:false,result:await api('/api/devices/check-in',{method:'POST',body:JSON.stringify(payload)})};
  } catch(error) {
    if(error instanceof TypeError || !navigator.onLine) { queueOfflineCheckin(payload); return {queued:true,error}; }
    throw error;
  }
}
async function syncPendingCheckins() {
  if(!navigator.onLine) { updateOfflineQueueStatus(); return; }
  for(const item of readOfflineQueue()) {
    try {
      await api('/api/devices/check-in',{method:'POST',body:JSON.stringify(item)});
      const rest=readOfflineQueue().filter(x=>!(x.code===item.code&&x.capturedAt===item.capturedAt));
      localStorage.setItem(OFFLINE_QUEUE_KEY,JSON.stringify(rest));
    } catch { break; }
  }
  updateOfflineQueueStatus();
}
function readOfflineReportQueue() { try { const q=JSON.parse(localStorage.getItem(OFFLINE_REPORT_QUEUE_KEY)||'[]'); return Array.isArray(q)?q:[]; } catch { return []; } }
function readOfflineReportHistory() { try { const q=JSON.parse(localStorage.getItem(OFFLINE_REPORT_HISTORY_KEY)||'[]'); return Array.isArray(q)?q:[]; } catch { return []; } }
function writeOfflineReportQueue(rows) { localStorage.setItem(OFFLINE_REPORT_QUEUE_KEY,JSON.stringify(rows.slice(-15))); }
function writeOfflineReportHistory(rows) { localStorage.setItem(OFFLINE_REPORT_HISTORY_KEY,JSON.stringify(rows.slice(-8))); }
function offlineDraftId() { return (window.crypto && typeof window.crypto.randomUUID === 'function' ? window.crypto.randomUUID() : `draft-${Date.now()}-${Math.random().toString(16).slice(2)}`); }
function resetReportFormAfterLocalSave() {
  $('reportForm').reset(); pickedLocation=null; $('locationStatus').textContent='No location attached';
  if (maps.reportMiniMap?._findsurePick) maps.reportMiniMap.removeLayer(maps.reportMiniMap._findsurePick);
  if (maps.reportMiniMap) maps.reportMiniMap.setView([24.8607,67.0011],5);
}
function saveOfflineReportDraft(body) {
  const queue=readOfflineReportQueue();
  if (queue.length >= 15) throw new Error('Your browser already has 15 unsent reports. Sync or delete one before saving another.');
  const entry={id:offlineDraftId(),body,queuedAt:new Date().toISOString(),lastError:''};
  queue.push(entry); writeOfflineReportQueue(queue); renderOfflineReportQueue(); return entry;
}
function renderOfflineReportQueue() {
  const panel=$('offlineReportQueuePanel'), list=$('offlineReportQueueList'); if(!panel||!list)return;
  const queue=readOfflineReportQueue(), history=readOfflineReportHistory();
  panel.classList.toggle('hidden',queue.length===0&&history.length===0);
  if (!queue.length&&!history.length) { list.innerHTML=''; return; }
  const pendingHtml=queue.map(item=>`<article class="offline-report-entry"><span class="offline-report-entry-state pending">Waiting for internet</span><div><b>${escapeHtml(item.body?.title||'Untitled report')}</b><p>${escapeHtml([item.body?.city,item.body?.area].filter(Boolean).join(' · ')||'Area not supplied')} · Saved ${escapeHtml(dateLabel(item.queuedAt))}</p>${item.lastError?`<small>${escapeHtml(item.lastError)}</small>`:''}</div><button class="text-link" type="button" data-delete-offline-report="${escapeHtml(item.id)}">Delete draft</button></article>`).join('');
  const historyHtml=history.map(item=>`<article class="offline-report-entry"><span class="offline-report-entry-state synced">Submitted</span><div><b>${escapeHtml(item.title||'Report')}</b><p>${escapeHtml(item.city||'')} · Sent ${escapeHtml(dateLabel(item.submittedAt))}</p><small>Your private code is saved only in this browser: <code>${escapeHtml(item.ownerCode||'Unavailable')}</code></small></div><button class="text-link" type="button" data-copy-offline-code="${escapeHtml(item.id)}">Copy code</button></article>`).join('');
  list.innerHTML=pendingHtml+historyHtml;
  list.querySelectorAll('[data-delete-offline-report]').forEach(btn=>btn.addEventListener('click',()=>{ if(!confirm('Delete this unsent local draft? It has not been uploaded.'))return; writeOfflineReportQueue(readOfflineReportQueue().filter(x=>x.id!==btn.dataset.deleteOfflineReport)); renderOfflineReportQueue(); toast('Local draft deleted.'); }));
  list.querySelectorAll('[data-copy-offline-code]').forEach(btn=>btn.addEventListener('click',async()=>{const item=readOfflineReportHistory().find(x=>x.id===btn.dataset.copyOfflineCode); if(!item?.ownerCode)return; try{await navigator.clipboard.writeText(item.ownerCode);toast('Private report code copied.');}catch{prompt('Copy this private report code:',item.ownerCode);}}));
  const clear=$('clearOfflineReportDrafts'); if(clear) clear.classList.toggle('hidden',queue.length===0);
}
async function syncPendingReports() {
  if (syncingOfflineReports || !navigator.onLine) { renderOfflineReportQueue(); return; }
  syncingOfflineReports=true;
  try {
    const original=readOfflineReportQueue();
    for (const item of original) {
      if (!navigator.onLine) break;
      try {
        const data=await api('/api/reports',{method:'POST',body:JSON.stringify(item.body)});
        const savedCodes=JSON.parse(localStorage.getItem('findsure-owner-codes')||'{}'); savedCodes[data.report.id]=data.ownerCode; localStorage.setItem('findsure-owner-codes',JSON.stringify(savedCodes));
        const history=readOfflineReportHistory(); history.unshift({id:item.id,title:item.body.title,city:item.body.city,reportId:data.report.id,ownerCode:data.ownerCode,submittedAt:new Date().toISOString()}); writeOfflineReportHistory(history);
        writeOfflineReportQueue(readOfflineReportQueue().filter(x=>x.id!==item.id));
        toast(`Saved report submitted: ${item.body.title}. Private code is shown below.`);
      } catch (error) {
        if (error instanceof TypeError || !navigator.onLine) break;
        const queue=readOfflineReportQueue().map(x=>x.id===item.id?{...x,lastError:error.message}:x); writeOfflineReportQueue(queue);
        break;
      }
    }
  } finally { syncingOfflineReports=false; renderOfflineReportQueue(); }
}
$('syncOfflineReportsButton')?.addEventListener('click',syncPendingReports);
$('clearOfflineReportDrafts')?.addEventListener('click',()=>{const q=readOfflineReportQueue();if(!q.length)return;if(confirm('Delete all unsent report drafts from this browser? This cannot be undone.')){localStorage.removeItem(OFFLINE_REPORT_QUEUE_KEY);renderOfflineReportQueue();toast('Unsent local reports cleared.');}});
window.addEventListener('online',()=>{ syncPendingReports(); toast('Internet detected. Syncing saved reports and location snapshots.'); });
window.addEventListener('storage',event=>{if([OFFLINE_REPORT_QUEUE_KEY,OFFLINE_REPORT_HISTORY_KEY].includes(event.key))renderOfflineReportQueue();});

function locationTimeLabel(loc) {
  const t=loc.capturedAt||loc.updatedAt; const zone=loc.timeZone||'UTC';
  try { return new Intl.DateTimeFormat('en-GB',{dateStyle:'medium',timeStyle:'medium',timeZone:zone}).format(new Date(t)); }
  catch { return new Date(t).toLocaleString(); }
}
function renderLocatedDevice(device) {
  const direct = device?.lastLocation || null;
  const sighting = device?.lastBeaconSighting || null;
  const ble = sighting ? { lat:sighting.lat, lon:sighting.lon, accuracy:sighting.accuracy, capturedAt:sighting.capturedAt, gpsCapturedAt:sighting.gpsCapturedAt, updatedAt:sighting.receivedAt, timeZone:sighting.timeZone, timeZoneName:sighting.timeZoneName, timeZoneSource:sighting.timeZoneSource, source:'community-ble' } : null;
  const candidates = [direct && {...direct, source:'owner-gps'}, ble].filter(Boolean).sort((a,b)=>Date.parse(b.capturedAt||b.updatedAt||0)-Date.parse(a.capturedAt||a.updatedAt||0));
  const loc = candidates[0] || null, result=$('lookupResult');
  if(maps.deviceLookupMap) { try { maps.deviceLookupMap.remove(); } catch {} delete maps.deviceLookupMap; }
  result.classList.remove('hidden');
  if(!loc) { result.innerHTML=`<b>${escapeHtml(device?.label||'Device')}</b><p>No location has been shared or detected by the FindSure network yet.</p><p>For a device already missing, try its official recovery service above. For future BLE-network support, prepare the device and trusted finder phones in advance.</p>`; return; }
  const captured=loc.capturedAt||loc.updatedAt; const age=Math.max(0,Date.now()-new Date(captured).getTime());
  const freshness=age<120000?'Recent location reading':`Last reading ${Math.floor(age/60000)} minute(s) ago`;
  const zoneSource=loc.timeZoneSource==='approximate-nearest-city'?'Timezone estimated from the approximate nearest-city service':loc.timeZoneSource==='device-timezone-fallback'?'Device timezone fallback; location timezone could not be verified':'UTC fallback';
  const sourceCopy=loc.source==='community-ble' ? `<div class="recovery-warning"><b>Community Bluetooth sighting</b><p>A participating FindSure Android phone detected this device's rotating BLE beacon nearby. The map point is the finder phone's location at detection time—not GPS read directly from the missing device—and Bluetooth range/accuracy can vary.</p></div>` : `<p><b>Source:</b> Location shared by the registered device.</p>`;
  const gpsFixLine=loc.source==='community-ble'&&loc.gpsCapturedAt?`<p><b>Finder phone GPS fix captured:</b> ${escapeHtml(locationTimeLabel({capturedAt:loc.gpsCapturedAt,timeZone:loc.timeZone}))}</p>`:'';
  result.innerHTML=`<b>${escapeHtml(device.label)}</b><p><strong>${escapeHtml(freshness)}</strong></p><p><b>${loc.source==='community-ble'?'Bluetooth detection time':'Location captured'}:</b> ${escapeHtml(locationTimeLabel(loc))} (${escapeHtml(loc.timeZone||'UTC')})</p>${gpsFixLine}<p><b>Received by server:</b> ${escapeHtml(locationTimeLabel({capturedAt:loc.updatedAt,timeZone:loc.timeZone}))} (${escapeHtml(loc.timeZone||'UTC')})</p><p>${escapeHtml(zoneSource)} · Reported GPS accuracy: ${loc.accuracy==null?'Not provided':`${Math.round(loc.accuracy)} metres`}</p>${sourceCopy}<a href="${mapLink(loc.lat,loc.lon)}" target="_blank" rel="noopener noreferrer">Open location in OpenStreetMap ↗</a><div id="deviceLookupMap" class="map-frame small-map"></div><div class="last-location-coords">${Number(loc.lat).toFixed(5)}, ${Number(loc.lon).toFixed(5)}</div>`;
  const map=initMap('deviceLookupMap',{zoom:14}); if(map) { if(map._findsureDevicePin) map.removeLayer(map._findsureDevicePin); map._findsureDevicePin=L.marker([Number(loc.lat),Number(loc.lon)]).addTo(map).bindPopup(loc.source==='community-ble'?'FindSure BLE beacon detected nearby':'Latest owner-shared location'); map.setView([Number(loc.lat),Number(loc.lon)],15); setTimeout(()=>map.invalidateSize(),120); }
}
async function lookupDevice(quiet=false) {
  const code=$('lookupCode').value.trim(); if(!$('lookupConsent')?.checked) { if(!quiet) toast('Please confirm you own this device or have permission to locate it.'); return; } if(!code) { if(!quiet) toast('Enter the private device code first.'); return; }
  if(lookupBusy) return; lookupBusy=true;
  try { const data=await api('/api/devices/locate',{method:'POST',body:JSON.stringify({code})}); renderLocatedDevice(data.device); $('lookupLiveStatus').textContent=lookupTimer?'Checking for a newer device location every minute.':'Auto-refresh is off.'; }
  catch(error) { if(!quiet) { $('lookupResult').classList.remove('hidden'); $('lookupResult').textContent=error.message; } }
  finally { lookupBusy=false; }
}
async function pushLivePosition(loc) {
  const code=$('checkinCode').value.trim(); if(!code) { stopLiveSharing('Enter the registered device code first.'); return; }
  const now=Date.now();
  if(now-liveLastSentAt<60_000) return;
  liveLastSentAt=now; liveLastCoords={lat:loc.lat,lon:loc.lon};
  try {
    const state=await postLocationOrQueue(livePayload(code,loc));
    $('liveShareStatus').textContent=state.queued?'Offline: newest GPS reading saved on this device; it will sync after internet returns.':`Sharing on this open page. Last sent ${new Date().toLocaleTimeString()}. Keep this page open.`;
  } catch(e) { $('liveShareStatus').textContent=e.message; }
}
function startLiveSharing() {
  if(liveWatchId!==null) return;
  if(!navigator.geolocation) {toast('This browser does not support location.');return;}
  if(!$('checkinCode').value.trim()) {toast('Enter the registered device code first.');$('checkinCode').focus();return;}
  if(!confirm('Start visible location sharing for this device? It sends location while this page stays open.')) return;
  liveLastSentAt=0; liveLastCoords=null; $('startLiveSharing').classList.add('hidden'); $('stopLiveSharing').classList.remove('hidden'); $('liveShareStatus').textContent='Requesting location permission…';
  liveWatchId=navigator.geolocation.watchPosition(pos=>pushLivePosition({lat:pos.coords.latitude,lon:pos.coords.longitude,accuracy:pos.coords.accuracy}),err=>{ $('liveShareStatus').textContent=err.code===1?'Location permission denied. Enable it in browser settings.':'Location update failed. Check GPS/location settings.'; },{enableHighAccuracy:true,maximumAge:10000,timeout:20000});
  livePushTimer=setInterval(async()=>{try{const loc=await getBrowserLocation(0);await pushLivePosition(loc);}catch(e){if($('liveShareStatus'))$('liveShareStatus').textContent=`Location refresh failed: ${e.message}`;}},60_000);
}
function stopLiveSharing(message='Location sharing stopped.') {
  if(liveWatchId!==null) navigator.geolocation.clearWatch(liveWatchId); liveWatchId=null; if(livePushTimer) clearInterval(livePushTimer); livePushTimer=null;
  $('startLiveSharing')?.classList.remove('hidden'); $('stopLiveSharing')?.classList.add('hidden'); if($('liveShareStatus')) $('liveShareStatus').textContent=message;
}
window.addEventListener('online',()=>{syncPendingCheckins();});
window.addEventListener('offline',()=>{if($('liveShareStatus')) $('liveShareStatus').textContent='Offline. A new location may be saved locally, but remote users cannot see it yet.';});
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible'){syncPendingCheckins();syncPendingReports();}});
$('useCurrentLocation').addEventListener('click', async () => {
  $('locationStatus').textContent = 'Requesting permission…';
  try { const location = await getBrowserLocation(); pickedLocation = {lat:location.lat, lon:location.lon}; $('locationStatus').textContent = 'Location attached. The public map uses an approximate location.'; updatePickMarker(); toast('Approximate map location attached.'); }
  catch (e) { $('locationStatus').textContent = e.message; toast(e.message); }
});
$('reportMiniMap').addEventListener('keydown', () => {});
async function findPossibleMatches(reportBody) {
  const opposite = reportBody.listingType === 'lost' ? 'found' : 'lost';
  const params = new URLSearchParams({kind:opposite,type:reportBody.itemType,city:reportBody.city});
  try {
    const data = await api(`/api/reports?${params.toString()}`);
    const tokens = `${reportBody.title} ${reportBody.identifier||''} ${reportBody.description||''}`.toLowerCase().split(/[^a-z0-9]+/).filter(w=>w.length>=4);
    return (data.reports||[]).filter(r=>r.status!=='resolved').map(r=>{
      const text=`${r.title} ${r.description||''} ${r.identifier||''} ${r.area||''}`.toLowerCase();
      const score=tokens.reduce((sum,word)=>sum+(text.includes(word)?1:0),0);
      return {...r,_matchScore:score};
    }).sort((a,b)=>b._matchScore-a._matchScore);
  } catch { return null; }
}
function applyPossibleMatchFilters() {
  if(!possibleMatchSearch)return;
  $('kindFilter').value=possibleMatchSearch.kind;
  $('typeFilter').value=possibleMatchSearch.type;
  $('cityFilter').value=possibleMatchSearch.city;
  $('searchInput').value='';
  if($('reportOwnerDialog').open)$('reportOwnerDialog').close();
  showView('browse'); loadReports();
  $('viewPotentialMatches').classList.add('hidden');
  $('ownerDialogMatchMessage').classList.add('hidden');
}
$('viewPotentialMatches')?.addEventListener('click',applyPossibleMatchFilters);

$('reportForm').addEventListener('submit', async event => {
  event.preventDefault(); $('reportFormError').textContent = '';
  const submit = event.submitter; if (submit) {submit.disabled=true;submit.textContent='Submitting…';}
  if (!activeReportSubmissionId) activeReportSubmissionId=newReportSubmissionId();
  newOwnerCode=''; newReportId='';
  const body = {
    clientSubmissionId:activeReportSubmissionId,
    listingType:$('listingType').value, itemType:$('itemType').value, title:$('reportTitle').value.trim(),
    city:$('reportCity').value.trim(), area:$('reportArea').value.trim(), identifier:$('reportIdentifier').value.trim(),
    description:$('reportDescription').value.trim(), contact:$('reportContact').value.trim(), shareContact:$('shareContact').checked,
    ...(pickedLocation ? {lat:pickedLocation.lat, lon:pickedLocation.lon} : {})
  };
  try {
    pendingReportDraftBody=null; $('saveReportOfflineButton')?.classList.add('hidden');
    const data = await api('/api/reports', {method:'POST', body:JSON.stringify(body)});
    newOwnerCode=data.ownerCode; newReportId=data.report.id; activeReportSubmissionId='';
    const savedOwnerCodes = JSON.parse(localStorage.getItem('findsure-owner-codes') || '{}'); savedOwnerCodes[newReportId] = newOwnerCode; localStorage.setItem('findsure-owner-codes', JSON.stringify(savedOwnerCodes));
    $('ownerDialogMessage').textContent=data.message;
    $('ownerDialogCode').textContent=data.ownerCode;
    $('ownerDialogMatchMessage').classList.add('hidden'); $('viewPotentialMatches').classList.add('hidden'); possibleMatchSearch=null;
    const matches = await findPossibleMatches(body);
    $('ownerDialogMatchMessage').classList.remove('hidden');
    if (matches && matches.length) {
      possibleMatchSearch={kind:body.listingType==='lost'?'found':'lost',type:body.itemType,city:body.city};
      $('ownerDialogMatchMessage').textContent=`${matches.length} possible ${possibleMatchSearch.kind} listing(s) in ${body.city} share this item category. These are suggestions only—check details and ownership before contacting anyone.`;
      $('viewPotentialMatches').classList.remove('hidden');
    } else if (matches) {
      $('ownerDialogMatchMessage').textContent='No close same-category listings were found in this city yet. Your report is saved; you can search again later.';
    } else {
      $('ownerDialogMatchMessage').textContent='Your report was saved, but possible matches could not be checked just now. You can browse reports later.';
    }
    $('reportOwnerDialog').showModal();
    $('reportForm').reset(); pickedLocation=null; $('locationStatus').textContent='No location attached'; if (maps.reportMiniMap?._findsurePick) maps.reportMiniMap.removeLayer(maps.reportMiniMap._findsurePick); if (maps.reportMiniMap) maps.reportMiniMap.setView([24.8607,67.0011],5);
    await loadReports(); showView('browse');
  } catch (error) {
    // If the API already accepted the report, never queue a second copy because a later UI step failed.
    if (newReportId && newOwnerCode) {
      $('reportFormError').textContent=`Your report was already saved. Do not submit it again. Keep this private report code: ${newOwnerCode}. A follow-up screen update failed: ${error.message}`;
      $('ownerDialogMessage').textContent='Your report was saved successfully. Keep the private code below to manage it.';
      $('ownerDialogCode').textContent=newOwnerCode;
      if (!$('reportOwnerDialog').open) $('reportOwnerDialog').showModal();
      activeReportSubmissionId='';
    } else if (!navigator.onLine) {
      try {
        const draft=saveOfflineReportDraft(body);
        $('reportFormError').textContent='Internet is unavailable. Your report is saved only in this browser and is not public yet. It will sync when internet returns.';
        $('saveReportOfflineButton')?.classList.add('hidden'); resetReportFormAfterLocalSave(); pendingReportDraftBody=null; activeReportSubmissionId=''; toast('Report saved locally. It has not been shared publicly.');
      } catch (storageError) { $('reportFormError').textContent=`Could not save a local report draft: ${storageError.message}`; }
    } else {
      if (error instanceof TypeError) {
        pendingReportDraftBody=body;
        $('saveReportOfflineButton')?.classList.remove('hidden');
        $('reportFormError').textContent='The server could not be reached. You can try again or save this report locally for later sync.';
      } else $('reportFormError').textContent=error.message;
    }
  }
  finally { if (submit) {submit.disabled=false;submit.innerHTML='Submit report <span>→</span>';} }
});
$('saveReportOfflineButton')?.addEventListener('click',()=>{
  if(!pendingReportDraftBody)return;
  try { saveOfflineReportDraft(pendingReportDraftBody); pendingReportDraftBody=null; activeReportSubmissionId=''; $('saveReportOfflineButton').classList.add('hidden'); $('reportFormError').textContent='Saved in this browser only. The report is not public until it syncs successfully.'; resetReportFormAfterLocalSave(); toast('Offline report draft saved.'); }
  catch(error) { $('reportFormError').textContent=error.message; }
});
$('closeOwnerDialog').addEventListener('click', () => $('reportOwnerDialog').close());
$('copyOwnerCode').addEventListener('click', async () => { try { await navigator.clipboard.writeText(newOwnerCode); toast('Private code copied. Save it securely.'); } catch { prompt('Copy and save this private code:',newOwnerCode); } });
$('reportOwnerDialog').addEventListener('click', event => { if (event.target === $('reportOwnerDialog')) $('reportOwnerDialog').close(); });

function renderMyReport(report) {
  const result = $('myReportsResult');
  const statusLabels = { pending:'Waiting for moderator review', published:'Publicly listed', resolved:'Marked as recovered', rejected:'Not approved for public listing' };
  result.classList.remove('hidden');
  result.innerHTML = `<div class="my-report-result-head"><span class="item-emoji">${typeEmoji(report.itemType)}</span><div><b>${escapeHtml(report.title)}</b><p>${escapeHtml([report.area,report.city].filter(Boolean).join(', '))}</p></div><span class="badge ${report.status==='resolved'?'resolved':report.status==='published'?'found':'lost'}">${escapeHtml(statusLabels[report.status]||report.status)}</span></div><p>${escapeHtml(report.description||'No extra description provided.')}</p><p><b>Report type:</b> ${report.listingType==='found'?'Found item':'Lost item'} · <b>Category:</b> ${escapeHtml(itemLabels[report.itemType]||report.itemType)}</p><p><b>Submitted:</b> ${escapeHtml(dateLabel(report.createdAt))}</p><div class="my-report-actions">${report.status!=='resolved'?'<button id="resolveMyReport" type="button" class="button primary">Mark item as recovered</button>':''}<button id="deleteMyReport" type="button" class="button light danger-button">Delete this report</button></div><p class="muted-note">This private code controls this report only. Keep it safe.</p>`;
  const del = $('deleteMyReport');
  if (del) del.addEventListener('click', async () => {
    const code=$('myReportCode').value.trim();
    if(!confirm('Permanently delete this report from FindSure? This cannot be undone.'))return;
    del.disabled=true;
    try { await api('/api/reports/delete',{method:'POST',body:JSON.stringify({id:report.id,ownerCode:code})}); $('myReportsResult').classList.add('hidden'); $('myReportCode').value=''; toast('Your report was deleted.'); await loadReports(); }
    catch(error){toast(error.message);del.disabled=false;}
  });
  const close = $('resolveMyReport');
  if (close) close.addEventListener('click', async () => {
    const code = $('myReportCode').value.trim();
    if (!confirm('Mark this item as recovered? It will no longer be shown as an active lost/found listing.')) return;
    close.disabled = true;
    try {
      await api('/api/reports/close',{method:'POST',body:JSON.stringify({id:report.id,ownerCode:code})});
      toast('Report marked as recovered.');
      const refreshed = await api('/api/reports/mine',{method:'POST',body:JSON.stringify({ownerCode:code})});
      renderMyReport(refreshed.report); await loadReports();
    } catch(error) { toast(error.message); close.disabled=false; }
  });
}
$('myReportsForm')?.addEventListener('submit', async event => {
  event.preventDefault(); const button=event.submitter; const result=$('myReportsResult');
  if(button){button.disabled=true;button.textContent='Loading report…';}
  result.classList.add('hidden');
  try { const data=await api('/api/reports/mine',{method:'POST',body:JSON.stringify({ownerCode:$('myReportCode').value.trim()})}); renderMyReport(data.report); }
  catch(error) { result.classList.remove('hidden'); result.textContent=error.message; }
  finally { if(button){button.disabled=false;button.textContent='View my report';} }
});

$('deviceRegisterForm').addEventListener('submit', async event => {
  event.preventDefault(); const button=event.submitter; button.disabled=true; button.textContent='Registering…'; $('registeredResult').classList.add('hidden');
  try {
    const data=await api('/api/devices/register',{method:'POST',body:JSON.stringify({label:$('deviceLabel').value.trim()})});
    $('registeredResult').classList.remove('hidden'); $('registeredResult').innerHTML=`<b>Private device code</b><code class="large-code">${escapeHtml(data.device.code)}</code><p>${escapeHtml(data.message)}</p><p><b>Next:</b> use this code in the "Locate a registered device" box on your second phone or computer.</p><button id="copyDeviceCode" type="button" class="button light full-width">Copy code</button>`;
    $('checkinCode').value=data.device.code; $('lookupCode').value=data.device.code; $('tagOwnerCode').value=data.device.code; $('tagRevokeOwnerCode').value=data.device.code;
    $('copyDeviceCode').addEventListener('click',async()=>{try{await navigator.clipboard.writeText(data.device.code);toast('Code copied. Keep it private.');}catch{prompt('Save this private code:',data.device.code);}});
    toast('Device registered. Save the private code.');
  } catch(error) { $('registeredResult').classList.remove('hidden'); $('registeredResult').textContent=error.message; }
  finally {button.disabled=false;button.textContent='Create private device code';}
});
$('tagProvisionForm')?.addEventListener('submit', async event => {
  event.preventDefault();
  const button = event.submitter; const result = $('tagProvisionResult');
  button.disabled = true; button.textContent = 'Creating tag credential…'; result.classList.add('hidden');
  try {
    const data = await api('/api/beacon/tags/provision', {method:'POST', body:JSON.stringify({code:$('tagOwnerCode').value.trim(), label:$('tagLabel').value.trim()})});
    result.classList.remove('hidden');
    result.innerHTML = `<b>Tag-only credential created</b><p><b>Tag ID:</b> <code>${escapeHtml(data.tagId)}</code></p><p><b>Credential — shown once:</b></p><code class="tag-credential-value">${escapeHtml(data.credential)}</code><button id="copyTagCredential" type="button" class="button light full-width">Copy tag credential</button><p>${escapeHtml(data.message)}</p><p>BLE service UUID: <code>${escapeHtml(data.serviceUuid)}</code> · Rotation: ${escapeHtml(String(data.slotMinutes))} minutes.</p><p><b>Next:</b> Save the credential now, then use the hardware guide to configure a compatible separate tracker. This credential cannot look up the item's location.</p>`;
    $('tagRevokeOwnerCode').value = $('tagOwnerCode').value.trim(); $('tagRevokeId').value = data.tagId;
    $('copyTagCredential')?.addEventListener('click', async () => { try { await navigator.clipboard.writeText(data.credential); toast('Tag credential copied. Save it securely.'); } catch { prompt('Save this tag-only credential now:', data.credential); } });
    toast('Tag-only credential created. It is displayed only once.');
  } catch(error) { result.classList.remove('hidden'); result.textContent = error.message; }
  finally { button.disabled = false; button.textContent = 'Create tag credential'; }
});
$('tagRevokeForm')?.addEventListener('submit', async event => {
  event.preventDefault();
  const button = event.submitter; const result = $('tagRevokeResult');
  if (!confirm('Revoke this tag now? The server will reject its cached tag tokens. This cannot be undone.')) return;
  button.disabled = true; button.textContent = 'Revoking…'; result.classList.add('hidden');
  try {
    const data = await api('/api/beacon/tags/revoke', {method:'POST', body:JSON.stringify({code:$('tagRevokeOwnerCode').value.trim(), tagId:$('tagRevokeId').value.trim()})});
    result.classList.remove('hidden'); result.innerHTML = `<b>Tag revoked</b><p>${escapeHtml(data.message)}</p>`; toast('External beacon tag revoked.');
  } catch(error) { result.classList.remove('hidden'); result.textContent = error.message; }
  finally { button.disabled = false; button.textContent = 'Revoke this tag'; }
});

$('checkinCode')?.addEventListener('input', () => { if ($('tagOwnerCode') && !$('tagOwnerCode').value) $('tagOwnerCode').value=$('checkinCode').value; if ($('tagRevokeOwnerCode') && !$('tagRevokeOwnerCode').value) $('tagRevokeOwnerCode').value=$('checkinCode').value; });
$('deviceCheckinForm').addEventListener('submit', async event => {
  event.preventDefault(); const button=event.submitter; button.disabled=true; button.textContent='Getting location…'; $('checkinResult').classList.add('hidden');
  try {
    const loc=await getBrowserLocation(); const payload=livePayload($('checkinCode').value,loc); const state=await postLocationOrQueue(payload);
    $('checkinResult').classList.remove('hidden');
    if(state.queued) $('checkinResult').innerHTML=`<b>Location saved on this device (offline)</b><p>Captured: ${escapeHtml(new Date(payload.capturedAt).toLocaleString())}</p><p>It is not available remotely yet. It will upload when internet returns.</p>`;
    else { const saved=state.result.device.lastLocation; $('checkinResult').innerHTML=`<b>Location uploaded</b><p>Device: ${escapeHtml(state.result.device.label)}</p><p>Captured: ${escapeHtml(locationTimeLabel(saved))} (${escapeHtml(saved.timeZone||'UTC')})</p><p>Server upload: ${escapeHtml(new Date(saved.updatedAt).toLocaleString())}</p><a href="${mapLink(saved.lat,saved.lon)}" target="_blank" rel="noopener noreferrer">View location on map ↗</a>`; }
    $('lookupCode').value=$('checkinCode').value.trim(); await lookupDevice(true); toast(state.queued?'Saved offline; waiting for internet.':'Location check-in uploaded.');
  } catch(error) { $('checkinResult').classList.remove('hidden'); $('checkinResult').textContent=error.message; }
  finally {button.disabled=false;button.textContent='Share current location';}
});
$('clearOfflineQueue').addEventListener('click',()=>{if(!readOfflineQueue().length)return;if(confirm('Clear queued location snapshots stored in this browser?')){localStorage.removeItem(OFFLINE_QUEUE_KEY);updateOfflineQueueStatus();toast('Local offline snapshot queue cleared.');}});
$('startLiveSharing').addEventListener('click',startLiveSharing);
$('stopLiveSharing').addEventListener('click',()=>stopLiveSharing());
$('deviceLookupForm').addEventListener('submit',async event=>{event.preventDefault();await lookupDevice();});
// v7: vehicle tracker provisioning, telemetry lookup and revocation.
let vehicleRefreshTimer = null, vehicleLookupBusy = false;
function vehicleTimeLabel(position) {
  const zone=position.timeZone||'UTC';
  try { return new Intl.DateTimeFormat(undefined,{dateStyle:'medium',timeStyle:'medium',timeZone:zone}).format(new Date(position.capturedAt)); }
  catch { return new Date(position.capturedAt).toLocaleString(); }
}
function renderVehiclePosition(vehicle) {
  const result=$('vehicleLocateResult'), mapHolder=$('vehicleLocationMap');
  result.classList.remove('hidden');
  if (maps.vehicleLocationMap) { try { maps.vehicleLocationMap.remove(); } catch {} delete maps.vehicleLocationMap; }
  const pos=vehicle?.position;
  if(!pos) {
    mapHolder.classList.add('hidden');
    result.innerHTML=`<b>${escapeHtml(vehicle?.label||'Vehicle')}</b><p>No GPS position has reached FindSure yet.</p><p>Check the tracker SIM/data connection, antenna, power supply and device API key. The vehicle may be moving or switched off; no location is available until the tracker uploads one.</p>`;
    return;
  }
  const age=Math.max(0,Date.now()-Date.parse(pos.capturedAt));
  const freshness=age<120000?'Recent tracker reading':`Last tracker reading ${Math.floor(age/60000)} minute(s) ago`;
  const status=age<120000?'Recent':age<30*60000?'A few minutes old':'Old reading — verify before acting';
  const speed=pos.speedKph==null?'Not provided':`${Number(pos.speedKph).toFixed(1)} km/h`;
  const ignition=pos.ignition===true?'On':pos.ignition===false?'Off':'Not reported';
  const battery=pos.batteryVoltage==null?'Not reported':`${Number(pos.batteryVoltage).toFixed(2)} V`;
  result.innerHTML=`<div class="vehicle-position-head"><b>${escapeHtml(vehicle.label)}</b><span class="badge">${status}</span></div><p><b>${freshness}</b></p><p><b>Captured:</b> ${escapeHtml(vehicleTimeLabel(pos))} (${escapeHtml(pos.timeZone||'UTC')})</p><p><b>Server received:</b> ${escapeHtml(new Date(pos.receivedAt).toLocaleString())}</p><p><b>Speed:</b> ${speed} · <b>Ignition:</b> ${ignition}</p><p><b>GPS accuracy:</b> ${pos.accuracy==null?'Not provided':`${Math.round(pos.accuracy)} metres`} · <b>Tracker battery:</b> ${battery}</p><a href="${mapLink(pos.lat,pos.lon)}" target="_blank" rel="noopener noreferrer">Open vehicle position in OpenStreetMap ↗</a><p class="tiny-warning">A location can be old, inaccurate or spoofed. Check its timestamp; do not confront anyone at the location.</p>`;
  mapHolder.classList.remove('hidden');
  const map=initMap('vehicleLocationMap',{zoom:14});
  if(map){ if(map._vehiclePin)map.removeLayer(map._vehiclePin); map._vehiclePin=L.marker([Number(pos.lat),Number(pos.lon)]).addTo(map).bindPopup(`${escapeHtml(vehicle.label)} · ${escapeHtml(status)}`); map.setView([Number(pos.lat),Number(pos.lon)],15); setTimeout(()=>map.invalidateSize(),120); }
}
$('vehicleRegisterForm')?.addEventListener('submit', async event=>{
  event.preventDefault(); const button=event.submitter, result=$('vehicleRegisterResult');
  button.disabled=true;button.textContent='Creating secure credentials…';result.classList.add('hidden');
  try {
    const data=await api('/api/vehicle-trackers/register',{method:'POST',body:JSON.stringify({label:$('vehicleLabel').value.trim(),vehicleType:$('vehicleType').value,makeModel:$('vehicleMakeModel').value.trim()})});
    $('vehicleLookupCode').value=data.vehicle.privateRecoveryCode;$('vehicleRevokeCode').value=data.vehicle.privateRecoveryCode;$('vehicleRevokeId').value=data.tracker.id;
    const sample={lat:24.8607,lon:67.0011,accuracy:8.5,speedKph:0,heading:90,ignition:false,batteryVoltage:12.6,capturedAt:new Date().toISOString()};
    result.classList.remove('hidden');
    result.innerHTML=`<b>Vehicle registered — save both secrets now</b><p><b>Private recovery code (for the owner):</b><code class="large-code">${escapeHtml(data.vehicle.privateRecoveryCode)}</code><button id="copyVehicleOwnerCode" class="button light full-width" type="button">Copy owner code</button></p><p><b>Tracker API key (for a compatible GPS unit OR FindSure Android companion):</b><code class="tag-credential-value">${escapeHtml(data.tracker.apiKey)}</code><button id="copyVehicleApiKey" class="button light full-width" type="button">Copy tracker API key</button></p><p><b>Telemetry endpoint:</b> <code>${escapeHtml(location.origin+data.tracker.endpoint)}</code></p><p><b>Low-cost option:</b> Use the FindSure Android companion on a spare phone you own. Paste this API key in its Vehicle GPS field, approve the visible location service, and keep the phone charged with mobile data.</p><p><b>HTTP method:</b> POST · <b>Header:</b> <code>Authorization: Bearer API_KEY</code></p><p><b>Example JSON payload:</b></p><pre class="vehicle-sample-json">${escapeHtml(JSON.stringify(sample,null,2))}</pre><p>${escapeHtml(data.message)}</p><p class="tiny-warning">Never paste the tracker API key into public listings, screenshots, GitHub or the browser of a shared computer. Keep it only in your tracker configuration or the FindSure companion app on your own spare phone. Do not post it publicly.</p>`;
    $('copyVehicleOwnerCode')?.addEventListener('click',()=>copySecret(data.vehicle.privateRecoveryCode,'Owner recovery code copied.'));
    $('copyVehicleApiKey')?.addEventListener('click',()=>copySecret(data.tracker.apiKey,'Tracker API key copied.'));
    toast('Vehicle and GPS tracker credentials created.');
  } catch(error){result.classList.remove('hidden');result.textContent=error.message;}
  finally{button.disabled=false;button.textContent='Create vehicle tracker credentials';}
});
async function copySecret(value,message){try{await navigator.clipboard.writeText(value);toast(message);}catch{prompt('Copy and save this private value:',value);}}
$('vehicleLocateForm')?.addEventListener('submit',async event=>{event.preventDefault();await locateVehicle();});
async function locateVehicle(quiet=false){
  if(vehicleLookupBusy)return; const code=$('vehicleLookupCode')?.value.trim();
  if(!$('vehicleLookupConsent')?.checked){if(!quiet)toast('Confirm vehicle ownership or permission first.');return;}
  if(!code){if(!quiet)toast('Enter the private vehicle recovery code.');return;}
  vehicleLookupBusy=true;try{const data=await api('/api/vehicle-trackers/locate',{method:'POST',body:JSON.stringify({code})});renderVehiclePosition(data.vehicle);$('vehicleRefreshStatus').textContent=vehicleRefreshTimer?'Auto-refresh is active every minute.':'Auto-refresh is off.';}
  catch(error){if(!quiet){const result=$('vehicleLocateResult');result.classList.remove('hidden');result.textContent=error.message;}}
  finally{vehicleLookupBusy=false;}
}
$('vehicleAutoRefresh')?.addEventListener('click',()=>{
  if(vehicleRefreshTimer){clearInterval(vehicleRefreshTimer);vehicleRefreshTimer=null;$('vehicleAutoRefresh').textContent='Auto-refresh every minute';$('vehicleRefreshStatus').textContent='Auto-refresh is off.';return;}
  if(!$('vehicleLookupConsent')?.checked){toast('Confirm ownership/permission first.');return;}
  vehicleRefreshTimer=setInterval(()=>locateVehicle(true),60000);$('vehicleAutoRefresh').textContent='Stop auto-refresh';$('vehicleRefreshStatus').textContent='Auto-refresh is active while this page is open.';locateVehicle(true);
});
$('vehicleLookupConsent')?.addEventListener('change',()=>{if(!$('vehicleLookupConsent').checked&&vehicleRefreshTimer){clearInterval(vehicleRefreshTimer);vehicleRefreshTimer=null;$('vehicleAutoRefresh').textContent='Auto-refresh every minute';$('vehicleRefreshStatus').textContent='Auto-refresh stopped because permission was unchecked.';}});
$('vehicleRevokeForm')?.addEventListener('submit',async event=>{
  event.preventDefault();if(!confirm('Revoke this tracker API key? It will stop accepting future positions.'))return;
  const button=event.submitter,result=$('vehicleRevokeResult');button.disabled=true;button.textContent='Revoking…';result.classList.add('hidden');
  try{const data=await api('/api/vehicle-trackers/revoke',{method:'POST',body:JSON.stringify({code:$('vehicleRevokeCode').value.trim(),trackerId:$('vehicleRevokeId').value.trim()})});result.classList.remove('hidden');result.textContent=data.message;toast('Vehicle tracker key revoked.');}
  catch(error){result.classList.remove('hidden');result.textContent=error.message;}
  finally{button.disabled=false;button.textContent='Revoke tracker key';}
});

const powerRecoveryContent = {
  android: `<b>Android: use Google Find Hub</b><p>This uses the owner's Google Account, not a FindSure device code. It may show a saved recent location or crowd-detected location if the service was enabled before the phone went missing.</p><ol><li>Open the official Find Hub page and sign in with the Google Account already on the lost phone.</li><li>Select the missing device and review its location and last-seen time. If available, secure it or mark it lost.</li><li>For future protection, on the phone open Settings → Google → All services → Find Hub → Find your offline devices. Choose a network option; keep Location and Bluetooth on when shutting down and set a screen lock.</li></ol><p><b>Powered-off support is model-specific.</b> Google documents power-off finding for supported devices including Pixel 8, Pixel 9 and Pixel 10 series when the required offline-finding settings were prepared. This does not apply to every Android phone, and FindSure cannot read Google's private network data.</p><div class="recovery-links"><a href="https://android.com/find" target="_blank" rel="noopener noreferrer">Open Google Find Hub ↗</a><a href="https://support.google.com/android/answer/3265955" target="_blank" rel="noopener noreferrer">Official setup instructions ↗</a><a href="https://developers.google.com/nearby/fast-pair/specifications/extensions/fmdn" target="_blank" rel="noopener noreferrer">Find Hub hardware-partner specification ↗</a><a href="https://complaint.pta.gov.pk/" target="_blank" rel="noopener noreferrer">PTA complaint portal ↗</a></div><div class="recovery-warning"><b>Pakistan / IMEI:</b> PTA's complaint system supports stolen-handset IMEI blocking/unblocking complaints; it does not provide public live GPS tracking. Do not paste IMEI into a public report. Keep it private for PTA, your carrier and police as appropriate.</div>`,
  apple: `<b>Apple: use Find My</b><p>Sign in with the Apple Account belonging to the missing device. The Find My network must have been enabled beforehand for offline finding.</p><ol><li>Open Find Devices and sign in with the owner's Apple Account.</li><li>Choose the iPhone, iPad or Mac and review the location and timestamp. Use Lost Mode / lock features where available.</li><li>For future protection on iPhone, check Settings → your name → Find My → Find My iPhone, then enable Find My network and Send Last Location where available.</li></ol><p>On supported iPhone models, with Find My network enabled in advance, Apple says the phone may remain findable for up to 24 hours after shutdown (up to 5 hours in power reserve). Other device types and models vary. FindSure cannot query Apple's private Find My network.</p><div class="recovery-links"><a href="https://www.icloud.com/find" target="_blank" rel="noopener noreferrer">Open Apple Find Devices ↗</a><a href="https://support.apple.com/en-asia/guide/iphone/iph9a847efc7/ios" target="_blank" rel="noopener noreferrer">Official setup instructions ↗</a></div>`,
  windows: `<b>Windows: use Microsoft's device page</b><p>Sign in with the Microsoft Account used on the missing PC/laptop. Find My Device must have been enabled before the loss, with device location available.</p><ol><li>Open Microsoft account devices and sign in as the owner.</li><li>Choose Find My Device and check the reported map location.</li><li>If it may be stolen, use available lock/security options and report it to local police.</li></ol><p>This is not a universal offline crowd-finding network and should not be expected to reveal a powered-off PC's new location.</p><div class="recovery-links"><a href="https://account.microsoft.com/devices" target="_blank" rel="noopener noreferrer">Open Microsoft devices ↗</a><a href="https://support.microsoft.com/en-us/accounts-billing/security/find-and-lock-a-lost-windows-device" target="_blank" rel="noopener noreferrer">Microsoft instructions ↗</a></div>`,
  vehicle: `<b>Vehicles: use a tracker or authorized service</b><p>A number plate, registration or engine number is an identifier, not a live GPS transmitter.</p><ol><li>If you installed a GPS tracker or the vehicle has an official connected-car service, use its owner account/app and check the last report time.</li><li>If no tracker was fitted before it went missing, FindSure cannot produce a live location from the plate alone.</li><li>Keep registration, engine/chassis details and proof of ownership private; report theft to police and contact the relevant insurer/vehicle service.</li></ol><div class="recovery-warning">Do not approach a suspected thief yourself. An IMEI, SIM signal, plate or engine number should not be presented as a location unless an authorized tracker/network has actually reported coordinates.</div>`,
  samsung: `<b>Samsung Galaxy: use Samsung Find</b><p>Sign in with the Samsung Account already connected to the missing Galaxy. Samsung Find may show a last known location or a crowd-detected location if Offline Finding and the related options were enabled before the loss.</p><ol><li>Open Samsung Find and sign in with the device owner's Samsung Account.</li><li>Select the missing Galaxy phone, tablet, watch, earbuds or supported item, then read the last-seen time carefully.</li><li>For future protection, turn on Allow this phone to be found, Send last location and Offline finding where supported.</li></ol><p>Samsung's offline finding is for supported Galaxy devices with the option enabled; Samsung's phone/tablet guidance says a powered-off phone generally shows only its last-known location. It is not an IMEI-to-location service and is separate from FindSure's pilot network.</p><div class="recovery-links"><a href="https://samsungfind.samsung.com/" target="_blank" rel="noopener noreferrer">Open Samsung Find ↗</a><a href="https://www.samsung.com/pk/apps/samsung-find/" target="_blank" rel="noopener noreferrer">Samsung Pakistan setup guide ↗</a></div>`,
  tracker: `<b>Other electronics: check the built-in account or tracker network</b><p>For a laptop, camera, smartwatch, headphones or smart tag, use the manufacturer's official owner account or the compatible tag network that was paired before the item went missing.</p><ol><li>Check whether an official device-finding service or Bluetooth tracker was set up before the loss.</li><li>Sign in to that service with the account that owns the item and inspect the last-seen timestamp.</li><li>For future protection, pair a compatible network tracker or install a supported GPS tracker before losing the item.</li></ol><p>A normal web app cannot remotely switch on a lost device's GPS or get coordinates from a serial number alone.</p><div class="recovery-links"><a href="https://android.com/find" target="_blank" rel="noopener noreferrer">Google Find Hub ↗</a><a href="https://www.icloud.com/find" target="_blank" rel="noopener noreferrer">Apple Find My ↗</a></div>`
};
function showPowerRecoverySteps() {
  const platform=$('poweroffPlatform')?.value || 'android';
  const state=$('poweroffState')?.value || 'unknown';
  const tagState=$('poweroffTagState')?.value || 'unknown';
  const output=$('powerRecoverySteps');
  if(!output) return;
  const statusCopy = {
    online: '<div class="recovery-status-banner"><b>Device is on and online</b><span>Start with the owner’s official finder. If FindSure was set up in advance and the device is actively sharing, use its private FindSure code too.</span></div>',
    offline: '<div class="recovery-status-banner"><b>Device is on, but has no internet</b><span>Check the manufacturer’s offline-finding network and last-seen location. FindSure cannot receive a new remote reading until that device gets a connection again.</span></div>',
    'powered-off': '<div class="recovery-status-banner"><b>Device is powered off / battery may be empty</b><span>Only supported hardware and finding services prepared before the loss may report an offline or recently powered-off location. If the device is not supported, use the last-known location and report the loss. A separate FindSure BLE tag can help only if it was attached and powered before the loss.</span></div>',
    unknown: '<div class="recovery-status-banner"><b>Not sure about its current state</b><span>Try the official owner-account service first; it will show a current, offline or last-known status when available.</span></div>'
  };
  let tagAdvice='';
  if (state==='powered-off' && tagState==='yes') {
    tagAdvice='<div class="recovery-warning"><b>Separate battery-powered tag selected</b><p>Open the tag’s own manufacturer app, or FindSure’s Device Locator if this is a previously enrolled FindSure pilot tag. A nearby community scanner must have seen it; the map pin is a finder location, not a guaranteed exact position. If this is an Apple/Google/Samsung ecosystem tag, use that tag’s official network.</p></div>';
  } else if (state==='powered-off' && tagState==='no') {
    tagAdvice='<div class="recovery-warning"><b>No separate powered tracker was attached</b><p>You cannot add a physical tag remotely after the item is lost. Try the official service below for supported hardware and inspect the last-known timestamp. If no supported network or tracker was set up beforehand, a web app cannot make a completely powered-off device transmit.</p></div>';
  } else if (state==='offline' && tagState==='yes') {
    tagAdvice='<div class="recovery-status-banner"><b>Try the pre-attached tag / offline network</b><span>If the independent tag is still powered and nearby FindSure companion phones scan it, community sightings can be uploaded now or queued until connectivity returns.</span></div>';
  }
  output.innerHTML = tagAdvice + (statusCopy[state] || statusCopy.unknown) + (powerRecoveryContent[platform] || powerRecoveryContent.android);
}
$('showPowerRecoverySteps')?.addEventListener('click',showPowerRecoverySteps);
$('poweroffPlatform')?.addEventListener('change',showPowerRecoverySteps);
$('poweroffState')?.addEventListener('change',showPowerRecoverySteps);
$('poweroffTagState')?.addEventListener('change',showPowerRecoverySteps);
$('startLiveFollow').addEventListener('click',()=>{if(lookupTimer)return;if(!$('lookupConsent')?.checked){toast('Confirm you have permission to locate this device first.');return;}lookupTimer=setInterval(()=>lookupDevice(true),60_000);$('startLiveFollow').classList.add('hidden');$('stopLiveFollow').classList.remove('hidden');$('lookupLiveStatus').textContent='Auto-refresh is active every minute while this page is open.';lookupDevice(true);});
$('stopLiveFollow').addEventListener('click',()=>{if(lookupTimer)clearInterval(lookupTimer);lookupTimer=null;$('startLiveFollow').classList.remove('hidden');$('stopLiveFollow').classList.add('hidden');$('lookupLiveStatus').textContent='Auto-refresh is off.';});
$('lookupConsent')?.addEventListener('change',()=>{if(!$('lookupConsent').checked&&lookupTimer){clearInterval(lookupTimer);lookupTimer=null;$('startLiveFollow').classList.remove('hidden');$('stopLiveFollow').classList.add('hidden');$('lookupLiveStatus').textContent='Auto-refresh stopped because permission was unchecked.';}});
document.querySelectorAll('[data-create-vehicle-report]').forEach(button => button.addEventListener('click', () => {
  $('listingType').value = 'lost';
  const type = $('itemType'); if (type) type.value = 'car';
  const title = $('reportTitle'); if (title) title.placeholder = 'Example: Honda bike lost near North Nazimabad';
  showView('create');
}));
document.querySelectorAll('[data-open-phone-steps]').forEach(button => button.addEventListener('click', () => {
  const panel = $('sparePhoneSteps');
  if (!panel) return;
  panel.classList.remove('hidden');
  panel.scrollIntoView({behavior:'smooth', block:'nearest'});
}));
document.querySelectorAll('[data-close-phone-steps]').forEach(button => button.addEventListener('click', () => $('sparePhoneSteps')?.classList.add('hidden')));
document.querySelectorAll('[data-scroll-vehicle-tools]').forEach(button => button.addEventListener('click', () => {
  const panel = $('vehicleSetupDetails'); if (panel) panel.open = true;
  panel?.scrollIntoView({behavior:'smooth', block:'start'});
}));


updateOfflineQueueStatus(); renderOfflineReportQueue(); syncPendingCheckins(); syncPendingReports();

$('finishGuide').addEventListener('click', () => {localStorage.setItem('findsure-guide-reviewed','yes');$('guideStatus').textContent='Thanks — you can reopen this guide any time.';toast('Security guide marked as reviewed.');});
$('skipGuide').addEventListener('click', () => {localStorage.setItem('findsure-guide-skipped','yes');showView('home');toast('You can return to the guide any time.');});
$('loadAdmin')?.addEventListener('click', async () => {
  const key=$('adminKeyInput').value.trim(); $('adminStatus').textContent='Connecting…'; $('adminReports').innerHTML='';
  try {
    const data=await api('/api/admin/reports',{headers:{'X-Admin-Key':key}}); sessionStorage.setItem('findsure-admin-key',key);
    $('adminStatus').textContent=`Loaded ${data.reports.length} report(s). Pending reports appear first.`;
    const sorted=[...data.reports].sort((a,b)=>({pending:0,published:1,resolved:2,rejected:3}[a.status]??9)-({pending:0,published:1,resolved:2,rejected:3}[b.status]??9));
    $('adminReports').innerHTML=sorted.length?sorted.map(r=>`<article class="admin-report"><div><div class="badges">${listingBadge(r.listingType)}<span class="badge">${escapeHtml(r.status)}</span></div><h3>${escapeHtml(r.title)}</h3><p>${escapeHtml(r.city)} · ${escapeHtml(itemLabels[r.itemType]||r.itemType)}</p><p>${escapeHtml(r.description)}</p>${r.contact?`<p>Submitted contact: ${escapeHtml(r.contact)}</p>`:''}</div><div class="admin-actions">${r.status!=='published'?`<button class="button primary" data-moderate="published" data-id="${escapeHtml(r.id)}">Approve</button>`:''}${r.status!=='rejected'?`<button class="button light" data-moderate="rejected" data-id="${escapeHtml(r.id)}">Reject</button>`:''}</div></article>`).join(''):'<div class="empty-state"><b>Nothing to review</b><p>No reports are currently in the queue.</p></div>';
    $('adminReports').querySelectorAll('[data-moderate]').forEach(btn=>btn.addEventListener('click',async()=>{
      btn.disabled=true;try{await api('/api/admin/reports/moderate',{method:'POST',headers:{'X-Admin-Key':key},body:JSON.stringify({id:btn.dataset.id,status:btn.dataset.moderate})});toast(`Report ${btn.dataset.moderate}.`);$('loadAdmin').click();await loadReports();}catch(e){toast(e.message);btn.disabled=false;}
    }));
    try {
      const abuse = await api('/api/admin/abuse',{headers:{'X-Admin-Key':key}});
      const list = $('adminAbuseReports');
      list.innerHTML = abuse.reports.length ? abuse.reports.map(r => `<article class="admin-report"><div><div class="badges"><span class="badge">${escapeHtml(r.status)}</span><span class="badge">${escapeHtml(r.reason)}</span></div><h3>Concern about listing ${escapeHtml(r.reportId)}</h3><p>${escapeHtml(r.details || 'No extra details provided.')}</p><p>Received: ${escapeHtml(dateLabel(r.createdAt))}</p></div><div class="admin-actions">${r.status==='open'?`<button class="button primary" data-abuse-status="reviewed" data-id="${escapeHtml(r.id)}">Reviewed</button><button class="button light" data-abuse-status="actioned" data-id="${escapeHtml(r.id)}">Actioned</button>`:''}</div></article>`).join('') : '<div class="empty-state"><b>No safety reports</b><p>No community concerns have been submitted.</p></div>';
      list.querySelectorAll('[data-abuse-status]').forEach(btn=>btn.addEventListener('click',async()=>{btn.disabled=true;try{await api('/api/admin/abuse/close',{method:'POST',headers:{'X-Admin-Key':key},body:JSON.stringify({id:btn.dataset.id,status:btn.dataset.abuseStatus})});toast('Concern updated.');$('loadAdmin').click();}catch(e){toast(e.message);btn.disabled=false;}}));
    } catch (error) { $('adminAbuseReports').innerHTML=`<div class="empty-state"><b>Could not load safety reports</b><p>${escapeHtml(error.message)}</p></div>`; }
  } catch(error) { $('adminStatus').textContent=error.message; }
});
const lastAdminKey=sessionStorage.getItem('findsure-admin-key'); if (lastAdminKey) $('adminKeyInput').value=lastAdminKey;


async function boot() {
  initMap('browseMap'); initMap('reportMiniMap',{pick:true,zoom:5});
  try {const health=await api('/api/health');appIsDev=Boolean(health.devMode);$('apiStatus').textContent=health.ok?`Connected · ${health.database}`:'Unavailable';$('apiStatus').title=health.database;
    if (!appIsDev && 'serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(()=>{});
  } catch {$('apiStatus').textContent='Offline';}
  if ('serviceWorker' in navigator) navigator.serviceWorker.addEventListener('controllerchange',()=>{});
  await loadReports(); refreshMapSizes();
  if (location.hash && viewLabels[location.hash.slice(1)]) showView(location.hash.slice(1));
  // Keep first launch friendly: show the overview first, with the optional security guide in navigation.
  const sharedId = new URLSearchParams(location.search).get('report');
  if (sharedId) { showView('browse'); await loadReports(); }
  if (window.L) setTimeout(refreshMapSizes,500);
  if (appIsDev) startAutoReload();
}
async function startAutoReload() {
  async function checkVersion() {
    try {const data=await api('/api/dev-version');if (devVersion===null) devVersion=data.version;else if (data.version!==devVersion) {devVersion=data.version;location.reload();}} catch {}
  }
  await checkVersion(); setInterval(checkVersion,2000);
}
window.addEventListener('beforeinstallprompt', event => {event.preventDefault();installPrompt=event;$('installBtn').classList.remove('hidden');});
$('installBtn').addEventListener('click', async()=>{if (!installPrompt) return;installPrompt.prompt();await installPrompt.userChoice;installPrompt=null;$('installBtn').classList.add('hidden');});
window.addEventListener('resize',refreshMapSizes);
document.querySelectorAll('details').forEach(detail => detail.addEventListener('toggle', () => { if (detail.open) refreshMapSizes(); }));
boot();
