# FindSure v12 testing notes

## Completed in the local test environment

- `node --check server.js` passed.
- `node --check public/app.js` passed.
- `GET /api/health` returned version `12.0.0`.
- `GET /` returned the v12 app shell.
- Device registration returned a private code.
- Device check-in accepted test coordinates and returned capture/receive timestamps and timezone fields.
- Private-code lookup returned the stored location.
- Invalid private code was rejected with HTTP 404.
- The Device Locator page contains both device setup and code lookup forms in the same visible workspace.

## Not yet verified

- Visual browser QA could not be run in this environment because local navigation was blocked by the managed browser policy.
- Real-device GPS permission, mobile background behaviour and two-physical-phone testing remain outstanding.
- Public HTTPS hosting and Supabase persistence are not configured.
- Native Android companion APK is not prebuilt.

## Test coordinate warning

The API integration test used a fixed Karachi test coordinate only to verify the response path. It is not a real or live device location.
