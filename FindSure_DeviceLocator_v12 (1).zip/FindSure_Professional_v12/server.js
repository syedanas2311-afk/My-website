'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const ROOT = __dirname;
const PUBLIC = path.join(ROOT, 'public');
const DATA_DIR = process.env.FINDSURE_DATA_DIR || path.join(ROOT, 'data');
const DB_FILE = path.join(DATA_DIR, 'findsure-data.json');
const PORT = Number(process.env.PORT || 3000);
const IS_PROD = process.env.NODE_ENV === 'production';
const ADMIN_KEY = process.env.ADMIN_KEY || (IS_PROD ? '' : 'findsure-local-admin');
const SUPABASE_URL = (process.env.SUPABASE_URL || '').replace(/\/$/, '');
// Prefer Supabase's newer server-side secret key; support the older service_role key for existing projects.
const SUPABASE_SECRET_KEY = process.env.SUPABASE_SECRET_KEY || process.env.SUPABASE_SERVICE_ROLE_KEY || '';
const USE_SUPABASE = Boolean(SUPABASE_URL && SUPABASE_SECRET_KEY);
const MAX_BODY = 1_000_000;
const rateBuckets = new Map();
const timezoneCache = new Map();

fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, JSON.stringify({ reports: [], devices: [], beaconTags: [], beaconTagTokens: [], vehicleTrackers: [], vehiclePositions: [] }, null, 2));

function readLocal() {
  try { return { reports: [], devices: [], abuseReports: [], beaconTokens: [], beaconSightings: [], beaconTags: [], beaconTagTokens: [], vehicleTrackers: [], vehiclePositions: [], ...JSON.parse(fs.readFileSync(DB_FILE, 'utf8')) }; }
  catch { return { reports: [], devices: [], abuseReports: [], beaconTokens: [], beaconSightings: [], beaconTags: [], beaconTagTokens: [], vehicleTrackers: [], vehiclePositions: [] }; }
}
function writeLocal(db) { fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2)); }
function sha(value) { return crypto.createHash('sha256').update(String(value)).digest('hex'); }
function randomCode() { return crypto.randomBytes(8).toString('hex').toUpperCase().match(/.{1,4}/g).join('-'); }
function clean(value, max = 300) { return String(value ?? '').trim().replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '').slice(0, max); }
function validCoord(lat, lon) {
  return lat !== null && lat !== undefined && lon !== null && lon !== undefined &&
    String(lat).trim() !== '' && String(lon).trim() !== '' &&
    Number.isFinite(Number(lat)) && Number.isFinite(Number(lon)) &&
    Math.abs(Number(lat)) <= 90 && Math.abs(Number(lon)) <= 180;
}
function approximate(value) { return Math.round(Number(value) * 100) / 100; }
function redactPublicText(value) {
  return String(value ?? '')
    // Hide explicit serial/IMEI/engine/chassis identifiers even if a user puts them in a description.
    .replace(/\b(IMEI|serial(?:\s+number)?|S\/N|device\s+ID|engine\s+number|chassis\s+number)\s*[:#-]?\s*[A-Z0-9-]{5,}\b/ig, '$1 [kept private]')
    // IMEIs and similar numeric identifiers should never be echoed to the public board.
    .replace(/\b\d{14,17}\b/g, '[identifier hidden]')
    .slice(0, 1400);
}
function toPublicReport(r) {
  const p = normalizeReport(r);
  return {
    id: p.id, listingType: p.listingType, itemType: p.itemType, title: redactPublicText(p.title),
    description: redactPublicText(p.description), city: redactPublicText(p.city), area: redactPublicText(p.area),
    // Never publish the separate identifying-detail field; retain it only in the private owner record.
    identifier: '',
    contact: p.shareContact ? p.contact : '', shareContact: p.shareContact,
    status: p.status, createdAt: p.createdAt, lat: p.lat, lon: p.lon
  };
}
function normalizeReport(r) {
  return {
    id: r.id, listingType: r.listing_type ?? r.listingType ?? 'lost',
    itemType: r.item_type ?? r.itemType ?? 'other', title: r.title ?? '',
    description: r.description ?? '', city: r.city ?? '', area: r.area ?? '',
    identifier: r.identifier ?? '', contact: r.contact ?? '', shareContact: Boolean(r.share_contact ?? r.shareContact),
    status: r.status ?? 'pending', createdAt: r.created_at ?? r.createdAt ?? new Date().toISOString(),
    lat: r.lat ?? null, lon: r.lon ?? null, ownerHash: r.owner_hash ?? r.ownerHash ?? '',
    clientSubmissionId: r.client_submission_id ?? r.clientSubmissionId ?? ''
  };
}
function toSupabaseReport(r) {
  return {
    id: r.id, listing_type: r.listingType, item_type: r.itemType, title: r.title,
    description: r.description, city: r.city, area: r.area, identifier: r.identifier,
    contact: r.contact, share_contact: r.shareContact, status: r.status,
    created_at: r.createdAt, lat: r.lat, lon: r.lon, owner_hash: r.ownerHash,
    client_submission_id: r.clientSubmissionId || null
  };
}
async function getAbuseReports() {
  if (USE_SUPABASE) {
    const rows = await sbRequest('abuse_reports?select=*&order=created_at.desc');
    return (rows || []).map(r => ({ id:r.id, reportId:r.report_id, reason:r.reason, details:r.details || '', status:r.status, createdAt:r.created_at }));
  }
  return (readLocal().abuseReports || []).sort((a,b) => b.createdAt.localeCompare(a.createdAt));
}
async function insertAbuseReport(item) {
  if (USE_SUPABASE) {
    const rows = await sbRequest('abuse_reports', { method:'POST', prefer:'return=representation', body:{ id:item.id, report_id:item.reportId, reason:item.reason, details:item.details, status:item.status, created_at:item.createdAt } });
    const r = rows[0]; return { id:r.id, reportId:r.report_id, reason:r.reason, details:r.details, status:r.status, createdAt:r.created_at };
  }
  const db = readLocal(); db.abuseReports = db.abuseReports || []; db.abuseReports.push(item); writeLocal(db); return item;
}
async function updateAbuseReport(id, status) {
  if (USE_SUPABASE) {
    const rows = await sbRequest(`abuse_reports?id=eq.${encodeURIComponent(id)}&select=*`, { method:'PATCH', prefer:'return=representation', body:{status} });
    const r = rows && rows[0]; return r ? { id:r.id, reportId:r.report_id, reason:r.reason, details:r.details || '', status:r.status, createdAt:r.created_at } : null;
  }
  const db=readLocal(); const item=(db.abuseReports || []).find(x => x.id === id); if (!item) return null; item.status=status; writeLocal(db); return item;
}
function normalizeDevice(d) {
  const ll = d.lastLocation || {};
  const lat = d.last_lat ?? ll.lat;
  return {
    id: d.id, label: d.label, codeHash: d.code_hash ?? d.codeHash,
    createdAt: d.created_at ?? d.createdAt,
    lastLocation: lat == null ? null : {
      lat: Number(lat), lon: Number(d.last_lon ?? ll.lon),
      accuracy: d.accuracy ?? ll.accuracy ?? null,
      capturedAt: d.captured_at ?? ll.capturedAt ?? d.updated_at ?? ll.updatedAt ?? null,
      updatedAt: d.updated_at ?? ll.updatedAt ?? null,
      timeZone: d.time_zone ?? ll.timeZone ?? '',
      timeZoneName: d.time_zone_name ?? ll.timeZoneName ?? '',
      timeZoneSource: d.time_zone_source ?? ll.timeZoneSource ?? 'unavailable'
    }
  };
}
async function timezoneForLocation(lat, lon, fallbackZone) {
  // Send only rounded (~1 km) coordinates to the external nearest-city timezone service.
  // Exact coordinates remain private in our own database and are never sent to the timezone provider.
  const qLat = Math.round(Number(lat) * 100) / 100;
  const qLon = Math.round(Number(lon) * 100) / 100;
  const cacheKey = `${qLat},${qLon}`;
  const cached = timezoneCache.get(cacheKey);
  if (cached && Date.now() - cached.at < (cached.value.timeZoneSource === 'approximate-nearest-city' ? 24 * 60 * 60 * 1000 : 15 * 60 * 1000)) return cached.value;
  try {
    const url = `https://hourora.app/api/v1/lookup?lat=${encodeURIComponent(qLat)}&lng=${encodeURIComponent(qLon)}`;
    const response = await fetch(url, { signal: AbortSignal.timeout(2500), headers: { Accept: 'application/json' } });
    if (response.ok) {
      const body = await response.json();
      const zone = clean(body.zone || body.city?.zone || body.now?.zone, 100);
      if (zone && validTimeZone(zone)) { const value = { timeZone: zone, timeZoneName: clean(body.city?.name || zone, 100), timeZoneSource: 'approximate-nearest-city' }; timezoneCache.set(cacheKey,{at:Date.now(),value}); return value; }
    }
  } catch { /* Use device-reported zone as clearly labelled fallback. */ }
  const fallback = clean(fallbackZone, 100);
  if (fallback && validTimeZone(fallback)) { const value = { timeZone: fallback, timeZoneName: fallback, timeZoneSource: 'device-timezone-fallback' }; timezoneCache.set(cacheKey,{at:Date.now(),value}); return value; }
  const value = { timeZone: 'UTC', timeZoneName: 'UTC', timeZoneSource: 'UTC-fallback' }; timezoneCache.set(cacheKey,{at:Date.now(),value}); return value;
}
function validTimeZone(zone) {
  try { new Intl.DateTimeFormat('en-US', { timeZone: zone }).format(new Date()); return true; }
  catch { return false; }
}
async function sbRequest(resource, options = {}) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${resource}`, {
    method: options.method || 'GET',
    headers: {
      apikey: SUPABASE_SECRET_KEY,
      Authorization: `Bearer ${SUPABASE_SECRET_KEY}`,
      'Content-Type': 'application/json',
      ...(options.prefer ? { Prefer: options.prefer } : {})
    },
    body: options.body === undefined ? undefined : JSON.stringify(options.body)
  });
  const body = await res.text();
  let result = null;
  try { result = body ? JSON.parse(body) : null; } catch { result = body; }
  if (!res.ok) throw new Error((result && (result.message || result.error_description || result.hint)) || `Database request failed (${res.status})`);
  return result;
}
async function allReports(includeHidden = false) {
  if (USE_SUPABASE) {
    const statusPart = includeHidden ? '' : '&status=in.(published,resolved)';
    const result = await sbRequest(`reports?select=*&order=created_at.desc${statusPart}`);
    return (result || []).map(normalizeReport);
  }
  const all = readLocal().reports.map(normalizeReport);
  return all.filter(r => includeHidden || ['published', 'resolved'].includes(r.status)).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}
async function findReportBySubmissionId(submissionId) {
  if (!submissionId) return null;
  if (USE_SUPABASE) {
    const rows = await sbRequest(`reports?client_submission_id=eq.${encodeURIComponent(submissionId)}&select=*&limit=1`);
    return rows && rows[0] ? normalizeReport(rows[0]) : null;
  }
  const match = readLocal().reports.find(r => (r.clientSubmissionId || r.client_submission_id) === submissionId);
  return match ? normalizeReport(match) : null;
}
async function insertReport(r) {
  if (USE_SUPABASE) {
    const rows = await sbRequest('reports', { method: 'POST', prefer: 'return=representation', body: toSupabaseReport(r) });
    return normalizeReport(rows[0]);
  }
  const db = readLocal(); db.reports.push(r); writeLocal(db); return r;
}
async function deleteReportByOwner(id, ownerHash) {
  if (USE_SUPABASE) {
    const rows = await sbRequest(`reports?id=eq.${encodeURIComponent(id)}&owner_hash=eq.${encodeURIComponent(ownerHash)}&select=id`, { method: 'DELETE', prefer: 'return=representation' });
    return Boolean(rows && rows.length);
  }
  const db = readLocal();
  const index = db.reports.findIndex(r => r.id === id && (r.ownerHash || r.owner_hash) === ownerHash);
  if (index < 0) return false;
  db.reports.splice(index, 1); writeLocal(db); return true;
}
async function updateReport(id, changes, ownerHash) {
  if (USE_SUPABASE) {
    const patch = {};
    if (changes.status) patch.status = changes.status;
    if (ownerHash) {
      const rows = await sbRequest(`reports?id=eq.${encodeURIComponent(id)}&owner_hash=eq.${encodeURIComponent(ownerHash)}&select=*`, { method: 'PATCH', prefer: 'return=representation', body: patch });
      return rows && rows[0] ? normalizeReport(rows[0]) : null;
    }
    const rows = await sbRequest(`reports?id=eq.${encodeURIComponent(id)}&select=*`, { method: 'PATCH', prefer: 'return=representation', body: patch });
    return rows && rows[0] ? normalizeReport(rows[0]) : null;
  }
  const db = readLocal(); const r = db.reports.find(x => x.id === id && (!ownerHash || (x.ownerHash === ownerHash)));
  if (!r) return null;
  Object.assign(r, changes); writeLocal(db); return normalizeReport(r);
}
async function findDevice(codeHash) {
  if (USE_SUPABASE) {
    const rows = await sbRequest(`devices?select=*&code_hash=eq.${encodeURIComponent(codeHash)}&limit=1`);
    return rows && rows[0] ? normalizeDevice(rows[0]) : null;
  }
  const found = readLocal().devices.find(d => (d.codeHash || d.code_hash) === codeHash);
  return found ? normalizeDevice(found) : null;
}
async function findReportByOwnerHash(ownerHash) {
  if (USE_SUPABASE) {
    const rows = await sbRequest(`reports?select=*&owner_hash=eq.${encodeURIComponent(ownerHash)}&limit=1`);
    return rows && rows[0] ? normalizeReport(rows[0]) : null;
  }
  const found = readLocal().reports.find(r => (r.ownerHash || r.owner_hash) === ownerHash);
  return found ? normalizeReport(found) : null;
}

async function insertDevice(d) {
  if (USE_SUPABASE) {
    const rows = await sbRequest('devices', { method: 'POST', prefer: 'return=representation', body: {
      id: d.id, label: d.label, code_hash: d.codeHash, created_at: d.createdAt,
      last_lat: null, last_lon: null, accuracy: null, captured_at: null, updated_at: null, time_zone: null, time_zone_name: null, time_zone_source: null
    }});
    return normalizeDevice(rows[0]);
  }
  const db = readLocal(); db.devices.push(d); writeLocal(db); return normalizeDevice(d);
}
async function saveDeviceLocation(id, location) {
  if (USE_SUPABASE) {
    const rows = await sbRequest(`devices?id=eq.${encodeURIComponent(id)}&select=*`, { method: 'PATCH', prefer: 'return=representation', body: {
      last_lat: location.lat, last_lon: location.lon, accuracy: location.accuracy, captured_at: location.capturedAt, updated_at: location.updatedAt, time_zone: location.timeZone, time_zone_name: location.timeZoneName, time_zone_source: location.timeZoneSource
    }});
    return rows && rows[0] ? normalizeDevice(rows[0]) : null;
  }
  const db = readLocal(); const d = db.devices.find(x => x.id === id);
  if (!d) return null;
  d.lastLocation = location; writeLocal(db); return normalizeDevice(d);
}

// FindSure vehicle GPS tracker integration. Only an enrolled tracker's private
// bearer key can send telemetry; only its owner's private recovery code can read it.
function normalizeVehicleTracker(row) {
  return {
    id: row.id, deviceId: row.device_id ?? row.deviceId,
    label: row.label || '', vehicleType: row.vehicle_type ?? row.vehicleType ?? 'car',
    makeModel: row.make_model ?? row.makeModel ?? '',
    credentialHash: row.credential_hash ?? row.credentialHash,
    createdAt: row.created_at ?? row.createdAt,
    revokedAt: row.revoked_at ?? row.revokedAt ?? null
  };
}
function normalizeVehiclePosition(row) {
  return {
    id: row.id, trackerId: row.tracker_id ?? row.trackerId,
    lat: Number(row.lat), lon: Number(row.lon),
    accuracy: row.accuracy == null ? null : Number(row.accuracy),
    speedKph: row.speed_kph == null && row.speedKph == null ? null : Number(row.speed_kph ?? row.speedKph),
    heading: row.heading == null ? null : Number(row.heading),
    ignition: row.ignition == null ? null : Boolean(row.ignition),
    batteryVoltage: row.battery_voltage == null && row.batteryVoltage == null ? null : Number(row.battery_voltage ?? row.batteryVoltage),
    capturedAt: row.captured_at ?? row.capturedAt,
    receivedAt: row.received_at ?? row.receivedAt,
    timeZone: row.time_zone ?? row.timeZone ?? 'UTC',
    timeZoneName: row.time_zone_name ?? row.timeZoneName ?? 'UTC',
    timeZoneSource: row.time_zone_source ?? row.timeZoneSource ?? 'UTC-fallback'
  };
}
async function insertVehicleTracker(tracker) {
  if (USE_SUPABASE) {
    const rows = await sbRequest('vehicle_trackers', { method:'POST', prefer:'return=representation', body:{
      id:tracker.id, device_id:tracker.deviceId, label:tracker.label, vehicle_type:tracker.vehicleType,
      make_model:tracker.makeModel, credential_hash:tracker.credentialHash, created_at:tracker.createdAt, revoked_at:null
    }});
    return rows?.[0] ? normalizeVehicleTracker(rows[0]) : tracker;
  }
  const db=readLocal(); db.vehicleTrackers=db.vehicleTrackers||[]; db.vehicleTrackers.push(tracker); writeLocal(db); return tracker;
}
async function findVehicleTrackerByCredentialHash(hash) {
  if (USE_SUPABASE) {
    const rows=await sbRequest(`vehicle_trackers?select=*&credential_hash=eq.${encodeURIComponent(hash)}&revoked_at=is.null&limit=1`);
    return rows?.[0] ? normalizeVehicleTracker(rows[0]) : null;
  }
  const row=(readLocal().vehicleTrackers||[]).find(t=>t.credentialHash===hash&&!t.revokedAt);
  return row||null;
}
async function findVehicleTrackerForDevice(trackerId, deviceId) {
  if (USE_SUPABASE) {
    const rows=await sbRequest(`vehicle_trackers?select=*&id=eq.${encodeURIComponent(trackerId)}&device_id=eq.${encodeURIComponent(deviceId)}&limit=1`);
    return rows?.[0] ? normalizeVehicleTracker(rows[0]) : null;
  }
  return (readLocal().vehicleTrackers||[]).find(t=>t.id===trackerId&&t.deviceId===deviceId)||null;
}
async function revokeVehicleTracker(trackerId, deviceId) {
  const tracker=await findVehicleTrackerForDevice(trackerId,deviceId);
  if (!tracker || tracker.revokedAt) return false;
  const revokedAt=new Date().toISOString();
  if (USE_SUPABASE) {
    const rows=await sbRequest(`vehicle_trackers?id=eq.${encodeURIComponent(trackerId)}&device_id=eq.${encodeURIComponent(deviceId)}&revoked_at=is.null&select=id`,{method:'PATCH',prefer:'return=representation',body:{revoked_at:revokedAt}});
    return Boolean(rows?.length);
  }
  const db=readLocal(); const row=(db.vehicleTrackers||[]).find(t=>t.id===trackerId&&t.deviceId===deviceId&&!t.revokedAt);
  if(!row)return false; row.revokedAt=revokedAt; writeLocal(db); return true;
}
async function insertVehiclePosition(position) {
  if (USE_SUPABASE) {
    const rows=await sbRequest('vehicle_tracker_positions',{method:'POST',prefer:'return=representation',body:{
      id:position.id, tracker_id:position.trackerId, lat:position.lat, lon:position.lon,
      accuracy:position.accuracy, speed_kph:position.speedKph, heading:position.heading,
      ignition:position.ignition, battery_voltage:position.batteryVoltage,
      captured_at:position.capturedAt, received_at:position.receivedAt,
      time_zone:position.timeZone, time_zone_name:position.timeZoneName, time_zone_source:position.timeZoneSource
    }});
    const row=rows?.[0]; return row?normalizeVehiclePosition(row):position;
  }
  const db=readLocal(); db.vehiclePositions=db.vehiclePositions||[]; db.vehiclePositions.push(position);
  if(db.vehiclePositions.length>5000) db.vehiclePositions=db.vehiclePositions.slice(-5000);
  writeLocal(db); return position;
}
async function latestVehiclePosition(trackerId) {
  if (USE_SUPABASE) {
    const rows=await sbRequest(`vehicle_tracker_positions?select=*&tracker_id=eq.${encodeURIComponent(trackerId)}&order=captured_at.desc&limit=1`);
    return rows?.[0]?normalizeVehiclePosition(rows[0]):null;
  }
  const rows=(readLocal().vehiclePositions||[]).filter(p=>p.trackerId===trackerId).sort((a,b)=>String(b.capturedAt).localeCompare(String(a.capturedAt)));
  return rows.length?normalizeVehiclePosition(rows[0]):null;
}

// FindSure BLE pilot: rotating 64-bit tokens, changed every 15 minutes.
// Tokens are only valid for the slot assigned by the server; they are not device serial numbers.
const BEACON_SLOT_MS = 15 * 60 * 1000;
const BEACON_PAST_SLOTS = 96 * 8;     // keep eight days of previous slots for delayed relay uploads
const BEACON_FUTURE_SLOTS = 96 * 7;    // pre-cache seven days for a phone that may lose internet
function beaconSlot(ms = Date.now()) { return Math.floor(ms / BEACON_SLOT_MS); }
function fromBeaconRow(row) {
  return { id: row.id, deviceId: row.device_id ?? row.deviceId, slot: Number(row.slot), token: row.token, createdAt: row.created_at ?? row.createdAt };
}
function fromSightingRow(row) {
  return {
    id: row.id, deviceId: row.device_id ?? row.deviceId, tokenSlot: Number(row.token_slot ?? row.tokenSlot),
    lat: Number(row.lat), lon: Number(row.lon), accuracy: row.accuracy == null ? null : Number(row.accuracy),
    capturedAt: row.captured_at ?? row.capturedAt,
    gpsCapturedAt: row.relay_location_captured_at ?? row.gpsCapturedAt ?? row.capturedAt,
    receivedAt: row.received_at ?? row.receivedAt,
    timeZone: row.time_zone ?? row.timeZone ?? 'UTC', timeZoneName: row.time_zone_name ?? row.timeZoneName ?? 'UTC',
    timeZoneSource: row.time_zone_source ?? row.timeZoneSource ?? 'UTC-fallback', finderPlatform: row.finder_platform ?? row.finderPlatform ?? 'android'
  };
}
async function ensureBeaconTokens(deviceId) {
  const current = beaconSlot(); const first = current - BEACON_PAST_SLOTS; const last = current + BEACON_FUTURE_SLOTS;
  if (USE_SUPABASE) {
    await sbRequest(`device_beacon_tokens?device_id=eq.${encodeURIComponent(deviceId)}&slot=lt.${first}`, { method: 'DELETE', prefer: 'return=minimal' });
    const existing = await sbRequest(`device_beacon_tokens?select=slot,token&device_id=eq.${encodeURIComponent(deviceId)}&slot=gte.${first}&slot=lte.${last}`);
    const bySlot = new Map((existing || []).map(row => [Number(row.slot), row.token]));
    const newRows = [];
    for (let slot = first; slot <= last; slot++) if (!bySlot.has(slot)) {
      const token = crypto.randomBytes(8).toString('hex').toUpperCase();
      bySlot.set(slot, token);
      newRows.push({ id: crypto.randomUUID(), device_id: deviceId, slot, token, created_at: new Date().toISOString() });
    }
    for (let i = 0; i < newRows.length; i += 400) {
      await sbRequest('device_beacon_tokens', { method: 'POST', prefer: 'resolution=ignore-duplicates,return=minimal', body: newRows.slice(i, i + 400) });
    }
    const refreshed = await sbRequest(`device_beacon_tokens?select=slot,token&device_id=eq.${encodeURIComponent(deviceId)}&slot=gte.${current}&slot=lte.${last}&order=slot.asc`);
    return (refreshed || []).map(row => ({ slot: Number(row.slot), token: row.token }));
  }
  const db = readLocal(); db.beaconTokens = db.beaconTokens || [];
  db.beaconTokens = db.beaconTokens.filter(row => Number(row.slot) >= first || row.deviceId !== deviceId);
  const bySlot = new Map(db.beaconTokens.filter(row => row.deviceId === deviceId).map(row => [Number(row.slot), row]));
  for (let slot = first; slot <= last; slot++) if (!bySlot.has(slot)) {
    const row = { id: crypto.randomUUID(), deviceId, slot, token: crypto.randomBytes(8).toString('hex').toUpperCase(), createdAt: new Date().toISOString() };
    db.beaconTokens.push(row); bySlot.set(slot, row);
  }
  // Keep a bounded amount of old data in local development. This is a pilot, not fleet-scale storage.
  db.beaconTokens = db.beaconTokens.filter(row => Number(row.slot) >= current - BEACON_PAST_SLOTS);
  writeLocal(db);
  return db.beaconTokens.filter(row => row.deviceId === deviceId && Number(row.slot) >= current && Number(row.slot) <= last).sort((a,b) => a.slot-b.slot).map(row => ({ slot: Number(row.slot), token: row.token }));
}
async function insertBeaconTag(tag) {
  if (USE_SUPABASE) {
    const rows = await sbRequest('device_beacon_tags', { method: 'POST', prefer: 'return=representation', body: {
      id: tag.id, device_id: tag.deviceId, label: tag.label, credential_hash: tag.credentialHash,
      created_at: tag.createdAt, revoked_at: null
    }});
    const row = rows && rows[0];
    return row ? { id: row.id, deviceId: row.device_id, label: row.label, credentialHash: row.credential_hash, createdAt: row.created_at, revokedAt: row.revoked_at } : tag;
  }
  const db = readLocal(); db.beaconTags = db.beaconTags || []; db.beaconTags.push(tag); writeLocal(db); return tag;
}
async function findBeaconTagByCredentialHash(credentialHash) {
  if (USE_SUPABASE) {
    const rows = await sbRequest(`device_beacon_tags?select=*&credential_hash=eq.${encodeURIComponent(credentialHash)}&revoked_at=is.null&limit=1`);
    const row = rows && rows[0];
    return row ? { id: row.id, deviceId: row.device_id, label: row.label, credentialHash: row.credential_hash, createdAt: row.created_at, revokedAt: row.revoked_at } : null;
  }
  const tag = (readLocal().beaconTags || []).find(t => t.credentialHash === credentialHash && !t.revokedAt);
  return tag || null;
}
async function findBeaconTagById(tagId, deviceId) {
  if (USE_SUPABASE) {
    const rows = await sbRequest(`device_beacon_tags?select=*&id=eq.${encodeURIComponent(tagId)}&device_id=eq.${encodeURIComponent(deviceId)}&limit=1`);
    const row = rows && rows[0];
    return row ? { id: row.id, deviceId: row.device_id, label: row.label, credentialHash: row.credential_hash, createdAt: row.created_at, revokedAt: row.revoked_at } : null;
  }
  return (readLocal().beaconTags || []).find(t => t.id === tagId && t.deviceId === deviceId) || null;
}
async function revokeBeaconTag(tagId, deviceId) {
  const tag = await findBeaconTagById(tagId, deviceId);
  if (!tag || tag.revokedAt) return false;
  const revokedAt = new Date().toISOString();
  if (USE_SUPABASE) {
    const rows = await sbRequest(`device_beacon_tags?id=eq.${encodeURIComponent(tagId)}&device_id=eq.${encodeURIComponent(deviceId)}&revoked_at=is.null&select=id`, { method: 'PATCH', prefer: 'return=representation', body: { revoked_at: revokedAt } });
    return Boolean(rows && rows.length);
  }
  const db = readLocal(); const found = (db.beaconTags || []).find(t => t.id === tagId && t.deviceId === deviceId && !t.revokedAt);
  if (!found) return false;
  found.revokedAt = revokedAt; writeLocal(db); return true;
}
async function ensureTagBeaconTokens(tagId, deviceId) {
  const current = beaconSlot(); const first = current - BEACON_PAST_SLOTS; const last = current + BEACON_FUTURE_SLOTS;
  if (USE_SUPABASE) {
    await sbRequest(`device_beacon_tag_tokens?tag_id=eq.${encodeURIComponent(tagId)}&slot=lt.${first}`, { method: 'DELETE', prefer: 'return=minimal' });
    const existing = await sbRequest(`device_beacon_tag_tokens?select=slot,token&tag_id=eq.${encodeURIComponent(tagId)}&slot=gte.${first}&slot=lte.${last}`);
    const bySlot = new Map((existing || []).map(row => [Number(row.slot), row.token]));
    const newRows = [];
    for (let slot = first; slot <= last; slot++) if (!bySlot.has(slot)) {
      const token = crypto.randomBytes(8).toString('hex').toUpperCase();
      bySlot.set(slot, token);
      newRows.push({ id: crypto.randomUUID(), tag_id: tagId, device_id: deviceId, slot, token, created_at: new Date().toISOString() });
    }
    for (let i = 0; i < newRows.length; i += 400) await sbRequest('device_beacon_tag_tokens', { method: 'POST', prefer: 'resolution=ignore-duplicates,return=minimal', body: newRows.slice(i, i + 400) });
    const refreshed = await sbRequest(`device_beacon_tag_tokens?select=slot,token&tag_id=eq.${encodeURIComponent(tagId)}&slot=gte.${current}&slot=lte.${last}&order=slot.asc`);
    return (refreshed || []).map(row => ({ slot: Number(row.slot), token: row.token }));
  }
  const db = readLocal(); db.beaconTagTokens = db.beaconTagTokens || [];
  db.beaconTagTokens = db.beaconTagTokens.filter(row => row.tagId !== tagId || Number(row.slot) >= first);
  const existing = new Map(db.beaconTagTokens.filter(row => row.tagId === tagId).map(row => [Number(row.slot), row]));
  for (let slot = first; slot <= last; slot++) if (!existing.has(slot)) {
    const row = { id: crypto.randomUUID(), tagId, deviceId, slot, token: crypto.randomBytes(8).toString('hex').toUpperCase(), createdAt: new Date().toISOString() };
    db.beaconTagTokens.push(row); existing.set(slot, row);
  }
  writeLocal(db);
  return db.beaconTagTokens.filter(row => row.tagId === tagId && Number(row.slot) >= current && Number(row.slot) <= last).sort((a,b) => a.slot-b.slot).map(row => ({ slot: Number(row.slot), token: row.token }));
}
async function findBeaconToken(token) {
  if (USE_SUPABASE) {
    const rows = await sbRequest(`device_beacon_tokens?select=id,device_id,slot,token&token=eq.${encodeURIComponent(token)}&limit=1`);
    if (rows && rows[0]) return fromBeaconRow(rows[0]);
    const tagRows = await sbRequest(`device_beacon_tag_tokens?select=id,device_id,tag_id,slot,token&token=eq.${encodeURIComponent(token)}&limit=1`);
    if (!tagRows || !tagRows[0]) return null;
    const tagStatus = await sbRequest(`device_beacon_tags?select=id&id=eq.${encodeURIComponent(tagRows[0].tag_id)}&revoked_at=is.null&limit=1`);
    if (!tagStatus || !tagStatus[0]) return null;
    return { id: tagRows[0].id, deviceId: tagRows[0].device_id, slot: Number(tagRows[0].slot), token: tagRows[0].token, source: 'external-tag' };
  }
  const db = readLocal();
  const found = (db.beaconTokens || []).find(row => row.token === token);
  if (found) return fromBeaconRow(found);
  const tagRow = (db.beaconTagTokens || []).find(row => row.token === token);
  if (!tagRow) return null;
  const tag = (db.beaconTags || []).find(row => row.id === tagRow.tagId && !row.revokedAt);
  return tag ? { id: tagRow.id, deviceId: tagRow.deviceId, slot: Number(tagRow.slot), token: tagRow.token, source: 'external-tag' } : null;
}
async function saveBeaconSighting(sighting) {
  if (USE_SUPABASE) {
    const rows = await sbRequest('device_beacon_sightings', { method: 'POST', prefer: 'return=representation', body: {
      id: sighting.id, device_id: sighting.deviceId, token_slot: sighting.tokenSlot, lat: sighting.lat, lon: sighting.lon,
      accuracy: sighting.accuracy, captured_at: sighting.capturedAt, relay_location_captured_at: sighting.gpsCapturedAt,
      received_at: sighting.receivedAt, time_zone: sighting.timeZone, time_zone_name: sighting.timeZoneName, time_zone_source: sighting.timeZoneSource, finder_platform: sighting.finderPlatform
    }});
    return rows && rows[0] ? fromSightingRow(rows[0]) : sighting;
  }
  const db = readLocal(); db.beaconSightings = db.beaconSightings || []; db.beaconSightings.push(sighting);
  // Retain only the latest 2,000 detections in the local demo database.
  if (db.beaconSightings.length > 2000) db.beaconSightings = db.beaconSightings.slice(-2000);
  writeLocal(db); return sighting;
}
async function latestBeaconSighting(deviceId) {
  if (USE_SUPABASE) {
    const rows = await sbRequest(`device_beacon_sightings?select=*&device_id=eq.${encodeURIComponent(deviceId)}&order=captured_at.desc&limit=1`);
    return rows && rows[0] ? fromSightingRow(rows[0]) : null;
  }
  const rows = (readLocal().beaconSightings || []).filter(row => row.deviceId === deviceId).sort((a,b) => String(b.capturedAt).localeCompare(String(a.capturedAt)));
  return rows.length ? fromSightingRow(rows[0]) : null;
}
function send(res, status, data, type = 'application/json; charset=utf-8', noStore = true) {
  const headers = {
    'Content-Type': type, 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'strict-origin-when-cross-origin',
    'X-Frame-Options': 'DENY', 'Permissions-Policy': 'geolocation=(self)',
    'Cache-Control': noStore ? 'no-store' : 'public, max-age=0, must-revalidate'
  };
  if (type.startsWith('application/json')) res.writeHead(status, headers).end(JSON.stringify(data));
  else res.writeHead(status, headers).end(data);
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let text = '';
    req.on('data', chunk => {
      text += chunk;
      if (text.length > MAX_BODY) { reject(new Error('Request is too large.')); req.destroy(); }
    });
    req.on('end', () => { try { resolve(JSON.parse(text || '{}')); } catch { reject(new Error('Invalid JSON request.')); } });
    req.on('error', reject);
  });
}
function clientKey(req) { return req.socket.remoteAddress || 'unknown'; }
function tooMany(req, res, bucket = 'write', max = 35, windowMs = 10 * 60 * 1000) {
  const key = `${bucket}:${clientKey(req)}`; const now = Date.now();
  const entry = rateBuckets.get(key) || { count: 0, until: now + windowMs };
  if (now > entry.until) { entry.count = 0; entry.until = now + windowMs; }
  entry.count++; rateBuckets.set(key, entry);
  if (rateBuckets.size > 6000) for (const [k, v] of rateBuckets) if (now > v.until) rateBuckets.delete(k);
  if (entry.count > max) { send(res, 429, { error: 'Too many requests. Please try again later.' }); return true; }
  return false;
}
function authorizedAdmin(req) {
  const key = req.headers['x-admin-key'];
  return Boolean(ADMIN_KEY && typeof key === 'string' && crypto.timingSafeEqual(Buffer.from(sha(key)), Buffer.from(sha(ADMIN_KEY))));
}
function versionStamp() {
  const entries = [path.join(ROOT, 'server.js'), path.join(PUBLIC, 'index.html'), path.join(PUBLIC, 'app.js'), path.join(PUBLIC, 'style.css'), path.join(PUBLIC, 'sw.js'), path.join(PUBLIC, 'manifest.webmanifest'), path.join(PUBLIC, 'icon.svg'), path.join(PUBLIC, 'icon-192.png'), path.join(PUBLIC, 'icon-512.png'), path.join(PUBLIC, 'privacy.html'), path.join(PUBLIC, 'community-guidelines.html')];
  return entries.map(f => { try { const s = fs.statSync(f); return `${path.basename(f)}:${s.mtimeMs}:${s.size}`; } catch { return f; } }).join('|');
}
function safeStatic(req, res, pathname) {
  if (pathname === '/') pathname = '/index.html';
  let decoded;
  try { decoded = decodeURIComponent(pathname); } catch { return send(res, 400, 'Bad path', 'text/plain; charset=utf-8'); }
  const target = path.resolve(PUBLIC, `.${decoded}`);
  if (!target.startsWith(path.resolve(PUBLIC) + path.sep) && target !== path.resolve(PUBLIC)) return send(res, 403, 'Forbidden', 'text/plain; charset=utf-8');
  fs.readFile(target, (error, data) => {
    if (error) return send(res, 404, 'Not found', 'text/plain; charset=utf-8');
    const mime = {
      '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
      '.svg': 'image/svg+xml', '.png': 'image/png', '.webmanifest': 'application/manifest+json; charset=utf-8', '.json': 'application/json; charset=utf-8', '.md': 'text/plain; charset=utf-8'
    }[path.extname(target)] || 'application/octet-stream';
    send(res, 200, data, mime, false);
  });
}



const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  try {
    if (req.method === 'GET' && url.pathname === '/api/health') {
      return send(res, 200, { ok: true, app: 'FindSure', version: '12.0.0', database: USE_SUPABASE ? 'Supabase PostgreSQL' : (IS_PROD ? 'local JSON (not suitable for hosted public persistence)' : 'local JSON (development)'), moderation: IS_PROD, devMode: !IS_PROD });
    }
    if (req.method === 'GET' && url.pathname === '/api/dev-version') return send(res, 200, { version: versionStamp() });
    if (req.method === 'GET' && url.pathname === '/api/reports') {
      const q = clean(url.searchParams.get('q'), 100).toLowerCase();
      const kind = clean(url.searchParams.get('kind'), 20); const itemType = clean(url.searchParams.get('type'), 30);
      const city = clean(url.searchParams.get('city'), 100).toLowerCase();
      let items = await allReports(false);
      items = items.filter(r => (!kind || kind === 'all' || r.listingType === kind) && (!itemType || itemType === 'all' || r.itemType === itemType) &&
        (!city || `${r.city} ${r.area}`.toLowerCase().includes(city)) && (!q || [r.title, r.description, r.identifier, r.city, r.area, r.itemType, r.listingType].join(' ').toLowerCase().includes(q)));
      return send(res, 200, { reports: items.map(toPublicReport) });
    }
    if (req.method === 'POST' && url.pathname === '/api/reports') {
      if (tooMany(req, res, 'reports', 20, 60 * 60 * 1000)) return;
      const b = await readBody(req);
      const listingType = clean(b.listingType, 10); const itemType = clean(b.itemType, 30);
      const title = clean(b.title, 100), city = clean(b.city, 100), area = clean(b.area, 100);
      const clientSubmissionId = clean(b.clientSubmissionId, 40).toUpperCase();
      const allowed = ['phone', 'laptop', 'tablet', 'desktop', 'camera', 'watch', 'headphones', 'bike', 'car', 'keys', 'bag', 'documents', 'other-electronics', 'other'];
      if (!['lost', 'found'].includes(listingType) || !allowed.includes(itemType) || !title || !city) return send(res, 400, { error: 'Please complete the report type, item category, title and city.' });
      if (clientSubmissionId && !/^[A-F0-9]{32}$/.test(clientSubmissionId)) return send(res, 400, { error: 'The report submission ID is invalid. Please retry from the FindSure page.' });
      // Offline retries reuse the same 128-bit client ID to avoid creating duplicate reports if a response was lost.
      if (clientSubmissionId) {
        const existing = await findReportBySubmissionId(clientSubmissionId);
        if (existing) return send(res, 200, { report: toPublicReport(existing), ownerCode: clientSubmissionId, message: 'This report was already received. Its private management code is unchanged.', idempotentReplay: true });
      }
      const ownerCode = clientSubmissionId || randomCode(); const hasCoords = validCoord(b.lat, b.lon);
      const r = {
        id: crypto.randomUUID(), listingType, itemType, title,
        description: clean(b.description, 1400), city, area,
        identifier: clean(b.identifier, 100), contact: clean(b.contact, 140), shareContact: b.shareContact === true,
        status: IS_PROD ? 'pending' : 'published', createdAt: new Date().toISOString(),
        // Public pins are deliberately approximate to avoid exposing someone's exact position.
        lat: hasCoords ? approximate(b.lat) : null, lon: hasCoords ? approximate(b.lon) : null, ownerHash: sha(ownerCode),
        clientSubmissionId
      };
      try {
        await insertReport(r);
      } catch (insertError) {
        // A concurrent retry can hit the Supabase unique index after the first request committed.
        if (clientSubmissionId) {
          const existing = await findReportBySubmissionId(clientSubmissionId);
          if (existing) return send(res, 200, { report: toPublicReport(existing), ownerCode: clientSubmissionId, message: 'This report was already received. Its private management code is unchanged.', idempotentReplay: true });
        }
        throw insertError;
      }
      return send(res, 201, { report: toPublicReport(r), ownerCode, message: IS_PROD ? 'Report received and waiting for moderator review.' : 'Report published in local test mode.' });
    }
    if (req.method === 'POST' && url.pathname === '/api/reports/mine') {
      if (tooMany(req, res, 'report-owner-lookup', 30, 60 * 60 * 1000)) return;
      const b = await readBody(req);
      const ownerCode = clean(b.ownerCode, 40).toUpperCase();
      if (!ownerCode) return send(res, 400, { error: 'Enter the private report management code.' });
      const report = await findReportByOwnerHash(sha(ownerCode));
      if (!report) return send(res, 404, { error: 'No report matches this private code. Check the code and try again.' });
      // This endpoint is private-code protected; it may return the owner's own contact details.
      const { ownerHash, ...safeReport } = report;
      return send(res, 200, { report: safeReport });
    }
    if (req.method === 'POST' && url.pathname === '/api/reports/delete') {
      if (tooMany(req, res, 'report-owner-delete', 12, 60 * 60 * 1000)) return;
      const b = await readBody(req); const id = clean(b.id, 60); const ownerCode = clean(b.ownerCode, 40).toUpperCase();
      if (!id || !ownerCode) return send(res, 400, { error: 'Report ID and private management code are required.' });
      const deleted = await deleteReportByOwner(id, sha(ownerCode));
      if (!deleted) return send(res, 404, { error: 'Report not found or private management code is incorrect.' });
      return send(res, 200, { ok: true, message: 'Your report has been deleted.' });
    }
    if (req.method === 'POST' && url.pathname === '/api/reports/close') {
      if (tooMany(req, res, 'close', 25)) return;
      const b = await readBody(req); const id = clean(b.id, 60); const code = clean(b.ownerCode, 40);
      if (!id || !code) return send(res, 400, { error: 'Report ID and owner code are required.' });
      const current = (await allReports(true)).find(r => r.id === id);
      if (!current) return send(res, 404, { error: 'Report not found.' });
      const updated = await updateReport(id, { status: 'resolved' }, sha(code));
      if (!updated) return send(res, 404, { error: 'Report not found or owner code is incorrect.' });
      return send(res, 200, { report: toPublicReport(updated) });
    }
    if (req.method === 'GET' && url.pathname === '/api/admin/reports') {
      if (!authorizedAdmin(req)) return send(res, 401, { error: 'Admin key is missing or incorrect.' });
      const items = await allReports(true);
      return send(res, 200, { reports: items.map(r => ({ ...toPublicReport(r), contact: r.contact, ownerHash: undefined })) });
    }
    if (req.method === 'POST' && url.pathname === '/api/admin/reports/moderate') {
      if (!authorizedAdmin(req)) return send(res, 401, { error: 'Admin key is missing or incorrect.' });
      const b = await readBody(req); const id = clean(b.id, 60); const status = clean(b.status, 20);
      if (!id || !['published', 'rejected'].includes(status)) return send(res, 400, { error: 'Invalid report or moderation status.' });
      const updated = await updateReport(id, { status });
      if (!updated) return send(res, 404, { error: 'Report not found.' });
      return send(res, 200, { report: toPublicReport(updated) });
    }
    if (req.method === 'POST' && url.pathname === '/api/abuse') {
      if (tooMany(req, res, 'abuse', 8, 24 * 60 * 60 * 1000)) return;
      const b = await readBody(req); const reportId = clean(b.reportId, 60); const reason = clean(b.reason, 40);
      const reasons = ['scam','personal-info','wrong-category','suspected-stolen','other'];
      if (!reportId || !reasons.includes(reason)) return send(res, 400, { error:'Choose a report and a valid concern reason.' });
      const reports = await allReports(true); const exists = reports.some(r => r.id === reportId && ['published','resolved'].includes(r.status));
      if (!exists) return send(res, 404, { error:'This public report could not be found.' });
      const complaint = { id:crypto.randomUUID(), reportId, reason, details:clean(b.details,500), status:'open', createdAt:new Date().toISOString() };
      await insertAbuseReport(complaint);
      return send(res, 201, { ok:true, message:'Thanks. Your safety concern has been sent to moderators.' });
    }
    if (req.method === 'GET' && url.pathname === '/api/admin/abuse') {
      if (!authorizedAdmin(req)) return send(res, 401, { error:'Admin key is missing or incorrect.' });
      return send(res, 200, { reports:await getAbuseReports() });
    }
    if (req.method === 'POST' && url.pathname === '/api/admin/abuse/close') {
      if (!authorizedAdmin(req)) return send(res, 401, { error:'Admin key is missing or incorrect.' });
      const b = await readBody(req); const id=clean(b.id,60); const status=clean(b.status,20);
      if (!id || !['reviewed','actioned'].includes(status)) return send(res,400,{error:'Invalid abuse report or resolution status.'});
      const updated = await updateAbuseReport(id,status); if (!updated) return send(res,404,{error:'Concern report not found.'});
      return send(res,200,{report:updated});
    }


    if (req.method === 'POST' && url.pathname === '/api/vehicle-trackers/register') {
      if (tooMany(req,res,'vehicle-tracker-register',5,60*60*1000)) return;
      const b=await readBody(req);
      const label=clean(b.label,80), vehicleType=clean(b.vehicleType,16).toLowerCase(), makeModel=clean(b.makeModel,100);
      if (!label || !['car','bike','other'].includes(vehicleType)) return send(res,400,{error:'Enter a vehicle name and choose car, bike or other.'});
      const code=randomCode();
      const device={id:crypto.randomUUID(),label,codeHash:sha(code),createdAt:new Date().toISOString(),lastLocation:null};
      await insertDevice(device);
      const credential=crypto.randomBytes(32).toString('hex');
      const tracker={id:crypto.randomUUID(),deviceId:device.id,label,vehicleType,makeModel,credentialHash:sha(credential),createdAt:new Date().toISOString(),revokedAt:null};
      await insertVehicleTracker(tracker);
      return send(res,201,{ok:true,vehicle:{id:tracker.id,label,vehicleType,makeModel,privateRecoveryCode:code},tracker:{id:tracker.id,apiKey:credential,endpoint:'/api/vehicle-trackers/telemetry',method:'POST',contentType:'application/json'},message:'Save the private recovery code and tracker API key separately. The API key is shown only once. Install the tracker on a vehicle you own or are authorised to manage.'});
    }
    if (req.method === 'POST' && url.pathname === '/api/vehicle-trackers/telemetry') {
      if (tooMany(req,res,'vehicle-telemetry',600,60*60*1000)) return;
      const auth=String(req.headers.authorization||'');
      const match=auth.match(/^Bearer\s+([a-f0-9]{64})$/i);
      if (!match) return send(res,401,{error:'Tracker API key is missing or invalid.'});
      const tracker=await findVehicleTrackerByCredentialHash(sha(match[1].toLowerCase()));
      if (!tracker) return send(res,401,{error:'Tracker key is invalid or has been revoked.'});
      const b=await readBody(req);
      if (!validCoord(b.lat,b.lon)) return send(res,400,{error:'Valid GNSS latitude and longitude are required.'});
      const capturedMs=Date.parse(String(b.capturedAt||'')); const now=Date.now();
      if (!Number.isFinite(capturedMs)||capturedMs>now+120000||capturedMs<now-48*60*60*1000) return send(res,400,{error:'capturedAt must be a valid UTC timestamp no older than 48 hours.'});
      const speed=b.speedKph==null?null:Number(b.speedKph), heading=b.heading==null?null:Number(b.heading), accuracy=b.accuracy==null?null:Number(b.accuracy), battery=b.batteryVoltage==null?null:Number(b.batteryVoltage);
      if (speed!==null&&(!Number.isFinite(speed)||speed<0||speed>400)) return send(res,400,{error:'Speed must be between 0 and 400 km/h.'});
      if (heading!==null&&(!Number.isFinite(heading)||heading<0||heading>=360)) return send(res,400,{error:'Heading must be from 0 to 359 degrees.'});
      if (accuracy!==null&&(!Number.isFinite(accuracy)||accuracy<0||accuracy>10000)) return send(res,400,{error:'Accuracy value is outside the allowed range.'});
      if (battery!==null&&(!Number.isFinite(battery)||battery<0||battery>60)) return send(res,400,{error:'Battery voltage is outside the allowed range.'});
      const zone=await timezoneForLocation(Number(b.lat),Number(b.lon),b.timeZone);
      const position={id:crypto.randomUUID(),trackerId:tracker.id,lat:Number(b.lat),lon:Number(b.lon),accuracy,speedKph:speed,heading,ignition:typeof b.ignition==='boolean'?b.ignition:null,batteryVoltage:battery,capturedAt:new Date(capturedMs).toISOString(),receivedAt:new Date().toISOString(),...zone};
      const saved=await insertVehiclePosition(position);
      return send(res,201,{ok:true,accepted:true,position:saved,message:'Vehicle location received. The owner can view it using the private recovery code.'});
    }
    if (req.method === 'POST' && url.pathname === '/api/vehicle-trackers/locate') {
      if (tooMany(req,res,'vehicle-tracker-locate',60,60*60*1000)) return;
      const b=await readBody(req); const code=clean(b.code,40).toUpperCase();
      if (!code) return send(res,400,{error:'Enter the private vehicle recovery code.'});
      const device=await findDevice(sha(code));
      if(!device) return send(res,404,{error:'No vehicle matches this private code.'});
      let tracker;
      if(USE_SUPABASE){const rows=await sbRequest(`vehicle_trackers?select=*&device_id=eq.${encodeURIComponent(device.id)}&revoked_at=is.null&order=created_at.desc&limit=1`);tracker=rows?.[0]?normalizeVehicleTracker(rows[0]):null;}
      else tracker=(readLocal().vehicleTrackers||[]).filter(t=>t.deviceId===device.id&&!t.revokedAt).sort((a,b)=>b.createdAt.localeCompare(a.createdAt))[0]||null;
      if(!tracker)return send(res,404,{error:'No active GPS tracker is registered for this vehicle.'});
      const position=await latestVehiclePosition(tracker.id);
      return send(res,200,{vehicle:{id:tracker.id,label:tracker.label,vehicleType:tracker.vehicleType,makeModel:tracker.makeModel,position}});
    }
    if (req.method === 'POST' && url.pathname === '/api/vehicle-trackers/revoke') {
      if (tooMany(req,res,'vehicle-tracker-revoke',8,60*60*1000)) return;
      const b=await readBody(req); const code=clean(b.code,40).toUpperCase(), trackerId=clean(b.trackerId,50);
      const device=code?await findDevice(sha(code)):null;
      if(!device||!trackerId)return send(res,400,{error:'Private recovery code and tracker ID are required.'});
      const ok=await revokeVehicleTracker(trackerId,device.id);
      if(!ok)return send(res,404,{error:'Active tracker not found or already revoked.'});
      return send(res,200,{ok:true,message:'Tracker API key revoked. New telemetry from it will be rejected.'});
    }
    if (req.method === 'POST' && url.pathname === '/api/devices/register') {
      if (tooMany(req, res, 'device-register', 10, 60 * 60 * 1000)) return;
      const b = await readBody(req); const label = clean(b.label, 80);
      if (!label) return send(res, 400, { error: 'Enter a device name.' });
      const code = randomCode();
      const d = { id: crypto.randomUUID(), label, codeHash: sha(code), createdAt: new Date().toISOString(), lastLocation: null };
      await insertDevice(d);
      return send(res, 201, { device: { id: d.id, label, code, createdAt: d.createdAt }, message: 'Keep this private code safe. It grants access to the last location shared by this device.' });
    }
    if (req.method === 'POST' && url.pathname === '/api/devices/check-in') {
      if (tooMany(req, res, 'device-checkin', 120, 60 * 60 * 1000)) return;
      const b = await readBody(req); const code = clean(b.code, 40).toUpperCase();
      if (!validCoord(b.lat, b.lon)) return send(res, 400, { error: 'Valid coordinates are required.' });
      const d = await findDevice(sha(code)); if (!d) return send(res, 404, { error: 'Device code not found. Register the phone first.' });
      const updatedAt = new Date().toISOString();
      const maybeCaptured = Date.parse(String(b.capturedAt || ''));
      const capturedAt = Number.isFinite(maybeCaptured) && maybeCaptured <= Date.now() + 60_000 && maybeCaptured >= Date.now() - 90 * 24 * 60 * 60 * 1000 ? new Date(maybeCaptured).toISOString() : updatedAt;
      const zone = await timezoneForLocation(Number(b.lat), Number(b.lon), b.timeZone);
      const location = { lat: Number(b.lat), lon: Number(b.lon), accuracy: Number.isFinite(Number(b.accuracy)) ? Number(b.accuracy) : null, capturedAt, updatedAt, ...zone };
      const updated = await saveDeviceLocation(d.id, location);
      return send(res, 200, { ok: true, device: { label: updated.label, lastLocation: updated.lastLocation } });
    }
    if (req.method === 'POST' && url.pathname === '/api/devices/locate') {
      if (tooMany(req, res, 'device-locate', 90, 60 * 60 * 1000)) return;
      const b = await readBody(req); const code = clean(b.code, 40).toUpperCase();
      if (!code) return send(res, 400, { error: 'Enter the private device code.' });
      const d = await findDevice(sha(code));
      if (!d) return send(res, 404, { error: 'No registered device matches this code.' });
      const lastBeaconSighting = await latestBeaconSighting(d.id);
      return send(res, 200, { device: { label: d.label, lastLocation: d.lastLocation, lastBeaconSighting } });
    }
    if (req.method === 'POST' && url.pathname === '/api/beacon/tags/provision') {
      if (tooMany(req, res, 'beacon-tag-provision', 6, 60 * 60 * 1000)) return;
      const b = await readBody(req); const code = clean(b.code, 40).toUpperCase();
      const device = code ? await findDevice(sha(code)) : null;
      if (!device) return send(res, 404, { error: 'Private device code not found. Register the item first.' });
      const credential = crypto.randomBytes(32).toString('hex');
      const tag = { id: crypto.randomUUID(), deviceId: device.id, label: clean(b.label || 'FindSure external BLE tag', 80), credentialHash: sha(credential), createdAt: new Date().toISOString(), revokedAt: null };
      await insertBeaconTag(tag);
      const tokens = await ensureTagBeaconTokens(tag.id, tag.deviceId);
      return send(res, 201, { ok: true, tagId: tag.id, label: tag.label, credential, serviceUuid: '4d1b3b6a-4e2b-4d59-a8fa-4f5a1b2c3d4e', slotMinutes: 15, cachedTokens: tokens.length, message: 'Save this tag credential privately. It is shown only once and cannot retrieve the device location. This experimental tag can help find an item only while the separate tag has power and is detected by the FindSure network.' });
    }
    if (req.method === 'POST' && url.pathname === '/api/beacon/tags/tokens') {
      if (tooMany(req, res, 'beacon-tag-token-refresh', 24, 60 * 60 * 1000)) return;
      const b = await readBody(req); const credential = clean(b.credential, 64).toLowerCase();
      if (!/^[a-f0-9]{64}$/.test(credential)) return send(res, 400, { error: 'A valid tag-only credential is required.' });
      const tag = await findBeaconTagByCredentialHash(sha(credential));
      if (!tag) return send(res, 401, { error: 'Tag credential is invalid or has been revoked.' });
      const tokens = await ensureTagBeaconTokens(tag.id, tag.deviceId);
      return send(res, 200, { tagId: tag.id, label: tag.label, serviceUuid: '4d1b3b6a-4e2b-4d59-a8fa-4f5a1b2c3d4e', slotMinutes: 15, tokens, message: 'These rotating tokens are only for this external tag. Cached tokens stop being accepted after the tag is revoked.' });
    }
    if (req.method === 'POST' && url.pathname === '/api/beacon/tags/revoke') {
      if (tooMany(req, res, 'beacon-tag-revoke', 10, 60 * 60 * 1000)) return;
      const b = await readBody(req); const code = clean(b.code, 40).toUpperCase(); const tagId = clean(b.tagId, 40);
      const device = code ? await findDevice(sha(code)) : null;
      if (!device || !tagId) return send(res, 400, { error: 'The owner device code and tag ID are required.' });
      const revoked = await revokeBeaconTag(tagId, device.id);
      if (!revoked) return send(res, 404, { error: 'Active tag not found for this device. It may already be revoked.' });
      return send(res, 200, { ok: true, revoked: true, message: 'Tag revoked. The server will reject sightings from its cached tokens.' });
    }
    if (req.method === 'POST' && url.pathname === '/api/beacon/tokens') {
      if (tooMany(req, res, 'beacon-tokens', 12, 60 * 60 * 1000)) return;
      const b = await readBody(req); const code = clean(b.code, 40).toUpperCase();
      if (!code) return send(res, 400, { error: 'Enter the private device code to prepare its offline beacon.' });
      const d = await findDevice(sha(code));
      if (!d) return send(res, 404, { error: 'Device code not found. Register this device first.' });
      const tokens = await ensureBeaconTokens(d.id);
      return send(res, 200, { deviceLabel: d.label, slotMinutes: 15, validFrom: new Date(beaconSlot()*BEACON_SLOT_MS).toISOString(), tokens, note: 'Rotating BLE tokens are intended for consenting FindSure pilot devices. They do not make a normal phone discoverable when powered off.' });
    }
    if (req.method === 'POST' && url.pathname === '/api/beacon/sightings') {
      if (tooMany(req, res, 'beacon-sightings', 120, 60 * 60 * 1000)) return;
      const b = await readBody(req); const token = clean(b.token, 32).toUpperCase();
      if (!/^[A-F0-9]{16}$/.test(token) || !validCoord(b.lat, b.lon)) return send(res, 400, { error: 'A valid rotating token and relay GPS coordinates are required.' });
      const tokenRow = await findBeaconToken(token);
      if (!tokenRow) return send(res, 404, { error: 'Unknown or expired beacon token.' });
      const capturedMs = Date.parse(String(b.capturedAt || ''));
      const slotStart = tokenRow.slot * BEACON_SLOT_MS; const slotEnd = slotStart + BEACON_SLOT_MS;
      const now = Date.now();
      if (!Number.isFinite(capturedMs) || capturedMs < slotStart - 60_000 || capturedMs > slotEnd + 60_000 || capturedMs > now + 120_000 || now - capturedMs > 8 * 24 * 60 * 60 * 1000) {
        return send(res, 400, { error: 'Detection timestamp does not match this rotating token window.' });
      }
      const lat = Number(b.lat), lon = Number(b.lon);
      const zone = await timezoneForLocation(lat, lon, b.timeZone);
      const row = await saveBeaconSighting({
        id: crypto.randomUUID(), deviceId: tokenRow.deviceId, tokenSlot: tokenRow.slot,
        lat, lon, accuracy: Number.isFinite(Number(b.accuracy)) ? Number(b.accuracy) : null,
        capturedAt: new Date(capturedMs).toISOString(),
        gpsCapturedAt: (() => { const gpsMs = Date.parse(String(b.gpsCapturedAt || b.capturedAt)); return Number.isFinite(gpsMs) && gpsMs <= now + 120_000 && gpsMs >= now - 10 * 60 * 1000 ? new Date(gpsMs).toISOString() : new Date(capturedMs).toISOString(); })(),
        receivedAt: new Date().toISOString(), ...zone,
        finderPlatform: ['android','ios','web'].includes(clean(b.finderPlatform, 20).toLowerCase()) ? clean(b.finderPlatform, 20).toLowerCase() : 'android'
      });
      return send(res, 201, { ok: true, accepted: true, receivedAt: row.receivedAt, message: 'Beacon sighting received. The owner can view it with the private device code.' });
    }
    if (req.method === 'GET' && url.pathname === '/api/map-issue') return send(res, 200, { url: 'https://www.openstreetmap.org/fixthemap' });
    if (req.method === 'GET' && !url.pathname.startsWith('/api/')) return safeStatic(req, res, url.pathname);
    return send(res, 404, { error: 'Endpoint not found.' });
  } catch (error) {
    console.error('[FindSure]', error.message);
    if (!res.headersSent) send(res, 500, { error: USE_SUPABASE ? 'Server or database error. Check host logs and database setup.' : 'Something went wrong. Check the local server window.' });
  }
});
server.requestTimeout = 20_000;
server.headersTimeout = 25_000;
server.listen(PORT, '0.0.0.0', () => {
  console.log(`\nFindSure v12.0 is running: http://localhost:${PORT}`);
  console.log(`Storage: ${USE_SUPABASE ? 'Supabase PostgreSQL' : 'local JSON database (demo only)'}`);
  console.log(`Mode: ${IS_PROD ? 'production (new public reports need moderation)' : 'development (reports publish immediately)'}`);
  if (!USE_SUPABASE && IS_PROD) console.warn('WARNING: Production mode is enabled without Supabase; local JSON storage will not persist on many cloud hosts. Configure the database before public launch.');
  console.log('Keep this window open. Development launcher watches server.js for changes; the browser refreshes when frontend files change.\n');
});
