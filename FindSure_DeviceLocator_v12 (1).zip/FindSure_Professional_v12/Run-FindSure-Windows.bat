@echo off
setlocal
cd /d "%~dp0"
title FindSure Recovery Network v12.0
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js was not found. Please install the Node.js Windows .msi package, then try again.
  pause
  exit /b 1
)
echo.
echo FindSure Recovery Network v12.0
node -v
echo.
echo Starting server with automatic restart on backend edits...
echo Browser assets auto-refresh when you edit the frontend files.
echo Once the message says FindSure is running, open http://localhost:3000
 echo Press Ctrl+C to stop the development server.
echo.
node --watch server.js
pause
