# FindSure v12.0 release notes

- Device locator now foregrounds the exact two-device private-code workflow.
- Both device registration/sharing and code-based locating are visible on one page.
- Locate result renders the latest available location, map pin, capture timestamp, server receive time, accuracy and source.
- Manual one-shot share and visible one-minute near-live sharing are provided.
- Auto-refresh on the finder checks for newer readings every minute.
- Home CTA and navigation explicitly point users to code-based locator.
- Official Android, Apple, Samsung and Windows finders remain available as a secondary recovery panel.
- Report/community and vehicle recovery functions are retained but are not allowed to obscure the core device-code flow.
- No claim of universal offline or power-off tracking.
