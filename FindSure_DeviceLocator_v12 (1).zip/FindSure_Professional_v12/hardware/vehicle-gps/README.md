# FindSure DIY Vehicle GPS Tracker — Prototype Design

This is a hardware integration guide for a tracker fitted to a vehicle that you own or are authorised to manage. It is a prototype design, not a certified product or a ready-to-install automotive PCB.

## What the tracker does

1. A GNSS receiver obtains latitude/longitude, fix time, accuracy and optionally speed/heading.
2. A cellular modem sends those readings to the FindSure HTTPS telemetry endpoint using its unique device API key.
3. FindSure stores the reading and returns it only after the owner enters the vehicle's private recovery code.
4. If cellular data is unavailable, firmware should store timestamped points in flash/SD and upload them when the connection returns. A remote viewer cannot see a newly captured point until it is uploaded.
5. If the vehicle ignition is off, the tracker can keep running from a fused permanent supply and its own backup battery. If the tracker itself loses all power, it cannot transmit.

## Recommended prototype parts

- ESP32 development board (ESP32-WROOM/S3 class) as the controller.
- SIMCom SIM7600 LTE + GNSS development board, with the exact regional SKU/bands checked against the SIM operator you plan to use. SIM7600E and SIM7600G R2 are different band variants; do not buy only by the family name.
- Main cellular antenna and GNSS antenna suitable for the selected board/module.
- A SIM with an active data package/APN from a local operator. Ask the operator for M2M/IoT suitability and confirm coverage where the vehicle will travel.
- Automotive-rated 12 V input protection stage: fuse near the source, reverse-polarity protection, transient/TVS protection and a high-quality DC-DC converter sized for the module's burst current.
- A correctly engineered backup battery, charger/power-path circuit, low-voltage cutoff and battery monitoring. Never connect a bare Li-ion cell directly to a vehicle supply.
- Enclosure, strain relief, suitable connectors and temperature/vibration-resistant mounting.
- Optional ignition-sense input, tamper switch and microSD/flash storage. Use an isolated/protected input designed by an automotive electronics engineer.

SIMCom lists SIM7600 LTE and integrated multi-constellation GNSS for telematics. The module supply range is 3.4–4.2 V; the hardware design says transmit bursts can reach about 2 A and VBAT must not drop below 3.4 V. Design the power stage from the exact selected module's latest hardware manual, not from a generic USB cable or low-cost regulator. Official family page: https://www.simcom.com/product/SIM7600.html

## Important Pakistan checks

- Before buying the modem, compare its exact LTE band list with the mobile operator and area where it will be used. Band information and operator deployments can change; ask the operator for confirmation.
- SIM/IMEI-capable tracking systems are explicitly included in Pakistan's 2025 type-approval technical amendment category list. Check current PTA type-approval and CoC requirements for the exact model before import, sale or commercial deployment. A DIY prototype is not automatically approved for public sale. Reference: https://www.tipp.gov.pk/site/display/109
- Use a lawful SIM subscription and obtain consent from the vehicle owner/authorised fleet manager. Do not install a tracker on someone else's vehicle without permission.

## Power and installation safety

**Do not connect a bare SIM7600 module directly to the car's 12 V battery.** Its VBAT input is around 3.8 V nominal and may need 2 A burst current. Use a designed automotive input stage, fuse, TVS/transient protection and a stable DC-DC supply.

Vehicle electrical systems can produce reverse polarity, cranking dips, load-dump spikes, vibration, moisture and high temperatures. A low-cost hobby buck converter and loose wires are not an automotive-safe installation. First test the electronics on a current-limited bench supply. Have a qualified automotive electrician install a fused circuit. Do not cut immobiliser, ignition, CAN-bus or safety wiring; do not add a remote engine-disable feature.

## Data contract to FindSure

When you create a vehicle under **Vehicle GPS** in FindSure, the app returns:

- a private owner recovery code (keep it with the owner; use it to look up the map),
- a separate tracker API key (keep it inside the tracker configuration only),
- the telemetry endpoint: `POST https://YOUR-FINDSURE-HOST/api/vehicle-trackers/telemetry`.

Send the API key in the `Authorization: Bearer YOUR_64_CHARACTER_KEY` header and send JSON:

```json
{
  "lat": 24.8607,
  "lon": 67.0011,
  "accuracy": 8.5,
  "speedKph": 0,
  "heading": 90,
  "ignition": false,
  "batteryVoltage": 12.6,
  "capturedAt": "2026-11-04T05:00:00.000Z"
}
```

All coordinates must be valid WGS84 decimal degrees. `capturedAt` is the time the GNSS fix was taken in ISO-8601 UTC. `ignition` and battery voltage are optional. Never send a fabricated coordinate or fake the capture time.

The API key is shown once and stored on the server as a SHA-256 hash. If a key is exposed, use **Revoke tracker key** in FindSure and provision a replacement tracker. The owner recovery code is not a hardware API key; never put it in firmware or expose it to a volunteer scanner.

## Firmware implementation stages

1. Bench test the ESP32 UART link to the selected modem; verify `AT`, SIM readiness, LTE registration and GNSS fix.
2. Verify the modem's LTE band support and APN with the actual SIM/operator.
3. Configure TLS with certificate validation. Do not disable certificate checks and do not send owner/device secrets over plain HTTP.
4. Build the telemetry JSON from real GNSS fixes; include capture time, accuracy and optional speed/heading.
5. Add a bounded offline queue (for example, a ring buffer in flash/SD) and retry with backoff after mobile data returns.
6. Add watchdog, brownout handling, voltage measurement and safe power-down; never corrupt queued data during cranking dips.
7. Bench-test, then test in a stationary vehicle, then road-test with consent; check GPS accuracy, reconnects, backup runtime and thermal behaviour.
8. Get the PCB, RF design, enclosure, automotive power stage and regulatory path reviewed before any public sale or life-safety claims.

### TLS library caution

The TinyGSM project lists SIM7600 support but currently says its `TinyGsmClientSecure` TLS client is not yet supported for SIM7500/7600/7800. Do not assume that class gives you HTTPS on SIM7600. Use the modem's documented SIMCom SSL/TLS AT-command path with a trusted root CA provisioned, or select an architecture/modem with verified end-to-end TLS support. Test certificate validation and hostname checking. References:
- TinyGSM support matrix: https://github.com/vshymanskyy/TinyGSM
- SIMCom SSL AT-command manual: https://simcom.ee/documents/SIM7X00/SIM7500_SIM7600_SIM7800%20Series_SSL_AT%20Command%20Manual_V1.00.pdf

## What this cannot do

- A SIM/GNSS tracker can report its location while the car's ignition is off only if the tracker still has power and has a working GNSS fix plus a usable uplink.
- Without cellular coverage, it can buffer points locally but cannot send a fresh point to FindSure at that moment. Satellite messaging requires a different modem, antenna, subscription and regulatory path.
- A vehicle plate, engine number or chassis number is an identity clue, not a GPS transmitter.
- This guide is a design reference. No physical prototype has been built, bench-tested, installed or certified as part of this source package.
