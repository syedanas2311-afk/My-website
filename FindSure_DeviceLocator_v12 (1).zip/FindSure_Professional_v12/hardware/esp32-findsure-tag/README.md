# FindSure External BLE Tag — Lab Prototype

This is a reference firmware sketch for an independently powered external tag. Attach the tag to an item before it goes missing. Because the tag has its own battery and BLE radio, it may advertise while the phone/laptop attached to it is powered off.

**It does not locate arbitrary powered-off phones by IMEI.** If no independent tag was attached before the loss and the device's OEM offline finder does not support that model, FindSure cannot retroactively add a radio or retrieve a GPS fix.

## What is required

- An ESP32-C3/ESP32 BLE development board and a separate battery/power source. This board is for the lab proof of concept; it is not optimized for coin-cell battery life.
- FindSure hosted at a public HTTPS URL with the current v6 `supabase-schema.sql` applied, including `device_beacon_tags` and `device_beacon_tag_tokens`.
- Two or more Android phones with the FindSure companion APK built from `android-companion/`: one scanner/volunteer phone per sighting area, plus one web dashboard for the owner.
- Arduino IDE with ESP32 Arduino core **2.0.17** (the sketch uses that version’s classic BLE API), ArduinoJson 6.x, built-in BLE libraries and LittleFS. The current ESP32 core 3.x BLE API differs; port and compile-test the sketch before choosing core 3.x.
- A verified TLS root CA configured in the sketch; the code refuses to bypass HTTPS validation.

## Setup

1. Open the FindSure website over HTTPS and register the item in **Set up FindSure**. Save its private device code.
2. In **Prepare a separate FindSure beacon tag**, enter that owner code and generate a tag-only credential. Save the 64-character credential; it is shown only once. This credential can fetch tokens for broadcasting, but cannot look up the item location.
3. Make a copy of `FindSureTagConfig.example.h` named `FindSureTagConfig.h` in the same folder. Fill in the Wi-Fi settings, the public HTTPS base URL, a verified TLS root CA, and the tag-only credential. Never place the owner private device code in firmware.
4. Open `FindSureTag.ino` in Arduino IDE and build/flash the sketch. Build and flash the board. Open Serial Monitor; the tag should sync time, refresh its token cache, and advertise a rotating 8-byte token with the FindSure-specific service UUID.
5. Use the Android companion in volunteer/scanner mode on a nearby phone. The finding phone should have Bluetooth and location permission, consent enabled, and internet access to upload detections (or store queued detections locally until it reconnects).
6. Use the owner's private device code on the FindSure dashboard to see the most recent reported sighting.
7. If the tag is lost, revoke it in the setup panel. Once revoked at the server, the server rejects all cached tokens from that tag.

## Honest behavior / limits

- This can report a **nearby finder phone's location at the time it detects the tag**. It is an approximate sighting, not GPS read directly from the tagged item.
- The tag needs its own battery and BLE radio, must remain powered, and must have a valid time source to choose the 15-minute token. On boot with no Wi-Fi/NTP, the prototype pauses advertising instead of using the wrong token. Add a tested RTC module/secure time scheme for production.
- Token refresh needs internet periodically. Cache covers a limited future window; refresh before it expires.
- It is not a Google Find Hub, Apple Find My or Samsung Find accessory. Community reach depends on how many volunteer phones run the FindSure companion. Network privacy, token replay/spoofing and unwanted-tracking mitigations need independent review before public rollout.
- The sketch has **not been compiled or tested on physical hardware in this environment**. Treat it as a developer lab prototype, not a shipping consumer tracker.

## Official path for true platform-powered-off finding

Google's Find Hub Partner Integration Guide says there is no specific SDK/API for general integration and asks prospective hardware partners to review the accessory specification and submit a device proposal. Apple requires MFi program enrollment for Find My accessories. FindSure would need official approval, compliant firmware/hardware, anti-stalking features and partner testing to use those networks.

- Google partner guide: https://developers.google.com/nearby/fast-pair/landing-page-find-hub
- Google FMDN specification: https://developers.google.com/nearby/fast-pair/specifications/extensions/fmdn
- Apple Find My accessory program: https://developer.apple.com/find-my/
