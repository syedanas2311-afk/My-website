#pragma once
// Copy this file to FindSureTagConfig.h and fill in your own secrets.
// The real FindSureTagConfig.h is gitignored; never upload it to GitHub or share it.

static const char *WIFI_SSID = "REPLACE_WITH_WIFI_NAME";
static const char *WIFI_PASSWORD = "REPLACE_WITH_WIFI_PASSWORD";
static const char *FINDSURE_BASE_URL = "https://YOUR-PUBLIC-FINDSURE-DOMAIN";
// Paste the verified root CA PEM for the HTTPS certificate chain used by your host.
// Keep certificate verification enabled; never replace it with setInsecure().
static const char *TLS_ROOT_CA_PEM = R"CERT(
PASTE_VERIFIED_ROOT_CA_PEM_HERE
)CERT";
// This is the scoped tag-only credential shown once by FindSure. Do not use the owner private device code.
static const char *TAG_CREDENTIAL = "PASTE_64_HEX_CHARACTER_TAG_CREDENTIAL_HERE";
