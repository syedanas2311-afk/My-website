/*
 * FindSure External BLE Tag — v6 experimental proof of concept
 * Board target: ESP32-C3/ESP32 development board with BLE + Wi-Fi.
 * Libraries: ESP32 Arduino core, ArduinoJson 6.x, built-in BLE, LittleFS.
 *
 * IMPORTANT:
 * - This independent tag can broadcast while the phone/laptop it is attached to is OFF,
 *   because the tag has its own battery. It does not make the host device's own radio work.
 * - Copy FindSureTagConfig.example.h to FindSureTagConfig.h and set Wi-Fi credentials,
 *   public HTTPS URL, tag-only credential, and a verified TLS root CA. Never disable TLS validation.
 * - Experimental pilot only. Not Google/Apple/Samsung certified and not safety-critical.
 */
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <LittleFS.h>
#include <BLEDevice.h>
#include <BLEUtils.h>
#include <BLEAdvertising.h>
#include <time.h>
#include <string>
#include "FindSureTagConfig.h"

static const char *SERVICE_UUID = "4d1b3b6a-4e2b-4d59-a8fa-4f5a1b2c3d4e";
static const uint32_t SLOT_SECONDS = 15 * 60;
static const uint32_t TOKEN_REFRESH_MS = 6UL * 60UL * 60UL * 1000UL;
static const char *TOKEN_FILE = "/tokens.json";

BLEAdvertising *advertiser = nullptr;
String activeToken;
uint64_t activeSlot = 0;
uint32_t lastRefreshMs = 0;
uint32_t lastClockTryMs = 0;
bool clockIsValid = false;

bool configurationReady() {
  const bool caReady = strstr(TLS_ROOT_CA_PEM, "BEGIN CERTIFICATE") != nullptr &&
                       strstr(TLS_ROOT_CA_PEM, "PASTE_VERIFIED") == nullptr;
  const bool urlReady = strstr(FINDSURE_BASE_URL, "YOUR-PUBLIC") == nullptr &&
                        strncmp(FINDSURE_BASE_URL, "https://", 8) == 0;
  const bool credentialReady = strlen(TAG_CREDENTIAL) == 64 &&
                               strstr(TAG_CREDENTIAL, "PASTE_") == nullptr;
  return caReady && urlReady && credentialReady &&
         strcmp(WIFI_SSID, "REPLACE_WITH_WIFI_NAME") != 0;
}

bool connectWiFi(uint32_t waitMs = 12000) {
  if (WiFi.status() == WL_CONNECTED) return true;
  if (strcmp(WIFI_SSID, "REPLACE_WITH_WIFI_NAME") == 0) return false;
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  const uint32_t started = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - started < waitMs) delay(250);
  return WiFi.status() == WL_CONNECTED;
}

bool syncClock() {
  if (!connectWiFi()) return false;
  configTime(0, 0, "pool.ntp.org", "time.google.com", "time.cloudflare.com");
  const uint32_t started = millis();
  time_t now = time(nullptr);
  while (now < 1760000000 && millis() - started < 12000) {
    delay(250);
    now = time(nullptr);
  }
  clockIsValid = now >= 1760000000;
  return clockIsValid;
}

bool refreshTokenCache() {
  if (!configurationReady()) {
    Serial.println("SETUP REQUIRED: enter HTTPS URL, a valid TLS root CA, Wi-Fi, and the tag-only credential.");
    return false;
  }
  if (!connectWiFi() || !syncClock()) {
    Serial.println("Cannot refresh tokens now. Cached tokens are retained; time must remain accurate.");
    return false;
  }

  WiFiClientSecure client;
  client.setCACert(TLS_ROOT_CA_PEM);  // fail closed; do not use setInsecure()
  HTTPClient http;
  const String endpoint = String(FINDSURE_BASE_URL) + "/api/beacon/tags/tokens";
  if (!http.begin(client, endpoint)) {
    Serial.println("HTTPS setup failed.");
    return false;
  }
  http.addHeader("Content-Type", "application/json");
  http.setConnectTimeout(8000);
  http.setTimeout(12000);
  StaticJsonDocument<160> request;
  request["credential"] = TAG_CREDENTIAL;
  String body;
  serializeJson(request, body);
  const int status = http.POST(body);
  const String response = status > 0 ? http.getString() : String();
  http.end();
  if (status != 200 || response.length() < 20) {
    Serial.printf("Token refresh rejected/failed (HTTP %d). Cached tokens retained.\n", status);
    return false;
  }

  DynamicJsonDocument check(65536);
  const auto err = deserializeJson(check, response);
  if (err || !check["tokens"].is<JsonArray>()) {
    Serial.println("Server response did not contain valid rotating tokens.");
    return false;
  }
  File file = LittleFS.open(TOKEN_FILE, "w");
  if (!file) {
    Serial.println("Unable to save token cache to flash.");
    return false;
  }
  const size_t written = serializeJson(check, file);
  file.close();
  if (written == 0) return false;
  lastRefreshMs = millis();
  Serial.println("Rotating token cache refreshed and saved privately.");
  return true;
}

String tokenForCurrentSlot(uint64_t slot) {
  File file = LittleFS.open(TOKEN_FILE, "r");
  if (!file) return String();
  DynamicJsonDocument doc(65536);
  const auto err = deserializeJson(doc, file);
  file.close();
  if (err) return String();
  JsonArray tokens = doc["tokens"].as<JsonArray>();
  for (JsonObject item : tokens) {
    if (item["slot"].as<uint64_t>() == slot) {
      String token = item["token"] | "";
      token.toUpperCase();
      if (token.length() == 16) return token;
    }
  }
  return String();
}

void stopBeacon() {
  if (advertiser) advertiser->stop();
  activeToken = "";
  activeSlot = 0;
}

void advertiseToken(const String &token, uint64_t slot) {
  if (!advertiser || token.length() != 16 || !clockIsValid) return;
  uint8_t bytes[8];
  for (int i = 0; i < 8; ++i) {
    char pair[3] = { token[i * 2], token[i * 2 + 1], 0 };
    bytes[i] = (uint8_t)strtoul(pair, nullptr, 16);
  }
  const std::string payload((const char *)bytes, sizeof(bytes));
  BLEAdvertisementData advertisement;
  advertisement.setFlags(0x06);
  advertisement.setServiceData(BLEUUID(SERVICE_UUID), payload);
  advertiser->stop();
  advertiser->setAdvertisementData(advertisement);
  BLEAdvertisementData emptyScanResponse;
  advertiser->setScanResponseData(emptyScanResponse);
  advertiser->start();
  activeToken = token;
  activeSlot = slot;
  Serial.printf("FindSure BLE tag advertising slot %llu. Token is not printed.\n", (unsigned long long)slot);
}

void refreshBeaconForCurrentSlot() {
  const time_t now = time(nullptr);
  if (!clockIsValid || now < 1760000000) {
    clockIsValid = false;
    stopBeacon();
    Serial.println("No trusted time. Beacon paused until NTP is available; this prevents wrong-slot tokens.");
    return;
  }
  const uint64_t slot = (uint64_t)now / SLOT_SECONDS;
  if (activeSlot == slot && activeToken.length() == 16) return;
  const String token = tokenForCurrentSlot(slot);
  if (token.length() != 16) {
    stopBeacon();
    Serial.println("No token cached for current slot. Reconnect to internet to refresh the cache.");
    return;
  }
  advertiseToken(token, slot);
}

void setup() {
  Serial.begin(115200);
  delay(300);
  if (!LittleFS.begin(true)) {
    Serial.println("LittleFS mount failed; cannot store tokens.");
    return;
  }
  BLEDevice::init("FindSureTag");
  advertiser = BLEDevice::getAdvertising();
  BLEDevice::setPower(ESP_PWR_LVL_N9);
  const bool timeReady = syncClock();
  if (timeReady) refreshTokenCache();
  refreshBeaconForCurrentSlot();
  if (WiFi.status() == WL_CONNECTED) WiFi.disconnect(true, false);
  lastRefreshMs = millis();
  Serial.println("FindSure external tag pilot running. Keep tag battery powered; the tagged phone/item may be off.");
}

void loop() {
  if (!clockIsValid && millis() - lastClockTryMs >= 30000UL) {
    lastClockTryMs = millis();
    if (syncClock()) {
      refreshTokenCache();
      lastRefreshMs = millis();
      if (WiFi.status() == WL_CONNECTED) WiFi.disconnect(true, false);
    }
  }
  if (clockIsValid && millis() - lastRefreshMs >= TOKEN_REFRESH_MS) {
    if (syncClock()) refreshTokenCache();
    lastRefreshMs = millis();
    if (WiFi.status() == WL_CONNECTED) WiFi.disconnect(true, false);
  }
  refreshBeaconForCurrentSlot();
  delay(1000);
}
