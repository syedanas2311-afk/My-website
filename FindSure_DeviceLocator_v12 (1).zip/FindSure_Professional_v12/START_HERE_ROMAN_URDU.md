# FindSure v12 — Roman Urdu Start Guide

## Sabse pehle
FindSure mein asal code-based location ka do-device process hai.

### A. Jis device ko future mein dhoondhna hai
1. Usi phone/computer par FindSure kholo.
2. **Device locator** page kholo.
3. **Set up location sharing** card mein device ka naam likho.
4. **Create my device code** dabao. Code ko private jagah save karo.
5. **Private device code** field auto-fill hoti hai.
6. **Send one location update** dabao aur browser ki location permission allow karo.
7. Phir **Start live location sharing** dabao. Is page ko khula rakho.

### B. Doosre phone/computer se location dekhna
1. Doosre device par bhi wohi FindSure website kholo.
2. **Device locator** page kholo.
3. Permission checkbox tick karo.
4. Pehle device ka private code paste karo.
5. **Find device location** dabao.
6. Map pin, GPS time, server upload time aur accuracy nazar aayegi.
7. Nayi reading dekhne ke liye **Auto-refresh every minute** dabao.

## Zaroori baat: localhost vs public website
`http://localhost:3000` sirf usi laptop ka address hai. Doosra mobile apne `localhost` par aapke laptop ka server nahi dekh sakta. Do devices ke darmiyan test ke liye website ko public HTTPS hosting par deploy karna hoga. Browser GPS ke liye HTTPS zaroori hai (localhost testing exception hai).

## Live location ka matlab
- Har minute ke qareeb update tabhi milegi jab target device internet/GPS permission ke saath location bhej raha ho.
- Target page ko khula rakhein. Mobile browser background mein updates rok sakta hai.
- Agar internet band ho, nayi location doosre mobile ko foran nahi milegi. Purani last-known location aur uska time dikhega.
- Agar phone poori tarah band ho, normal app uske GPS/Bluetooth se nayi location nahi bhej sakti. Supported manufacturer offline network ya pehle se attached powered tracker ki zaroorat hoti hai.

## Troubleshooting
- Code not found: check karein ke wohi code poora paste hua hai.
- No location available: pehle target device par **Send one location update** karein.
- Location permission denied: browser/site settings mein Location allow karein.
- Map blank: internet connection check karein.
- Doosra phone connect nahi hota: public HTTPS deployment use karein, laptop ka localhost nahi.

## Public launch abhi baqi
Hosting, Supabase persistent database, strong admin key, moderation, HTTPS aur real Android/iPhone tests complete karna zaroori hai. Yeh ZIP local development prototype hai, pehle real two-device pilot karein.
