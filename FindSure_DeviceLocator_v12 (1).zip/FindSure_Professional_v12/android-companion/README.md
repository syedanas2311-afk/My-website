# FindSure Android Companion — v0.7 pilot source

This Android Studio project contains three explicit, owner/volunteer-controlled modes:

1. **Make this phone findable (BLE beacon):** the phone broadcasts a rotating token while powered on, Bluetooth is enabled and the visible foreground service is running.
2. **Volunteer to find nearby beacons:** the volunteer phone detects opted-in FindSure BLE beacons, captures the volunteer phone's approximate location and uploads/queues a sighting.
3. **Vehicle GPS sharing (new):** reuse a spare Android phone you own as a low-cost GPS unit for your own car or bike. The user starts a visible location foreground service; it submits GPS points to `/api/vehicle-trackers/telemetry` with the vehicle tracker API key. If data is temporarily unavailable, up to 100 points are queued locally for later upload.

The Bluetooth LE feature is optional at install time so a phone without BLE can still use Vehicle GPS mode. This is source code, not a compiled APK. It is not certified by Google Find Hub, Apple Find My or Samsung Find.

## Build on Windows

1. Install Android Studio from https://developer.android.com/studio and let it install a current Android SDK.
2. Open this `android-companion` folder as a project. Allow Gradle sync to download the Android Gradle Plugin, Kotlin plugin and Google Play Services Location dependency.
3. Select the `app` run configuration and build a debug APK (`Build > Build Bundle(s) / APK(s) > Build APK(s)`).
4. Install that APK on your own test Android phones.

## Use a spare phone as a car/bike GPS device

1. First deploy FindSure to a **public HTTPS** address and configure the shared database. The companion rejects plain HTTP.
2. On the FindSure website, open **Cars & bikes** and register your own vehicle. Save the **private owner recovery code** and **tracker API key** separately. The owner code is entered on the website to view location; the API key is entered only in the companion app.
3. On the spare Android phone, install the companion APK. Open it, enter the public HTTPS FindSure base URL, paste the vehicle tracker API key, tick the vehicle ownership/permission checkbox, and tap **Start vehicle GPS sharing**.
4. Grant precise location and notification permission. Android starts the service from the visible app screen and shows an ongoing notification with a Stop action. Keep the phone powered, charged, cool and connected to mobile data.
5. On your main phone/laptop, open FindSure → Cars & bikes → enter the private vehicle owner code → Show vehicle location. Auto-refresh can check for new readings every minute.

### Limitations of the spare-phone route

- This is a cheaper alternative only if you already own a spare Android phone. A SIM/data package and safe charging are still needed.
- The spare phone must remain powered on, GPS/location enabled and the visible foreground service active. Some manufacturers' battery controls may stop background work; test on the specific phone.
- If mobile data is unavailable, readings can be queued on the spare phone and uploaded later. The website cannot show a new reading until it uploads.
- If the spare phone is switched off, removed, damaged, out of battery or force-stopped, new tracking stops. It cannot locate a car by number plate alone.
- Android location foreground services have system permission and start restrictions. The user must start this mode while the app is visible and grant the required permissions. See https://developer.android.com/develop/background-work/services/fgs/restrictions-bg-start and https://developer.android.com/about/versions/14/changes/fgs-types-required.
- This does not control ignition, engine, immobilizer or vehicle CAN/ECU. Do not connect phone chargers to vehicle wiring without a properly fused, automotive-rated supply. Do not track another person's vehicle without permission.

## Two-phone BLE test

- Register the target phone through FindSure and enter its private device code in the companion; press **Make THIS phone findable**.
- On a second phone, tick volunteer consent and press **Volunteer to find nearby beacons**.
- Bring the phones within BLE range. A sighting pin is the volunteer phone's location at detection time, not a direct GPS fix read from a powered-off target.

## Honest boundaries

- A normal Android app cannot keep an ordinary phone's Bluetooth/GPS radio operating after complete shutdown.
- A separately powered BLE tag can keep advertising while the host item is off, provided the tag battery lasts. Community coverage depends on nearby FindSure companion users.
- This pilot has not received Google/Apple/Samsung network approval and is not suitable for emergency response or a public guarantee until independently security-reviewed and tested on a broad range of devices.


## Security note

This is a development pilot. The owner code and tracker key are currently saved in app-private SharedPreferences for convenience; production release should move secrets into Android Keystore-backed encrypted storage, add device attestation where appropriate, and receive an independent security review. The ongoing notification and explicit consent must remain visible.
