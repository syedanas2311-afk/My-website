package com.findsure.companion

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.Location
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.Executors

/**
 * Owner-started, visible Android GPS sharing mode for a spare phone installed in
 * a vehicle the owner is authorised to track. The persistent notification makes
 * the active tracking session visible. This is not a stealth service.
 */
class VehicleGpsService : Service() {
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private lateinit var prefs: android.content.SharedPreferences
    private var baseUrl = ""
    private var trackerApiKey = ""
    private var callback: LocationCallback? = null
    private val fused by lazy { LocationServices.getFusedLocationProviderClient(this) }

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopTracking()
            return START_NOT_STICKY
        }
        baseUrl = (intent?.getStringExtra(EXTRA_URL)
            ?: prefs.getString(MainActivity.KEY_URL, "") ?: "").trim().trimEnd('/')
        trackerApiKey = (intent?.getStringExtra(EXTRA_API_KEY)
            ?: prefs.getString(MainActivity.KEY_VEHICLE_API_KEY, "") ?: "").trim()
        if (!baseUrl.startsWith("https://") || !trackerApiKey.matches(Regex("[a-fA-F0-9]{64}"))) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            stopSelf()
            return START_NOT_STICKY
        }
        prefs.edit().putString(MainActivity.KEY_URL, baseUrl)
            .putString(MainActivity.KEY_VEHICLE_API_KEY, trackerApiKey).apply()
        val notification = buildNotification("Starting GPS updates. Keep this phone charged and secured.")
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        startLocationUpdates()
        main.removeCallbacks(queueFlushTick)
        main.post(queueFlushTick)
        return START_STICKY
    }

    private fun startLocationUpdates() {
        callback?.let { try { fused.removeLocationUpdates(it) } catch (_: Exception) {} }
        callback = null
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            updateNotification("Location permission was removed. Open FindSure and start again.")
            stopSelf()
            return
        }
        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, UPDATE_INTERVAL_MS)
            .setMinUpdateIntervalMillis(MIN_INTERVAL_MS)
            .setMinUpdateDistanceMeters(20f)
            .build()
        val locationCallback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                val location = result.lastLocation ?: return
                val payload = makePayload(location)
                io.execute {
                    try {
                        flushQueueOnWorker()
                        NetworkApi.submitVehicleTelemetry(baseUrl, trackerApiKey, payload)
                        updateNotification("Vehicle GPS active. Latest point uploaded at ${timeLabel(location.time)}.")
                    } catch (e: NetworkApi.HttpStatusException) {
                        if (e.code in 400..499) {
                            Log.w(TAG, "Telemetry rejected with HTTP ${e.code}", e)
                            updateNotification("Server rejected the tracker key or GPS point (HTTP ${e.code}). Check credentials.")
                        } else {
                            enqueue(payload)
                            updateNotification("No usable data connection. GPS readings are saved on this phone until sync is possible.")
                        }
                    } catch (e: Exception) {
                        enqueue(payload)
                        updateNotification("Waiting for data connection. Recent GPS readings are queued on this phone.")
                        Log.w(TAG, "Vehicle telemetry queued", e)
                    }
                }
            }
        }
        callback = locationCallback
        try {
            fused.requestLocationUpdates(request, locationCallback, Looper.getMainLooper())
                .addOnSuccessListener { updateNotification("Vehicle GPS sharing is active. Location is sent about once a minute.") }
                .addOnFailureListener { error ->
                    updateNotification("Could not start GPS updates: ${error.localizedMessage ?: "location error"}")
                    Log.e(TAG, "requestLocationUpdates failed", error)
                    stopSelf()
                }
        } catch (e: SecurityException) {
            updateNotification("Location permission is missing. Open FindSure and grant it.")
            stopSelf()
        }
    }

    private fun makePayload(location: Location): JSONObject {
        val formatter = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
        return JSONObject()
            .put("lat", location.latitude)
            .put("lon", location.longitude)
            .put("accuracy", location.accuracy.toDouble())
            .put("speedKph", if (location.hasSpeed()) (location.speed * 3.6).coerceIn(0.0, 400.0) else JSONObject.NULL)
            .put("heading", if (location.hasBearing()) location.bearing.toDouble().coerceIn(0.0, 359.9) else JSONObject.NULL)
            .put("capturedAt", formatter.format(Date(location.time)))
            .put("timeZone", TimeZone.getDefault().id)
            .put("source", "findsure-android-spare-phone")
    }

    private fun enqueue(payload: JSONObject) {
        val current = try { JSONArray(prefs.getString(KEY_PENDING, "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        val next = JSONArray()
        // Keep the most recent 100 snapshots. Oldest entries are discarded if storage is full.
        val start = (current.length() - MAX_PENDING + 1).coerceAtLeast(0)
        for (i in start until current.length()) next.put(current.getJSONObject(i))
        next.put(payload)
        prefs.edit().putString(KEY_PENDING, next.toString()).apply()
    }

    private fun flushQueueOnWorker() {
        val current = try { JSONArray(prefs.getString(KEY_PENDING, "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        if (current.length() == 0) return
        val remaining = JSONArray()
        var failed = false
        for (i in 0 until current.length()) {
            val item = current.optJSONObject(i) ?: continue
            if (!failed) {
                try {
                    NetworkApi.submitVehicleTelemetry(baseUrl, trackerApiKey, item)
                    continue
                } catch (e: NetworkApi.HttpStatusException) {
                    if (e.code == 400 || e.code == 422) {
                        // Malformed or out-of-range points cannot become valid by retrying.
                        Log.w(TAG, "Dropping invalid queued point (HTTP ${e.code})")
                        continue
                    }
                    // Keep the queue for authentication errors; the owner may need to restore a valid key.
                    failed = true
                } catch (_: Exception) {
                    failed = true
                }
            }
            remaining.put(item)
        }
        prefs.edit().putString(KEY_PENDING, remaining.toString()).apply()
        if (remaining.length() == 0) updateNotification("All saved GPS points have synced.")
    }

    private val queueFlushTick = object : Runnable {
        override fun run() {
            io.execute { try { flushQueueOnWorker() } catch (e: Exception) { Log.w(TAG, "Queue sync failed", e) } }
            main.postDelayed(this, QUEUE_FLUSH_MS)
        }
    }

    private fun stopTracking() {
        main.removeCallbacks(queueFlushTick)
        callback?.let { try { fused.removeLocationUpdates(it) } catch (_: Exception) {} }
        callback = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        main.removeCallbacks(queueFlushTick)
        callback?.let { try { fused.removeLocationUpdates(it) } catch (_: Exception) {} }
        callback = null
        io.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "FindSure vehicle GPS", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun buildNotification(message: String): Notification {
        val openApp = PendingIntent.getActivity(this, 101, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stopIntent = PendingIntent.getService(this, 102,
            Intent(this, VehicleGpsService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("FindSure vehicle sharing is on")
            .setContentText(message)
            .setContentIntent(openApp)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
        builder.addAction(Notification.Action.Builder(android.R.drawable.ic_media_pause, "Stop", stopIntent).build())
        return builder.build()
    }

    private fun updateNotification(message: String) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, buildNotification(message))
    }

    private fun timeLabel(time: Long): String = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(time))

    companion object {
        const val ACTION_STOP = "com.findsure.companion.VEHICLE_GPS_STOP"
        const val EXTRA_URL = "vehicle_url"
        const val EXTRA_API_KEY = "vehicle_api_key"
        private const val TAG = "FindSureVehicleGPS"
        private const val CHANNEL_ID = "findsure_vehicle_gps"
        private const val NOTIFICATION_ID = 7208
        private const val UPDATE_INTERVAL_MS = 60_000L
        private const val MIN_INTERVAL_MS = 30_000L
        private const val QUEUE_FLUSH_MS = 30_000L
        private const val MAX_PENDING = 100
        private const val KEY_PENDING = "vehicle_gps_pending_points"
    }
}
