package com.findsure.companion

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var apiField: EditText
    private lateinit var codeField: EditText
    private lateinit var consentBox: CheckBox
    private lateinit var vehicleApiKeyField: EditText
    private lateinit var vehicleConsentBox: CheckBox
    private lateinit var vehicleStatusText: TextView
    private lateinit var statusText: TextView
    private var requestedMode: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(26))
            setBackgroundColor(0xFFF5F7FB.toInt())
        }
        val scroll = ScrollView(this).apply { addView(outer) }
        val title = TextView(this).apply {
            text = "FindSure Companion"
            textSize = 25f; setTextColor(0xFF17233C.toInt()); setTypeface(null, 1)
        }
        outer.addView(title, matchWrap())
        outer.addView(note("Choose a mode: make your own phone findable, help the community detect nearby beacons, or reuse a spare Android phone as a GPS unit for your own car or bike. This app is a pilot, not a replacement for official platform finders."))

        outer.addView(label("FindSure server URL"))
        apiField = EditText(this).apply {
            hint = "https://your-public-findsure-host.example"
            setSingleLine(true); textSize = 14f
            setText(prefs.getString(KEY_URL, "") ?: "")
        }
        outer.addView(apiField, matchWrap())
        outer.addView(note("Use the public HTTPS URL after deployment. For a local test, use your laptop's LAN IP (not localhost) and only on a trusted Wi-Fi network."))

        outer.addView(label("Private device code (beacon mode only)"))
        codeField = EditText(this).apply {
            hint = "Paste the code created on FindSure website"
            setSingleLine(true); textSize = 14f
            setText(prefs.getString(KEY_CODE, "") ?: "")
        }
        outer.addView(codeField, matchWrap())

        outer.addView(label("Vehicle tracker API key (spare-phone GPS mode)"))
        vehicleApiKeyField = EditText(this).apply {
            hint = "Paste the vehicle API key created on FindSure"
            setSingleLine(true); textSize = 14f
            setText(prefs.getString(KEY_VEHICLE_API_KEY, "") ?: "")
        }
        outer.addView(vehicleApiKeyField, matchWrap())
        outer.addView(note("Low-cost alternative: reuse an old Android phone you own as the GPS unit in your own car or bike. Register the vehicle on FindSure first, then paste the one-time tracker API key here. A SIM/data plan and safe charging are still needed."))
        vehicleConsentBox = CheckBox(this).apply {
            text = "I own or am authorised to manage this vehicle. I understand this phone will share its location while the visible GPS service is running."
            textSize = 13f; setTextColor(0xFF384863.toInt())
        }
        outer.addView(vehicleConsentBox, matchWrap())
        outer.addView(button("3. Start vehicle GPS sharing") { prepareStart("vehicle") }, matchWrap())
        vehicleStatusText = TextView(this).apply {
            text = "Vehicle GPS mode is off."; textSize = 12f; setTextColor(0xFF285B48.toInt())
            setPadding(0, dp(4), 0, dp(8))
        }
        outer.addView(vehicleStatusText, matchWrap())

        consentBox = CheckBox(this).apply {
            text = "I agree to volunteer this phone's Bluetooth scanning and share its location only when it detects an opted-in FindSure beacon."
            textSize = 13f; setTextColor(0xFF384863.toInt())
        }
        outer.addView(consentBox, matchWrap())

        val beacon = button("1. Make THIS phone findable") { prepareStart("beacon") }
        outer.addView(beacon, matchWrap())
        val finder = button("2. Volunteer to find nearby beacons") { prepareStart("scanner") }
        outer.addView(finder, matchWrap())
        val stop = button("Stop all FindSure services", neutral = true) {
            stopService(Intent(this, BeaconNetworkService::class.java))
            stopService(Intent(this, VehicleGpsService::class.java))
            statusText.text = "All FindSure services stopped."
            vehicleStatusText.text = "Vehicle GPS mode is off."
        }
        outer.addView(stop, matchWrap())
        outer.addView(note("Beacon mode: the phone broadcasts a rotating token and preloads up to seven days of tokens while online. It must remain powered on with Bluetooth and the foreground service working.\n\nVolunteer mode: this phone scans for opted-in FindSure beacons, obtains its own location, then uploads a sighting. If this phone has no internet, sightings are queued locally for later upload."))
        outer.addView(note("Privacy: an ongoing Android notification is shown while active. Use only on devices you own or are authorised to manage. Stop the service any time. Do not use this pilot for covert tracking."))
        outer.addView(note("Important limit: normal apps cannot keep a typical phone's Bluetooth radio transmitting after full shutdown. This pilot can help when the lost phone has no internet but is still on; it does not promise universal power-off location."))
        statusText = TextView(this).apply {
            text = "Service not running. Choose one of the modes above."
            textSize = 13f; setTextColor(0xFF285B48.toInt()); setPadding(0, dp(12), 0, dp(12))
        }
        outer.addView(statusText, matchWrap())
        val guide = button("Open FindSure website") {
            val url = apiField.text.toString().trim().trimEnd('/')
            if (url.startsWith("http://") || url.startsWith("https://")) startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            else Toast.makeText(this, "Enter the server URL first.", Toast.LENGTH_LONG).show()
        }
        outer.addView(guide, matchWrap())
        setContentView(scroll)
    }

    private fun prepareStart(mode: String) {
        val base = apiField.text.toString().trim().trimEnd('/')
        val code = codeField.text.toString().trim().uppercase()
        if (!base.startsWith("https://")) {
            Toast.makeText(this, "For security, use FindSure's deployed HTTPS URL. Local HTTP is disabled in this build.", Toast.LENGTH_LONG).show(); return
        }
        if (mode == "beacon" && code.isBlank()) {
            Toast.makeText(this, "Register this device on the website and enter its private code.", Toast.LENGTH_LONG).show(); return
        }
        if (mode == "scanner" && !consentBox.isChecked) {
            Toast.makeText(this, "Please tick the volunteer consent box before scanning.", Toast.LENGTH_LONG).show(); return
        }
        val vehicleKey = vehicleApiKeyField.text.toString().trim()
        if (mode == "vehicle" && !vehicleKey.matches(Regex("[a-fA-F0-9]{64}"))) {
            Toast.makeText(this, "Register your vehicle on the FindSure website and paste its 64-character tracker API key.", Toast.LENGTH_LONG).show(); return
        }
        if (mode == "vehicle" && !vehicleConsentBox.isChecked) {
            Toast.makeText(this, "Please confirm that this is your vehicle or one you are authorised to manage.", Toast.LENGTH_LONG).show(); return
        }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_URL, base).putString(KEY_CODE, code).putString(KEY_VEHICLE_API_KEY, vehicleKey).apply()
        requestedMode = mode
        val missing = requiredPermissions(mode).filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }.toTypedArray()
        if (missing.isNotEmpty()) requestPermissions(missing, PERMISSION_REQUEST) else startRequestedMode()
    }

    private fun requiredPermissions(mode: String): Array<String> {
        val permissions = mutableListOf<String>()
        when (mode) {
            "scanner" -> {
                // Approximate location is sufficient for a community BLE sighting.
                permissions += Manifest.permission.ACCESS_COARSE_LOCATION
                if (Build.VERSION.SDK_INT >= 31) permissions += Manifest.permission.BLUETOOTH_SCAN
            }
            "beacon" -> {
                if (Build.VERSION.SDK_INT >= 31) permissions += Manifest.permission.BLUETOOTH_ADVERTISE
            }
            "vehicle" -> {
                // Ask while the activity is visible, then run a user-started location foreground service.
                permissions += Manifest.permission.ACCESS_COARSE_LOCATION
                permissions += Manifest.permission.ACCESS_FINE_LOCATION
            }
        }
        if (Build.VERSION.SDK_INT >= 31 && mode in listOf("scanner", "beacon")) permissions += Manifest.permission.BLUETOOTH_CONNECT
        else if (Build.VERSION.SDK_INT < 31 && mode in listOf("scanner", "beacon")) permissions += Manifest.permission.ACCESS_COARSE_LOCATION
        if (Build.VERSION.SDK_INT >= 33) permissions += Manifest.permission.POST_NOTIFICATIONS
        return permissions.distinct().toTypedArray()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != PERMISSION_REQUEST) return
        if (grantResults.any { it != PackageManager.PERMISSION_GRANTED }) {
            requestedMode = null
            AlertDialog.Builder(this).setTitle("Permission needed")
                .setMessage("FindSure needs the requested Bluetooth or location permissions for the mode you selected. Vehicle GPS mode requires location permission and a visible ongoing notification. You can review permissions in Settings.")
                .setPositiveButton("Open settings") { _, _ -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }
                .setNegativeButton("Cancel", null).show()
            return
        }
        startRequestedMode()
    }

    private fun startRequestedMode() {
        val mode = requestedMode ?: return
        try {
            if (mode == "vehicle") {
                val vehicleIntent = Intent(this, VehicleGpsService::class.java).apply {
                    putExtra(VehicleGpsService.EXTRA_URL, apiField.text.toString().trim().trimEnd('/'))
                    putExtra(VehicleGpsService.EXTRA_API_KEY, vehicleApiKeyField.text.toString().trim())
                }
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(vehicleIntent) else startService(vehicleIntent)
                vehicleStatusText.text = "Starting vehicle GPS sharing. Check the persistent notification."
            } else {
                val intent = Intent(this, BeaconNetworkService::class.java).apply {
                    action = BeaconNetworkService.ACTION_START
                    putExtra(BeaconNetworkService.EXTRA_MODE, mode)
                    putExtra(BeaconNetworkService.EXTRA_URL, apiField.text.toString().trim().trimEnd('/'))
                    putExtra(BeaconNetworkService.EXTRA_CODE, codeField.text.toString().trim().uppercase())
                }
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
                statusText.text = if (mode == "beacon") "Starting this phone's rotating BLE beacon…" else "Starting community scan. This phone's location may be uploaded when a beacon is detected."
            }
            Toast.makeText(this, "FindSure service started. Check the ongoing notification.", Toast.LENGTH_LONG).show()
        } catch (error: Exception) {
            Toast.makeText(this, "Could not start service: ${error.message}", Toast.LENGTH_LONG).show()
        } finally { requestedMode = null }
    }

    private fun label(value: String) = TextView(this).apply {
        text = value; textSize = 12f; setTypeface(null, 1); setTextColor(0xFF34445F.toInt())
        setPadding(0, dp(14), 0, dp(3))
    }
    private fun note(value: String) = TextView(this).apply {
        text = value; textSize = 12f; setTextColor(0xFF66748C.toInt()); setPadding(0, dp(10), 0, dp(12))
    }
    private fun button(value: String, neutral: Boolean = false, action: () -> Unit) = Button(this).apply {
        text = value; isAllCaps = false; gravity = Gravity.CENTER; setOnClickListener { action() }
        if (neutral) setTextColor(0xFF293955.toInt())
    }
    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        const val PREFS = "findsure_beacon_prefs"
        const val KEY_URL = "api_url"
        const val KEY_CODE = "device_code"
        const val KEY_VEHICLE_API_KEY = "vehicle_api_key"
        const val KEY_TOKENS = "token_cache"
        const val KEY_QUEUE = "pending_sightings"
        const val PERMISSION_REQUEST = 4107
    }
}
