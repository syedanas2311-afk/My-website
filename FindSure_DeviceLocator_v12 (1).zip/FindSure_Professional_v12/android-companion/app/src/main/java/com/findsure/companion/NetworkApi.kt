package com.findsure.companion

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

object NetworkApi {
    data class TokenItem(val slot: Long, val token: String)
    data class GpsPoint(val latitude: Double, val longitude: Double, val accuracy: Float, val capturedAt: String, val gpsCapturedAt: String)

    @Throws(Exception::class)
    fun fetchTokens(baseUrl: String, deviceCode: String): List<TokenItem> {
        val response = post(baseUrl, "/api/beacon/tokens", JSONObject().put("code", deviceCode))
        val array = response.getJSONArray("tokens")
        val out = mutableListOf<TokenItem>()
        for (i in 0 until array.length()) {
            val row = array.getJSONObject(i)
            out += TokenItem(row.getLong("slot"), row.getString("token"))
        }
        return out
    }

    @Throws(Exception::class)
    fun submitVehicleTelemetry(baseUrl: String, trackerApiKey: String, payload: JSONObject) {
        val url = URL(baseUrl.trimEnd('/') + "/api/vehicle-trackers/telemetry")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 8000
            readTimeout = 10000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Authorization", "Bearer $trackerApiKey")
        }
        try {
            OutputStreamWriter(connection.outputStream, Charsets.UTF_8).use { it.write(payload.toString()) }
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.use { input -> BufferedReader(InputStreamReader(input, Charsets.UTF_8)).readText() } ?: "{}"
            if (status !in 200..299) throw HttpStatusException(status, text.take(300))
        } finally { connection.disconnect() }
    }

    @Throws(Exception::class)
    fun submitSighting(baseUrl: String, token: String, point: GpsPoint): Boolean {
        val body = JSONObject()
            .put("token", token)
            .put("lat", point.latitude)
            .put("lon", point.longitude)
            .put("accuracy", point.accuracy.toDouble())
            .put("capturedAt", point.capturedAt)
            .put("gpsCapturedAt", point.gpsCapturedAt)
            .put("timeZone", java.util.TimeZone.getDefault().id)
            .put("finderPlatform", "android")
        return try {
            post(baseUrl, "/api/beacon/sightings", body)
            true
        } catch (e: HttpStatusException) {
            // Network/server failures may be retried; bad or expired tokens (4xx) should be dropped.
            if (e.code >= 500) throw e
            false
        }
    }

    private fun post(baseUrl: String, path: String, json: JSONObject): JSONObject {
        val url = URL(baseUrl.trimEnd('/') + path)
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 8000
            readTimeout = 10000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json")
        }
        try {
            OutputStreamWriter(connection.outputStream, Charsets.UTF_8).use { it.write(json.toString()) }
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.use { input -> BufferedReader(InputStreamReader(input, Charsets.UTF_8)).readText() } ?: "{}"
            if (status !in 200..299) throw HttpStatusException(status, text.take(300))
            return JSONObject(text)
        } finally { connection.disconnect() }
    }

    class HttpStatusException(val code: Int, message: String) : Exception("FindSure API returned HTTP $code: $message")
}
