package com.findsure.companion

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.le.AdvertiseCallback
import android.bluetooth.le.AdvertiseData
import android.bluetooth.le.AdvertiseSettings
import android.bluetooth.le.BluetoothLeAdvertiser
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.Location
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelUuid
import android.util.Log
import com.google.android.gms.location.CancellationTokenSource
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import java.util.concurrent.Executors

class BeaconNetworkService : Service() {
    private val mainHandler = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private lateinit var prefs: android.content.SharedPreferences
    private var baseUrl = ""
    private var deviceCode = ""
    private var mode = ""
    private var advertiser: BluetoothLeAdvertiser? = null
    private var scanner: BluetoothLeScanner? = null
    private var advertisingCallback: AdvertiseCallback? = null
    private var scanningCallback: ScanCallback? = null
    private var activeToken: String? = null
    private val seenTokens = LinkedHashSet<String>()
    private val fused by lazy { LocationServices.getFusedLocationProviderClient(this) }

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        mode = intent?.getStringExtra(EXTRA_MODE) ?: prefs.getString("active_mode", "") ?: ""
        baseUrl = intent?.getStringExtra(EXTRA_URL) ?: prefs.getString(MainActivity.KEY_URL, "") ?: ""
        deviceCode = intent?.getStringExtra(EXTRA_CODE) ?: prefs.getString(MainActivity.KEY_CODE, "") ?: ""
        prefs.edit().putString(MainActivity.KEY_URL, baseUrl).putString(MainActivity.KEY_CODE, deviceCode).putString("active_mode", mode).apply()
        if (mode !in listOf("beacon", "scanner") || baseUrl.isBlank()) { stopSelf(); return START_NOT_STICKY }
        if (Build.VERSION.SDK_INT >= 29) {
            val serviceTypes = if (mode == "beacon") ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
                else ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE or ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
            startForeground(NOTIFICATION_ID, buildNotification(), serviceTypes)
        } else {
            startForeground(NOTIFICATION_ID, buildNotification())
        }
        val adapter = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if (adapter == null || !adapter.isEnabled) {
            updateNotification("Bluetooth is unavailable or turned off. Enable Bluetooth to continue.")
            return START_STICKY
        }
        advertiser = adapter.bluetoothLeAdvertiser
        scanner = adapter.bluetoothLeScanner
        if (mode == "beacon") startBeaconMode() else startScannerMode()
        mainHandler.removeCallbacks(tick)
        mainHandler.post(tick)
        return START_STICKY
    }

    private val tick = object : Runnable {
        override fun run() {
            if (mode == "beacon") {
                ensureCurrentAdvertisement()
                refreshTokensIfNeeded()
            } else if (mode == "scanner") {
                io.execute { flushQueue() }
            }
            mainHandler.postDelayed(this, if (mode == "beacon") 30_000L else 60_000L)
        }
    }

    private fun startBeaconMode() {
        if (deviceCode.isBlank()) { updateNotification("Beacon stopped: register this device and enter its private code."); stopSelf(); return }
        updateNotification("Beacon mode active: rotating Bluetooth token; phone must stay powered on.")
        refreshTokensIfNeeded(force = true)
    }

    private var lastTokenRefreshAt = 0L
    private var tokenRetryDelayMs = 60_000L
    private fun refreshTokensIfNeeded(force: Boolean = false) {
        if (mode != "beacon" || deviceCode.isBlank()) return
        if (!force && System.currentTimeMillis() - lastTokenRefreshAt < 6 * 60 * 60 * 1000L) return
        lastTokenRefreshAt = System.currentTimeMillis()
        io.execute {
            try {
                val tokens = NetworkApi.fetchTokens(baseUrl, deviceCode)
                val arr = JSONArray()
                tokens.forEach { arr.put(JSONObject().put("slot", it.slot).put("token", it.token)) }
                prefs.edit().putString(MainActivity.KEY_TOKENS, arr.toString()).apply()
                tokenRetryDelayMs = 60_000L
                mainHandler.post { ensureCurrentAdvertisement() }
                updateNotification("Beacon ready. Rotating token cached for up to seven future days.")
            } catch (e: Exception) {
                Log.w(TAG, "Could not refresh rotating tokens", e)
                lastTokenRefreshAt = System.currentTimeMillis() - 6 * 60 * 60 * 1000L + tokenRetryDelayMs
                tokenRetryDelayMs = (tokenRetryDelayMs * 2).coerceAtMost(30 * 60 * 1000L)
                updateNotification("Using cached tokens if available. Will retry token refresh with backoff.")
                mainHandler.post { ensureCurrentAdvertisement() }
            }
        }
    }

    private fun ensureCurrentAdvertisement() {
        if (mode != "beacon") return
        if (checkSelfPermission(Manifest.permission.BLUETOOTH_ADVERTISE) != PackageManager.PERMISSION_GRANTED && Build.VERSION.SDK_INT >= 31) return
        if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED && Build.VERSION.SDK_INT >= 31) return
        val slot = System.currentTimeMillis() / SLOT_MS
        val arr = try { JSONArray(prefs.getString(MainActivity.KEY_TOKENS, "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        var token: String? = null
        for (i in 0 until arr.length()) {
            val row = arr.optJSONObject(i) ?: continue
            if (row.optLong("slot", -1) == slot) { token = row.optString("token").takeIf { it.matches(Regex("[A-Fa-f0-9]{16}")) }; break }
        }
        val tokenValue = token
        if (tokenValue == null) {
            updateNotification("No cached beacon token for the current time window. Reconnect this phone to refresh tokens.")
            stopAdvertising(); return
        }
        if (tokenValue == activeToken) return
        stopAdvertising()
        val currentAdvertiser = advertiser ?: run { updateNotification("This phone does not support BLE advertising."); return }
        val data = AdvertiseData.Builder().addServiceData(SERVICE_PARCEL_UUID, hexToBytes(tokenValue)).setIncludeDeviceName(false).build()
        val settings = AdvertiseSettings.Builder().setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_POWER)
            .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_LOW).setConnectable(false).setTimeout(0).build()
        val callback = object : AdvertiseCallback() {
            override fun onStartSuccess(settingsInEffect: AdvertiseSettings?) {
                activeToken = tokenValue
                updateNotification("Rotating BLE beacon is advertising. This is not available after a normal full shutdown.")
            }
            override fun onStartFailure(errorCode: Int) {
                activeToken = null
                updateNotification("BLE advertising failed (code $errorCode). Check device Bluetooth support and permissions.")
                Log.w(TAG, "BLE advertising failed: $errorCode")
            }
        }
        advertisingCallback = callback
        try { currentAdvertiser.startAdvertising(settings, data, callback) }
        catch (e: SecurityException) { updateNotification("Bluetooth permission is missing. Open FindSure and grant it."); Log.w(TAG, "Missing advertise permission", e) }
        catch (e: Exception) { updateNotification("Could not start Bluetooth beacon: ${e.message}") }
    }

    private fun stopAdvertising() {
        val callback = advertisingCallback
        if (callback != null) try { advertiser?.stopAdvertising(callback) } catch (_: Exception) {}
        advertisingCallback = null; activeToken = null
    }

    private fun startScannerMode() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            updateNotification("Location permission is needed to send a beacon sighting."); return
        }
        val currentScanner = scanner ?: run { updateNotification("This phone does not support BLE scanning."); return }
        val filter = ScanFilter.Builder().setServiceUuid(SERVICE_PARCEL_UUID).build()
        val settings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_POWER).setReportDelay(0).build()
        val callback = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val bytes = result.scanRecord?.getServiceData(SERVICE_PARCEL_UUID) ?: return
                if (bytes.size != 8) return
                val token = bytesToHex(bytes)
                synchronized(seenTokens) {
                    if (token in seenTokens) return
                    seenTokens.add(token)
                    while (seenTokens.size > 250) seenTokens.remove(seenTokens.first())
                }
                obtainLocationAndUpload(token, System.currentTimeMillis())
            }
            override fun onScanFailed(errorCode: Int) {
                updateNotification("Bluetooth scan failed (code $errorCode). Check Bluetooth and permissions.")
                Log.w(TAG, "BLE scanning failed: $errorCode")
            }
        }
        scanningCallback = callback
        try {
            currentScanner.startScan(listOf(filter), settings, callback)
            updateNotification("Volunteer finder active. When an opted-in beacon is detected, this phone may upload its location.")
        } catch (e: SecurityException) { updateNotification("Bluetooth scan permission is missing. Open FindSure and grant it."); Log.w(TAG, "Missing scan permission", e) }
        catch (e: Exception) { updateNotification("Could not start Bluetooth scan: ${e.message}") }
    }

    private fun obtainLocationAndUpload(token: String, detectedAtMs: Long) {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return
        val cancellation = CancellationTokenSource()
        try {
            fused.getCurrentLocation(Priority.PRIORITY_BALANCED_POWER_ACCURACY, cancellation.token)
                .addOnSuccessListener { location ->
                    val chosen = location ?: return@addOnSuccessListener
                    if (System.currentTimeMillis() - chosen.time > 3 * 60 * 1000L) return@addOnSuccessListener
                    val payload = JSONObject()
                        .put("token", token)
                        .put("lat", chosen.latitude)
                        .put("lon", chosen.longitude)
                        .put("accuracy", chosen.accuracy.toDouble())
                        // Separate radio detection time (validates the rotating token slot) from
                        // the timestamp of the finder's GPS fix, which may be slightly cached.
                        .put("capturedAt", iso(detectedAtMs))
                        .put("gpsCapturedAt", iso(chosen.time))
                        .put("timeZone", TimeZone.getDefault().id)
                        .put("finderPlatform", "android")
                    io.execute { tryUploadOrQueue(payload) }
                }
                .addOnFailureListener { Log.w(TAG, "Could not get finder location", it) }
        } catch (e: SecurityException) { Log.w(TAG, "Location permission is missing", e) }
    }

    private fun tryUploadOrQueue(payload: JSONObject) {
        try {
            val ok = NetworkApi.submitSighting(baseUrl, payload.getString("token"), NetworkApi.GpsPoint(
                payload.getDouble("lat"), payload.getDouble("lon"), payload.optDouble("accuracy", -1.0).toFloat(),
                payload.getString("capturedAt"), payload.optString("gpsCapturedAt", payload.getString("capturedAt"))
            ))
            if (ok) updateNotification("A community BLE sighting was uploaded. Nearby location is not a direct GPS fix from the lost phone.")
            else Log.w(TAG, "Sighting rejected by the FindSure API; it will not be queued")
        } catch (e: Exception) {
            Log.w(TAG, "Sighting upload failed; queueing it for later", e)
            addToQueue(payload)
        }
    }

    private fun addToQueue(item: JSONObject) {
        synchronized(prefs) {
            val old = try { JSONArray(prefs.getString(MainActivity.KEY_QUEUE, "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
            val now = System.currentTimeMillis()
            val kept = JSONArray()
            for (i in 0 until old.length()) {
                val row = old.optJSONObject(i) ?: continue
                val at = try { java.time.Instant.parse(row.optString("capturedAt")).toEpochMilli() } catch (_: Exception) { 0L }
                if (now - at <= 8 * 24 * 60 * 60 * 1000L) kept.put(row)
            }
            kept.put(item)
            val trimmed = JSONArray()
            val start = maxOf(0, kept.length() - 100)
            for (i in start until kept.length()) trimmed.put(kept.getJSONObject(i))
            prefs.edit().putString(MainActivity.KEY_QUEUE, trimmed.toString()).apply()
        }
        updateNotification("A sighting is queued on this finder phone and will retry when network returns.")
    }

    private fun flushQueue() {
        val old = try { JSONArray(prefs.getString(MainActivity.KEY_QUEUE, "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        if (old.length() == 0) return
        val kept = JSONArray()
        var sent = 0
        for (i in 0 until old.length()) {
            val item = old.optJSONObject(i) ?: continue
            try {
                val ok = NetworkApi.submitSighting(baseUrl, item.getString("token"), NetworkApi.GpsPoint(
                    item.getDouble("lat"), item.getDouble("lon"), item.optDouble("accuracy", -1.0).toFloat(),
                    item.getString("capturedAt"), item.optString("gpsCapturedAt", item.getString("capturedAt"))
                ))
                if (ok) sent++ else Log.w(TAG, "Queued token was rejected; dropping it")
            } catch (_: Exception) { kept.put(item) }
        }
        prefs.edit().putString(MainActivity.KEY_QUEUE, kept.toString()).apply()
        if (sent > 0) updateNotification("Uploaded $sent queued community sighting(s).")
    }

    private fun stopScanner() {
        val callback = scanningCallback
        if (callback != null) try { scanner?.stopScan(callback) } catch (_: Exception) {}
        scanningCallback = null
    }

    private fun buildNotification(): Notification {
        val text = if (mode == "beacon") "Rotating beacon active" else "Community finder active"
        return makeNotification(text)
    }

    private fun updateNotification(text: String) {
        val notification = makeNotification(text)
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIFICATION_ID, notification)
    }

    @Suppress("DEPRECATION")
    private fun makeNotification(text: String): Notification {
        val intent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return builder.setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("FindSure Beacon Pilot")
            .setContentText(text)
            .setContentIntent(intent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "FindSure device finding", NotificationManager.IMPORTANCE_LOW)
            channel.description = "Visible status for opted-in Bluetooth beacon and finder mode"
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        mainHandler.removeCallbacks(tick)
        stopAdvertising(); stopScanner()
        io.shutdownNow()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null

    private fun hexToBytes(value: String): ByteArray = value.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
    private fun bytesToHex(value: ByteArray): String = value.joinToString("") { "%02X".format(it) }
    private fun iso(ms: Long): String = java.time.Instant.ofEpochMilli(ms).toString()

    companion object {
        const val ACTION_START = "com.findsure.companion.START"
        const val ACTION_STOP = "com.findsure.companion.STOP"
        const val EXTRA_MODE = "mode"
        const val EXTRA_URL = "base_url"
        const val EXTRA_CODE = "device_code"
        const val NOTIFICATION_ID = 4110
        const val CHANNEL_ID = "findsure_beacon_status"
        const val SLOT_MS = 15 * 60 * 1000L
        // A FindSure-only BLE service identifier. This pilot is not certified for Find Hub or Apple's network.
        val SERVICE_UUID: UUID = UUID.fromString("4d1b3b6a-4e2b-4d59-a8fa-4f5a1b2c3d4e")
        val SERVICE_PARCEL_UUID = ParcelUuid(SERVICE_UUID)
        const val TAG = "FindSureBeacon"
    }
}
