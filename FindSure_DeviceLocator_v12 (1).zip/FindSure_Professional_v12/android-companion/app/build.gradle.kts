plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.findsure.companion"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.findsure.companion"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "0.7.0-pilot"
    }
}

dependencies {
    implementation("com.google.android.gms:play-services-location:21.3.0")
}
