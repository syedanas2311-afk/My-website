# FindSure — Bluetooth Pilot Security and Limits

# FindSure BLE Network Pilot — Security & Rollout Gates

## Intended flow

1. Device owner registers a device on FindSure and keeps its private recovery code.
2. The native Android companion asks for Bluetooth permission and, in beacon mode, receives a cache of random rotating 64-bit tokens with 15-minute slots. The tokens are not a permanent device identifier and rotate every slot.
3. When in range, an opted-in volunteer companion can scan the FindSure service UUID. If location permission is granted, the relay app requests its own approximate location and sends a sighting.
4. The backend maps the token to a registered device, checks its time slot, saves the relay's location and timestamp, and returns the latest sighting only through the device's private recovery-code lookup.
5. If the volunteer phone has no internet, its app queues the sighting locally and attempts to upload later. The target may have no internet at detection time; the relay needs a path to upload eventually.

## What a BLE sighting means

The stored coordinates are from the volunteer/finder phone at the time it detected a beacon. They are **not coordinates obtained from the lost phone's GPS**. BLE range is variable, usually local, and walls/metal/buildings can reduce range. The pin should be read as “a participating phone was near this beacon at this time.”

## Hard limitations

- This is an Android-only pilot. A PWA in Chrome cannot replace a native always-available BLE scanner/broadcaster.
- The target has to be powered on, have working Bluetooth, have the app service running, and have previously cached tokens. The seven-day forward token cache is finite; an extended offline period may exhaust it.
- Most phones stop ordinary app-controlled Bluetooth broadcasting when fully shut down. Power-off finding needs manufacturer-reserved power/hardware/firmware or an official network; there is no public universal IMEI-to-GPS API.
- Finder phones must participate. Coverage depends on installed apps, permission choices, battery restrictions and nearby volunteer density. There is no guarantee of a sighting.
- Google Find Hub and Samsung Find run their own device/crowd networks and Apple Find My accessory integration is governed by Apple's MFi program. The FindSure app does not query or decrypt these vendor networks.
- This pilot is not yet iOS-compatible and is not a general-purpose Windows/macOS finder.

## Security and privacy risks in this pilot

- BLE tokens are short-lived and only 64-bit in the current POC. Server storage maps these rotating tokens to device IDs. Before a large public launch, commission a cryptographic/security review, consider a longer token with BLE extended advertising or a hardware design, end-to-end encrypted reports, authenticated relay identities, replay-resistant signed sightings and stronger anti-abuse controls.
- Beacon tokens are broadcast over BLE by design. A nearby radio can observe a token during its 15-minute slot; do not treat a token as a password.
- The backend currently accepts a token plus a reported location and validates token/slot/time, but does not cryptographically prove that the reporter was physically close or that the reported GPS is honest. A malicious client could fabricate a sighting. Use pilot devices and do not rely on these coordinates for emergency response or theft confrontation.
- The private device code grants location access. Keep it secret; revoke/re-register devices if a code is exposed.
- Relay mode sends the relay phone's approximate GPS only after an explicit consent checkbox, OS permissions and an ongoing notification. It should be stopped any time the user wants.
- Tokens and location data must be governed by a published privacy policy, retention/delete rules, documented abuse response, user consent, account recovery and security monitoring before wide release.
- A stable hidden identifier, secret continuous scanning, or covert location collection must not be added.

## Production gates before marketing “offline finding”

1. Build the Android project with a current stable Android Studio / SDK; complete static analysis and dependency checks.
2. Test on at least 2 Android brands and API levels for BLE advertisement/scanning in foreground, screen-off behavior, battery saver, reboot, app process kill, permissions revoked, GPS disabled, network loss, queue retry, wrong time and expired tokens.
3. Implement robust user accounts and device ownership, device revocation, authenticated finder app sessions, abuse throttling, report deduplication, tamper/anti-replay defenses, observability and retention policies.
4. Complete privacy/security review and store policy review; publish transparency notice and customer support process.
5. For actual fully powered-off phones, work with OEMs or certified hardware/official finding-network partners. Do not advertise this prototype as universal power-off tracking.


## v5 external BLE tag credential

- Owner creates a scoped, high-entropy tag credential from the owner private device code; the raw credential is shown once and only the SHA-256 hash is stored server-side.
- Tag credential can request its own tag token schedule only; it cannot call owner location lookup.
- Tag owner can revoke by submitting their device code and tag ID. Server filters revoked tags, rejecting even previously cached tag tokens.
- Keep the tag credential secret and do not embed the owner's device code in firmware.
- This is still a pilot: the 64-bit advertising tokens and sighting relay are not a substitute for a formal secure, privacy-reviewed crowd-finding protocol. Independent anti-stalking, replay, spoofing, access-control, retention and abuse-resistance review is required before public rollout.


## v6 offline report queue

Browser-local drafts can include contact and private item-identifying details. They are not encrypted storage and may remain on a shared device until cleared. Tell users not to create sensitive drafts on public computers; provide clear draft deletion. The 128-bit clientSubmissionId doubles as the private management code for v6 offline retries, is not included in public report serialization, and must never be added to public links/logging.
