# FindSure v12 — Public HTTPS deployment checklist

The local app is for testing on one laptop. To share the same device code and location between two different phones, deploy one shared HTTPS server and a persistent database.

## 1. Create the shared database

1. Create a project at https://supabase.com/.
2. In Supabase SQL Editor, run the complete `supabase-schema.sql` file in this project.
3. Copy the project URL and a server-side secret key. Keep the secret key only in the hosting provider's environment variables—never in browser code, GitHub or chat.

## 2. Deploy the web server

1. Put the extracted project in a private GitHub repository. Do not commit local data, private recovery codes, tracker keys or admin keys.
2. Deploy the repository to a Node.js host such as https://render.com/ using the included `render.yaml`.
3. Set these environment variables in the host dashboard:
   - `NODE_ENV=production`
   - `SUPABASE_URL` = your Supabase project URL
   - `SUPABASE_SECRET_KEY` = your server-side Supabase key
   - `ADMIN_KEY` = a long random secret
4. Deploy, then open `/api/health`. It must return `ok: true` and `Supabase PostgreSQL`. Do not invite public users if it reports local JSON storage.

## 3. Test the two-device code workflow

1. Open the public HTTPS URL on Phone A. Go to **Device locator**.
2. In **Set up location sharing**, register Phone A and save its private code.
3. Allow location permission, tap **Send one location update**, then **Start live location sharing**. Keep the page active.
4. Open the same public HTTPS URL on Phone B. Go to **Device locator**.
5. Tick the ownership/permission confirmation, enter Phone A's private code and tap **Find device location**.
6. Check the map, captured time, server upload time and accuracy. Tap **Auto-refresh every minute** to check for newer readings.

## Important: localhost is not public

`http://localhost:3000` refers only to the computer running the server. If you type `localhost` on a second phone, it refers to that phone, not your laptop. Browser GPS requires a secure context such as HTTPS (localhost is allowed for local testing). For two separate phones, use the deployed HTTPS address.

## What the live-sharing feature really does

- The target device must be registered and sharing must be enabled before it is lost.
- A browser sends a location only while it has permission and the page/device is active enough to provide updates. Mobile browsers may pause location in the background.
- The finder refreshes the last stored reading every minute; that does not make the target send a new reading if it is offline.
- If the target is offline, the finder can show only the last location already uploaded. A queued location becomes visible only after the target reconnects and uploads it.
- A fully powered-off ordinary phone cannot send a new GPS/Bluetooth reading. Supported manufacturer hardware/networks or a separate powered tag prepared before the loss are required.

## Production safeguards before public launch

- Publish a clear privacy notice, community guidelines and support contact.
- Configure strong admin key, database backups, database restore test and monitoring.
- Add user accounts/device ownership, private-code rotation/revocation and a retention/deletion process before a large rollout.
- Add moderation and an abuse response process for community reports.
- Test on multiple Android/iPhone models and real networks.
- Review map tile usage limits; the public OpenStreetMap tile service is not an unlimited free CDN.
- Never promise guaranteed recovery, universal IMEI tracking or universal powered-off tracking.

## Optional vehicle module

The Car / bike area can show a live position only if a compatible GPS tracker or an authorised spare Android phone was configured beforehand to send telemetry to FindSure. Registration plate, engine number or chassis number alone does not create a live location. See `docs/VEHICLE_TRACKER_API.md` for the backend interface.
