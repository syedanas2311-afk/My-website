# FindSure Professional v12.0

A code-first location-sharing and recovery prototype. The primary experience has two clear jobs:

1. On the device you may need to find later: register it, save the private code, grant location permission, and start visible location sharing.
2. On another phone/computer: enter that private code, press **Find device location**, view the map, capture time, upload time and accuracy. Auto-refresh checks for a newer reading every minute while the page remains open.

## Run on Windows

1. Install Node.js 20.11 or newer.
2. Extract this ZIP to a new folder.
3. Double-click `Run-FindSure-Windows.bat` and keep its terminal open.
4. Open `http://localhost:3000`.

No third-party Node packages are required. Leaflet and OpenStreetMap maps require internet access.

## Important two-device requirement

For two different phones to reach the same server, FindSure must be hosted at a public HTTPS address (or a properly configured HTTPS test host). `localhost` only refers to the device on which the browser is running. The target device must be registered and location sharing must be enabled before it is lost. The page/browser must remain active; mobile browsers may pause location updates in the background. For stronger background operation, a tested native Android companion app is needed.

This is permission-based sharing, not covert tracking. Only locate your own device or one whose owner explicitly consented.

## What it cannot do

- A private code returns only locations previously uploaded by the registered device or an accepted pilot beacon sighting.
- If the target is offline, no fresh remote GPS reading can arrive until it reconnects; only an earlier saved location can be shown.
- A normal fully powered-off phone cannot broadcast via its ordinary Bluetooth radio. A supported manufacturer network or separate powered tracker prepared beforehand is required.
- IMEI, SIM number, registration plate or serial number alone does not provide live coordinates.

## Production before public launch

Configure HTTPS hosting, Supabase using `supabase-schema.sql`, a strong `ADMIN_KEY`, database backups, rate-limit strategy, privacy notice, abuse moderation and real-device tests. The local JSON data file is for development only. Review `DEPLOY_PUBLIC.md` and `PILOT_SECURITY_AND_LIMITS.md`.
